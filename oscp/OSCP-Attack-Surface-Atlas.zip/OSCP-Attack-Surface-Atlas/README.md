# OSCP — surface maps and detailed tracks

Open **START.canvas** with this folder as the Obsidian vault root. Each track offers a **Technique map** with names, links and procedural handoffs, and a **Detailed track** restored to its earlier complete version. The technique maps contain no commands or embedded procedures. Open a linked note for context, commands, interpretation and variants.

All 174 core methods and 19 supplemental surfaces are retained. The same notes and exact cheatsheet sections are indexed in the reference under [Attack-surface maps](https://armaanleg3nd.github.io/oscp/notes/Attack_Surface_Maps/).

The optional Excalidraw, SVG and Map.html versions remain available. Earlier simplified tracks are preserved locally in Simplified backups/.
