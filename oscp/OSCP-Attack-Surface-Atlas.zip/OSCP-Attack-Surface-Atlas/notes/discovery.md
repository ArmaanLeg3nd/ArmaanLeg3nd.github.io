# Discover attack surfaces

[Overview](../START.canvas) · [Browser map](../Map.html)

Discovery establishes reachable behavior from a particular source. Keep host discovery, TCP coverage, UDP coverage and application identity separate; each produces different evidence.

## path-hosts

### Validate the source path and discover hosts

**Enter:** No response, a new subnet, or uncertainty about the interface and route

**Discovery**

```text
ip addr
ip route get TARGET
nmap -sn SUBNET -oA host-discovery
```

**Interpret:** The route names the intended interface/source; a responder is evidence from that source, not a global reachability claim.

**Still check:** Check scope, target state and whether host-discovery probes are permitted by this path.

**Verify:** Record source address/interface, route and the exact responding endpoint; a missing ping response does not prove a host is down.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/discovery/#path-hosts)

### Full procedure and variants

> **Purpose:** Confirm the source path and discover explicitly assigned hosts before spending time on port coverage.

##### 1. Check the path

From the target's working folder:

```bash
mkdir -p scans
ip -br addr
ip route get TARGET
```

> **Read:** selected interface/source address. A route lookup does not prove reachability.

<details>
<summary><strong>Variants — discover one host, a host list or a subnet</strong></summary>

##### Host discovery

**One host:**

```bash
nmap -sn -n -oA scans/host TARGET
```

**Assigned list:** put IPs in `targets.txt`, one per line.

```bash
nmap -sn -n -iL targets.txt -oA scans/hosts
```

**Explicitly assigned subnet:**

```bash
nmap -sn -n -oA scans/subnet SUBNET
```

No response does not establish that a host is offline. A list of assigned hosts does not imply the surrounding subnet is in scope.

</details>

### Follow the evidence

- [ Discover TCP ports with SYN or connect scans](discovery.md#tcp-coverage) — An assigned host needs an initial service queue or full TCP coverage Required: SYN scanning needs raw-packet privileges; connect scanning needs OS TCP connections; specify selected versus full port coverage
- [ Probe UDP and resolve ambiguous silence](discovery.md#udp-coverage) — TCP enumeration is incomplete for the objective or DNS/SNMP/RPC clues suggest UDP Required: Raw-packet access and UDP reachability from the real source; bounded or full selection must be explicit
- [ Relay a single TCP service through a fixed forward](pivoting.md#fixed-forward) — One reachable pivot can connect to one internal TCP destination Required: A bindable pivot listener, source-to-listener access and pivot-to-destination connectivity
- [ Enumerate reachable endpoints from a Windows source](discovery.md#windows-discovery) — The useful vantage point is a Windows host without Nmap Required: A permitted Windows shell, explicit target list and built-in networking support
## tcp-coverage

### Discover TCP ports with SYN or connect scans

**Enter:** An assigned host needs an initial service queue or full TCP coverage

**Discovery**

```text
nmap -Pn -sT --top-ports 1000 TARGET -oA tcp-initial
nmap -Pn -sT -p- TARGET -oA tcp-full
```

**Interpret:** The high listener exists outside the first selection; its application label remains provisional.

**Still check:** Confirm scan completion, source, errors and application behavior on each interesting port.

**Verify:** Retain the selected port set, source context, completion/errors and raw output; follow open ports with focused application evidence.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/discovery/#tcp-coverage)

### Full procedure and variants

> **Purpose:** Get quick leads, complete TCP coverage, and adapt scan type, discovery handling, timing and output to the access path.

##### 2. Get initial TCP results

```bash
sudo nmap -sS -n -oA scans/tcp-initial TARGET
```

> **Coverage:** 1,000 common TCP ports. Review `scans/tcp-initial.nmap` in a text editor.

<details>
<summary><strong>Variants — host list, connect scan or selected ports</strong></summary>

##### Initial view: 1,000 common ports

**Assigned host list, SYN scan:**

```bash
sudo nmap -sS -n -iL targets.txt -oA scans/tcp-initial-list
```

**One host, connect scan without raw-packet privileges:**

```bash
nmap -sT -n -oA scans/tcp-connect TARGET
```

Default coverage is the common-port selection, not ports 1-1000.

##### Selected ports or a range

**One host:** replace PORTS with, for example, `25,43` or `1-1024`.

```bash
sudo nmap -sS -n -p PORTS -oA scans/tcp-selected TARGET
```

**Find relevant services across assigned hosts:**

```bash
sudo nmap -sS -n -p PORTS -iL targets.txt -oA scans/tcp-service-sweep
```

A focused service sweep is not a full port map.

</details>

##### 3. Complete TCP coverage

```bash
sudo nmap -sS -n -p- -oA scans/tcp-all TARGET
```

> **Coverage:** TCP 1-65535. Investigate useful initial results while this runs.

<details>
<summary><strong>Variants — connect scan, blocked discovery, timing and progress</strong></summary>

##### All TCP ports: 1-65535

**Connect scan:**

```bash
nmap -sT -n -p- -oA scans/tcp-all-connect TARGET
```

Inspect additional endpoints before narrowing the investigation. TCP coverage says nothing about UDP.

##### Discovery skips a running target

**Recheck relevant ports with response reasons:**

```bash
sudo nmap -sS -n -Pn --reason -p PORTS -oA scans/tcp-recheck TARGET
```

**Proceed with full TCP coverage despite failed discovery:**

```bash
sudo nmap -sS -n -Pn -p- -oA scans/tcp-all-no-discovery TARGET
```

`-Pn` assumes online status; inspect actual responses. It does not fix routing. Use `-sT` without sudo if ordinary TCP connections are needed.

##### Timing and progress

**Full TCP with normal timing and periodic progress:**

```bash
sudo nmap -sS -n -p- -T3 --stats-every 30s -oA scans/tcp-normal TARGET
```

**Faster timing on a stable path:**

```bash
sudo nmap -sS -n -p- -T4 --stats-every 30s -oA scans/tcp-faster TARGET
```

`-T3` is normal timing; `-T4` is more aggressive. Periodic progress changes display, not coverage. Recheck decisive results if loss or filtering makes observations uncertain.

##### TCP-only access through a SOCKS proxy

Use ordinary connect calls when a previously established proxy is the only route. This is a bounded first view, not complete TCP coverage:

```bash
proxychains nmap -sT -Pn -n --top-ports 100 -oA scans/tcp-proxy-top100 TARGET
```

`proxychains` cannot turn SYN probes or UDP into proxied TCP connections. `-Pn` avoids discovery probes that may not traverse the proxy. Confirm the proxy route first, preserve the 100-port limit, and expand with another connect scan only when scope and path permit it.

</details>

### Follow the evidence

- [ Identify applications and validate selected NSE checks](discovery.md#identify-app) — A listener has a port-based label or uncertain version Required: A reachable selected port; scripts must match the application and permitted assessment behavior
- [ Enumerate SMB/RPC shares, files and identities](services.md#service-smb) — SMB/RPC endpoints, domain clues or new credentials Required: Reachable SMB/RPC; anonymous, guest, local or domain context must be explicit; share and filesystem ACLs both matter
- [ Establish scheme, host, redirects and request state](web-mapping.md#web-identity) — An HTTP endpoint, redirect or hostname-dependent response Required: Correct scheme/port and virtual host; saved cookies/headers for authenticated comparisons
## identify-app

### Identify applications and validate selected NSE checks

**Enter:** A listener has a port-based label or uncertain version

**Discovery**

```text
nmap -Pn -sV -p PORTS TARGET -oA selected-services
```

**Interpret:** An HTTP response on a nonstandard port routes investigation to application mapping; a product string is still only fingerprint evidence.

**Still check:** Verify normal requests, hostname/TLS requirements and exact build/configuration before selecting an exploit.

**Verify:** Preserve the responding product/version evidence and distinguish an inferred fingerprint from a confirmed vulnerable build.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/discovery/#identify-app)

### Full procedure and variants

> **Purpose:** Identify applications on discovered ports and choose only the probing needed for the next decision.

##### 4. Identify discovered applications

```bash
nmap -sT -n -sV -p PORTS -oA scans/tcp-services TARGET
```

> **Next:** choose service-specific enumeration from application evidence. A version match alone does not establish exploitability.

<details>
<summary><strong>Variants — default scripts, named scripts and OS fingerprints</strong></summary>

##### Identify applications on discovered ports

**Version probing plus the default NSE script set:** use when those scripts answer relevant enumeration questions.

```bash
nmap -sT -n -sV -sC -p PORTS -oA scans/tcp-services-default TARGET
```

Read the application evidence and script results. Default scripts add interactions; they do not complete service enumeration or prove exploitability.

**Lighter version probing when time or fragile service behavior matters:**

```bash
nmap -sT -n -sV --version-light -p PORTS -oA scans/tcp-services-light TARGET
```

Light mode tries fewer uncommon probes and can miss an identity that the default intensity finds. Use the default first unless a concrete constraint justifies the tradeoff.

##### Select a named script

**Inspect behavior locally:**

```bash
nmap --script-help http-headers
```

**After identifying HTTP, inspect its relevant port(s):**

```bash
nmap -sT -n -p PORTS --script http-headers -oA scans/http-headers TARGET
```

Returned headers are clues. Choose scripts for the question they answer and their behavior.

##### OS fingerprinting and bundled probing

**Estimate OS from network-stack behavior:**

```bash
sudo nmap -n -O -oA scans/os TARGET
```

**Request more tentative OS guesses:**

```bash
sudo nmap -n -O --osscan-guess -oA scans/os-guesses TARGET
```

**Bundle OS/version detection, default scripts and traceroute:**

```bash
sudo nmap -sS -n -A -oA scans/combined-detail TARGET
```

OS guesses are hypotheses. These use default TCP coverage; `-A` does not mean all ports. Choose this bundle only when its additional probing is useful.

</details>

### Follow the evidence

- [ Discriminate unknown listeners and use scanner alternatives](discovery.md#unknown-port) — A nonstandard listener, slow TCP discovery or a scanner-specific candidate Required: Explicit bounded scope; raw scanning alternatives need their required privileges and conservative rates
- [ Establish scheme, host, redirects and request state](web-mapping.md#web-identity) — An HTTP endpoint, redirect or hostname-dependent response Required: Correct scheme/port and virtual host; saved cookies/headers for authenticated comparisons
- [ Match a public exploit to the actual component and configuration](public-exploits.md#exploit-select) — A product/version clue, advisory or component-specific public PoC Required: Exact vulnerable build/configuration, required access and endpoint behavior; reviewable source and a verifiable expected effect
- [ Inspect rsync modules and retrieve selected artifacts](services.md#service-rsync) — An rsync daemon banner, TCP/873 listener or disclosed rsync module Required: Reachable rsync daemon and a module/path readable by the anonymous or supplied account
- [ Retrieve an evidence-backed file over TFTP](services.md#service-tftp) — A UDP/69 service plus a plausible filename from configuration, source or boot metadata Required: Reachable TFTP service and an exact server-relative filename permitted for read or write
- [ Use anonymous or authenticated FTP file access](services.md#service-ftp) — An FTP banner or accessible listing Required: Anonymous login allowed or a valid FTP identity; data-channel connectivity and object-specific read/write rights
- [ Use SSH passwords, keys and forwarding-capable access](services.md#service-ssh) — An SSH service and a known password, private key or agent context Required: Compatible authentication method, correct user, accepted key policy and the requested shell/subsystem permission
- [ Enumerate SMTP identities and accessible mailbox protocols](services.md#service-smtp) — SMTP capabilities or mail-related account clues Required: Reachable SMTP/POP3/IMAP service; enumeration or mailbox access must be enabled for the selected context
- [ Expand names through DNS records and zone transfers](services.md#service-dns) — A DNS server, domain name or host aliases Required: Reachable DNS transport and relevant authoritative zone; AXFR requires an allowed TCP zone transfer
- [ Inspect RPC/NFS exports and effective file identity](services.md#service-nfs) — RPC/NFS listeners or export information Required: Reachable RPC/NFS transports, permitted client address and an export whose UID/GID mapping grants relevant access
- [ Enumerate SMB/RPC shares, files and identities](services.md#service-smb) — SMB/RPC endpoints, domain clues or new credentials Required: Reachable SMB/RPC; anonymous, guest, local or domain context must be explicit; share and filesystem ACLs both matter
- [ Extract configuration and process information through SNMP](services.md#service-snmp) — UDP/161 evidence or an exposed management plane Required: An accepted read community or SNMPv3 identity/security level; transport and view permissions
- [ Use MySQL/MariaDB data and file primitives](services.md#service-mysql) — A MySQL-compatible service and valid application/database credentials Required: Database authentication and exact schema/file privileges; secure_file_priv and server filesystem identity constrain file actions
- [ Use SQL Server rights, impersonation and command facilities](services.md#service-mssql) — SQL Server credentials or a Windows identity accepted by the database Required: Correct SQL versus Windows authentication; database role and configuration must permit the requested operation
- [ Use PostgreSQL data and privileged program execution](services.md#service-postgres) — PostgreSQL access or an application connection string Required: Accepted connection/database role; COPY PROGRAM needs the corresponding server privilege and an executable OS context
- [ Inspect Redis access and persistence boundaries](services.md#service-redis) — A Redis listener or application cache credentials Required: Reachability and accepted authentication/ACL commands; persistence writes need CONFIG rights, destination permissions and a consumer
- [ Triage Oracle listener and database identity](services.md#service-oracle) — An Oracle TNS listener or connection descriptor Required: Correct service/SID, reachable database transport and valid database credentials for authenticated work
- [ Validate RDP, WinRM, VNC and Telnet access contexts](services.md#service-remote) — An exposed remote-access application and compatible known credentials Required: Enabled destination service, matching authentication and protocol-specific logon/session rights
- [ Discover LDAP naming contexts and authenticated search](services.md#service-ldap) — LDAP/Kerberos listeners or a probable AD domain Required: Reachable directory; anonymous query permission or valid bind identity; required signing/TLS and naming context
- [ Investigate SIP/IRC identity and configuration clues](services.md#service-sip-irc) — A confirmed SIP or IRC application Required: Application-specific request format; permitted registration/channel/configuration access
## udp-coverage

### Probe UDP and resolve ambiguous silence

**Enter:** TCP enumeration is incomplete for the objective or DNS/SNMP/RPC clues suggest UDP

**Discovery**

```text
sudo nmap -Pn -sU --top-ports 20 --reason TARGET -oA udp-initial
```

**Interpret:** A DNS response confirms a UDP application; open|filtered SNMP silence is a candidate requiring a correctly formatted request.

**Still check:** Check accepted service parameters, response identity and possible ICMP rate limiting.

**Verify:** Use an application response for a confirmed service; document unresolved silence, coverage and ICMP rate-limit effects.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/discovery/#udp-coverage)

### Full procedure and variants

> **Purpose:** Sample UDP separately, preserve ambiguous states, and expand only when the objective or evidence warrants it.

##### 5. Check UDP separately

```bash
sudo nmap -sU -n --top-ports 20 -oA scans/udp-top20 TARGET
```

> **Limit:** this is a sample. `open|filtered` remains inconclusive; expand when evidence or the objective warrants it.

<details>
<summary><strong>Variants — larger sample, selected ports, application probes and TCP + UDP</strong></summary>

##### Common-port samples

**Expand to 100 common ports when more coverage is warranted:**

```bash
sudo nmap -sU -n --top-ports 100 -oA scans/udp-top100 TARGET
```

These are samples. `open|filtered` is inconclusive; TCP results cannot fill UDP gaps.

##### Selected ports

**Check a relevant UDP port/list:**

```bash
sudo nmap -sU -n -p PORTS -oA scans/udp-selected TARGET
```

**Add application probes to resolve a useful candidate:**

```bash
sudo nmap -sU -n -sV -p PORTS -oA scans/udp-detail TARGET
```

A reply can resolve ambiguity; no reply can leave it inconclusive. If discovery skips an assigned running host, add `-Pn` with the same limitations as TCP.

##### Full UDP coverage when the objective justifies the cost

```bash
sudo nmap -sU -n -p- --stats-every 60s -oA scans/udp-all TARGET
```

This selects UDP ports 1-65535 and may take a long time because silence requires waiting and ICMP errors may be rate-limited. It is the coverage-expansion option, not a universal first command. Continue service work in parallel and preserve the result if the scan cannot finish.

##### Combined TCP/UDP selection

**Example selection:** change the TCP (`T:`) and UDP (`U:`) lists for the actual question.

```bash
sudo nmap -sS -sU -n -p T:22,80,445,U:53,123,161 -oA scans/tcp-udp TARGET
```

The port lists are examples, not complete coverage. UDP waiting can extend the combined scan.

</details>

### Follow the evidence

- [ Extract configuration and process information through SNMP](services.md#service-snmp) — UDP/161 evidence or an exposed management plane Required: An accepted read community or SNMPv3 identity/security level; transport and view permissions
- [ Expand names through DNS records and zone transfers](services.md#service-dns) — A DNS server, domain name or host aliases Required: Reachable DNS transport and relevant authoritative zone; AXFR requires an allowed TCP zone transfer
- [ Inspect RPC/NFS exports and effective file identity](services.md#service-nfs) — RPC/NFS listeners or export information Required: Reachable RPC/NFS transports, permitted client address and an export whose UID/GID mapping grants relevant access
## result-validation

### Validate uncertain results and rebuild the service queue

**Enter:** Scanners disagree, a result is ambiguous, or a new identity changes accessible behavior

**Discovery**

```text
nc -nvz TARGET PORT
nmap -Pn -sT -p PORT --reason TARGET
```

**Interpret:** Independent TCP reachability supports an endpoint candidate, not credentials, read permission or execution.

**Still check:** Identify the application and validate the particular next-layer action.

**Verify:** Record which layer was demonstrated: transport, application, authentication, read/write or execution.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/discovery/#result-validation)

### Full procedure and variants

> **Purpose:** Resolve uncertainty that affects a decision, preserve coverage limits, and turn scan output into a service-enumeration queue.

##### 6. Resolve a result that changes your next action

Keep source, destination, transport and port consistent when comparing results. Revisit relevant checks after a new route, foothold or identity changes access.

<details>
<summary><strong>Variants — Netcat verification, response reasons and readable output</strong></summary>

##### Netcat connection check

**One TCP port:** replace PORTS with one number.

```bash
nc -nv -w 3 -z TARGET PORTS
```

**Short port range:** replace PORTS with a range such as `3388-3390`.

```bash
nc -nvv -w 3 -z TARGET PORTS
```

Success establishes TCP connection acceptance; refusal and timeout differ. The second form gives more verbose output. A three-second wait may be insufficient on a slow path.

##### Output and diagnostics

**Readable text only, with verbose output and port-state reasons:**

```bash
sudo nmap -sS -n -v --reason -p PORTS -oN scans/tcp-check.txt TARGET
```

Open saved `.nmap` or `.txt` output in a text editor. `-oA` writes `.nmap`, `.gnmap` and `.xml`; `-oN` writes only normal text. Use a different output prefix when retaining another run.

</details>

##### 7. Build the service queue

Open the saved `.nmap` files in a text editor. For every useful endpoint, capture one line with this structure:

```text
SOURCE -> TARGET | tcp/udp PORT | OBSERVED STATE | APPLICATION EVIDENCE | COVERAGE LIMIT | NEXT TEST
```

> **Next:** carry the complete endpoint tuple into [Stage 02 service enumeration](https://github.com/ArmaanLeg3nd/OSCP-Exploitation-Reference/blob/main/reference/02-service-enumeration/README.md) and choose the cheapest protocol-aware test that can change your understanding or access. Keep an explicit return item for incomplete TCP, UDP or application coverage.

<details>
<summary><strong>Interpretation cues — preserve what the scan actually established</strong></summary>

- `open` establishes a reachable endpoint from the scan source; it does not establish a vulnerability or usable authentication.
- `closed` records an explicit rejection in that context. Move on unless later evidence changes the route, source or target state.
- `filtered` leaves the listener state unresolved because filtering, loss or the path prevented classification.
- `unfiltered` means the selected probe reached the port but could not determine whether it was open or closed; use a scan type that can answer the required question.
- UDP `open|filtered` is inconclusive. A useful protocol probe may reduce uncertainty, but another silence can remain inconclusive.
- `closed|filtered` is also an explicit ambiguity. Preserve it unless resolving the distinction changes the next action.
- A port-based service label is a clue. Use application evidence before treating product, version, operating system or machine role as confirmed.
- Record the exact target, transport, selected ports and source position. A successful narrow scan does not cover untested ports, the other transport or another network position.

</details>

##### 8. Prioritize and know when to rescan

Rank candidates by the cheapest test likely to produce access, credentials, sensitive information or a decisive prerequisite. Prefer observed application behavior over conventional port numbers. Keep at least one return item for incomplete coverage so an attractive early service does not erase the rest of the map.

Re-run network discovery after a new source host, route, tunnel or target restart. Re-enumerate a service after a new credential or identity. Inspect local listeners after a foothold. Recheck a previous result when the source, target state, port selection or network conditions changed—not simply because the first attack failed.

### Follow the evidence

- [ Identify applications and validate selected NSE checks](discovery.md#identify-app) — A listener has a port-based label or uncertain version Required: A reachable selected port; scripts must match the application and permitted assessment behavior
- [ Validate known passwords and context-specific reuse](credentials.md#credential-use) — A password tied to a plausible user and service Required: Correct local/domain/application identity, reachable compatible service, accepted authentication and account state
- [ Maintain state and select the next evidence-producing test](integration.md#attack-state) — Several hosts, identities, routes or competing hypotheses need coordination Required: Explicit scope/objective and a record of observations, unknowns and available capabilities
## windows-discovery

### Enumerate reachable endpoints from a Windows source

**Enter:** The useful vantage point is a Windows host without Nmap

**Discovery**

```text
Get-NetIPConfiguration
Get-NetRoute -AddressFamily IPv4
Test-NetConnection TARGET -Port 445
```

**Interpret:** The service is reachable from this Windows source; this can reveal a useful vantage point unavailable from Kali.

**Still check:** Confirm application/authentication and whether a forward or a native client can use that route.

**Verify:** Associate each result with the actual Windows source and selected port; do not claim UDP or full-port coverage.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/discovery/#windows-discovery)

### Full procedure and variants

> **Purpose:** Test TCP reachability from a Windows host when source position or available tooling matters.

Test one TCP port from the Windows source host:

```powershell
Test-NetConnection -ComputerName TARGET -Port PORTS
```

> **Read:** `TcpTestSucceeded`, source and destination addresses. Use one number for PORTS. Failure does not distinguish a closed port, filtering or a path problem.

<details>
<summary><strong>Variants — scan ports 1-1024 or a selected port list</strong></summary>

##### Scan a low-port range

```powershell
1..1024 | % {echo ((New-Object Net.Sockets.TcpClient).Connect("DC_IP", $_)) "TCP port $_ is open"} 2>$null
```

##### Check a selected port list

The example list can be changed to the endpoints of interest.

```powershell
22,80,443,445,3389 | % {echo ((New-Object Net.Sockets.TcpClient).Connect("TARGET", $_)) "TCP port $_ is open"} 2>$null
```

`$_` is the current port; errors are hidden. No printed result does not prove every port is closed. Results reflect the Windows host's access and the stated port selection.

</details>

### Follow the evidence

- [ Discover pivot interfaces, routes and internal service context](pivoting.md#pivot-state) — A foothold exposes an interface/subnet or a loopback-only service Required: A usable pivot process/identity and explicit scope; both forward and return directions must be understood
- [ Use WinRM, WinRS or PowerShell remoting](lateral-movement.md#move-winrm) — A WinRM listener and a candidate endpoint-authorized account Required: Reachable HTTP(S) listener, accepted authentication and endpoint/session configuration permissions; hash/ticket support depends on client/context
- [ Validate uncertain results and rebuild the service queue](discovery.md#result-validation) — Scanners disagree, a result is ambiguous, or a new identity changes accessible behavior Required: A selected endpoint and a test that can resolve the decision-changing uncertainty
## unknown-port

### Discriminate unknown listeners and use scanner alternatives

**Enter:** A nonstandard listener, slow TCP discovery or a scanner-specific candidate

**Discovery**

```text
nmap -Pn -sV --version-all -p PORT TARGET
nc -nv TARGET PORT
```

**Interpret:** TLS and an HTTP redirect suggest a hostname-selected web application rather than an attack tied to the port number.

**Still check:** Reproduce the hostname/TLS request and confirm exact software/configuration.

**Verify:** Confirm the endpoint through independent application behavior and preserve the rate/scope used for discovery.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/discovery/#unknown-port)

### Full procedure and variants

> **Use when:** Nmap remains the interpretation baseline, but a faster TCP discovery pass or a bounded web-server check is useful. These tools generate candidates; Nmap/manual protocol checks confirm them.

##### RustScan: fast TCP discovery, Nmap interpretation

> **Prerequisite:** RustScan and Nmap on Kali; direct TCP reachability. **Coverage:** only the explicit TCP range. **Decisive output:** a discovered port that Nmap can reproduce and identify.

```bash
rustscan -a TARGET -r 1-65535 --ulimit 5000 -- \
  -Pn -sV -sC -oA rustscan-followup
```

If the target or network becomes unstable, lower concurrency rather than trusting an empty result. RustScan does not replace UDP work and does not prove that closed/filtered ports were tested with the same semantics as Nmap.

<details>
<summary><strong>Bounded first 1,000 TCP ports</strong></summary>

```bash
rustscan -a TARGET -r 1-1000 --ulimit 5000 -- \
  -Pn -sV -sC -oA rustscan-1000
```

> Use only for a quick selection. It is not full TCP coverage and is not equivalent to Nmap's default top-1,000 selection.

</details>

##### Masscan: raw-packet discovery, then validation

> **Prerequisite:** root/raw-packet access and a directly routed target. **Choose it:** for a large authorized address/port space where discovery speed matters. **Failure cue:** high loss or inconsistent results at the chosen rate.

```bash
sudo masscan TARGET -p1-65535 --rate 500 -oL masscan-open.txt
```

Treat each hit as a candidate and recheck with Nmap:

```bash
PORTS=$(awk '$1 == "open" && $2 == "tcp" {print $3}' masscan-open.txt \
  | sort -nu | paste -sd,)
test -n "$PORTS" && sudo nmap -Pn -sV -sC -p "$PORTS" TARGET -oA masscan-verified
```

Masscan's raw-packet model is not suitable through a TCP SOCKS proxy. A rate that overwhelms the path can create false negatives and disrupt the lab; record the rate with the result.

##### Unknown-port discrimination

Start passively or with protocol-appropriate probes. Do not spray arbitrary strings at a stateful or destructive service.

```bash
nmap -Pn -sV --version-all -p PORT TARGET -oN port-PORT-version.txt
nmap --script-help banner
nmap -Pn --script=banner -p PORT TARGET -oN port-PORT-banner.txt
nc -nv TARGET PORT
openssl s_client -connect TARGET:PORT -servername HOSTNAME
curl -vk --max-time 10 https://TARGET:PORT/
```

> **Next action:** route application evidence to the matching Stage 02 page. If TLS succeeds but HTTP does not, preserve the certificate names and protocol evidence instead of labelling it HTTPS.

##### NSE candidate checks

Inspect a script before selecting it:

```bash
nmap --script-help SCRIPT_NAME
grep -i 'SCRIPT_NAME' /usr/share/nmap/scripts/script.db
```

Run a named script against a confirmed service/port:

```bash
nmap -Pn -sV --script SCRIPT_NAME -p PORT TARGET -oN nse-SCRIPT_NAME.txt
```

The broad `vuln` category is candidate generation and can be intrusive or misleading. If its use is justified in the authorized lab, restrict it to identified ports and manually validate every result:

```bash
nmap -Pn -sV --script vuln -p PORTS TARGET -oN nse-vuln-candidates.txt
```

Avoid `*brute*` categories as a default; first establish exact service, known test identities, lockout/rate limits and explicit authorization.

##### Nikto: bounded web-server candidate generation

> **Prerequisite:** an identified HTTP(S) endpoint. **Choose it:** after manual baselining to identify common files, headers and server misconfiguration candidates. **Decisive output:** a finding manually reproduced with the same host, path and authentication context.

```bash
nikto -h http://TARGET:PORT -output nikto-TARGET-PORT.txt
```

<details>
<summary><strong>HTTPS, host name and tuning variants</strong></summary>

```bash
nikto -h https://HOSTNAME:PORT -output nikto-HOSTNAME-PORT.txt
nikto -h http://TARGET:PORT -vhost HOSTNAME -output nikto-vhost.txt
nikto -h http://TARGET:PORT -Tuning 123b -output nikto-focused.txt
```

> Tuning codes are version-sensitive. Inspect `nikto -H` / local documentation before relying on a copied code set.

</details>

Nikto is explicitly listed as allowed by the current OffSec exam guide, but its findings remain scanner candidates. Recheck the guide before an exam and manually validate anything that affects an attack decision.

### Follow the evidence

- [ Identify applications and validate selected NSE checks](discovery.md#identify-app) — A listener has a port-based label or uncertain version Required: A reachable selected port; scripts must match the application and permitted assessment behavior
- [ Establish scheme, host, redirects and request state](web-mapping.md#web-identity) — An HTTP endpoint, redirect or hostname-dependent response Required: Correct scheme/port and virtual host; saved cookies/headers for authenticated comparisons
- [ Match a public exploit to the actual component and configuration](public-exploits.md#exploit-select) — A product/version clue, advisory or component-specific public PoC Required: Exact vulnerable build/configuration, required access and endpoint behavior; reviewable source and a verifiable expected effect
