# Map useful web behavior

[Overview](../START.canvas) · [Browser map](../Map.html)

Build the request and role map before selecting a weakness. Distinguish scheme, virtual host, route, method, parameter, object and identity; the same path can expose different behavior in another context.

## web-identity

### Establish scheme, host, redirects and request state

**Enter:** An HTTP endpoint, redirect or hostname-dependent response

**Discovery**

```text
curl -skD headers.txt -o body.html http://TARGET:PORT/
curl -skI https://TARGET:PORT/
```

**Interpret:** The hostname/scheme redirect identifies the application request context to reproduce.

**Still check:** Confirm the hostname routes to the assigned address and preserve its TLS/Host/session state.

**Verify:** Record final URL, host, status, redirects, cookies and authentication context before comparing payload results.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/web-mapping/#web-identity)

### Full procedure and variants

```bash
curl -skL -D headers.txt -o body.html http://TARGET:PORT/
curl -sk -o /dev/null -w 'code=%{http_code} bytes=%{size_download} type=%{content_type} redirect=%{redirect_url}\n' http://TARGET:PORT/
```

> **Decisive output:** record the scheme, hostname/`Host` header, port, redirects, page title, certificate names, server/framework clues and whether the view is anonymous or authenticated.

<details>
<summary><strong>Variant — explicit virtual-host candidate</strong></summary>

```bash
curl -sk -H 'Host: CANDIDATE.DOMAIN' http://TARGET:PORT/
```

Compare it with a random hostname. A different status alone is weak evidence; compare body, length, title and redirects.

</details>

<details>
<summary><strong>Variant — preserve cookies and follow redirects</strong></summary>

```bash
curl -skL -c cookies.txt -b cookies.txt http://TARGET:PORT/PATH
```

Use a separate cookie jar per identity. Do not mix anonymous, ordinary-user and administrator evidence.

</details>

<details>
<summary><strong>Variant — replay through Burp Community</strong></summary>

```bash
curl -sk -x http://127.0.0.1:8080 http://TARGET:PORT/PATH
```

Confirm the proxy listener is active on `127.0.0.1:8080`. Use `-k` only for the controlled lab because it disables destination-certificate verification.

</details>

### Follow the evidence

- [ Discover virtual hosts and hostname-selected applications](web-mapping.md#web-vhosts) — DNS names, redirects, certificate names or a default virtual-host response Required: A destination listener, relevant domain candidates and controlled Host/SNI routing
- [ Map functions, roles and normal requests manually](web-mapping.md#web-behavior) — Forms, downloads, exports, account functions or role-specific interfaces Required: A normal request baseline and the relevant account/role; authorized accounts for role comparisons
- [ Inspect source, backups, configuration and repository artifacts](web-mapping.md#web-artifacts) — JavaScript endpoints, backup names, exposed configuration or Git metadata Required: Readable application artifact or a complete recoverable repository; preserve the public-source scope
## web-behavior

### Map functions, roles and normal requests manually

**Enter:** Forms, downloads, exports, account functions or role-specific interfaces

**Discovery**

```text
curl -sk -b cookies.txt -D response-headers.txt http://TARGET:PORT/PATH
```

**Interpret:** The normal request exposes a file-selecting input discovered through functionality, not guessed from a payload list.

**Still check:** Find the actual input semantics, account/role and normal response before file/read/authorization tests.

**Verify:** Retain method, route, input location, identity and expected normal behavior; do not infer vulnerability from an interesting parameter name.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/web-mapping/#web-behavior)

### Full procedure and variants

For every visible function, capture one unchanged request in Burp Proxy history, send it to Repeater and record:

```text
METHOD PATH | CONTENT-TYPE | ACCESS CONTEXT/ROLE
INPUT LOCATION + NAME | BASELINE VALUE
STATUS | LENGTH/HASH | REDIRECT | MARKER/ERROR/TIME
OBJECT/FUNCTION SELECTED | NEXT ONE-VARIABLE TEST
```

Check login/registration/reset, profiles/objects, search/filter/pagination, download/export/preview, upload/import, administration and every JavaScript API call.

> **Next:** a browser-side restriction is not server authorization. Replay the raw request and change one field, object reference, method or access-context element at a time.

### Follow the evidence

- [ Cross an object-ownership boundary](web-exploitation.md#web-idor) — A request selects an object by ID/path and two authorized ownership contexts are available Required: The server accepts a lower-privilege identity's request for an object it should not access
- [ Read files through directory traversal](web-exploitation.md#web-traversal) — A download/path parameter or URL segment influences a local filename Required: Untrusted path reaches a filesystem read outside its intended directory; process identity can read the requested file
- [ Establish upload acceptance, storage and retrieval](web-exploitation.md#web-upload) — An upload/import/attachment function Required: A valid upload request and permitted account; the server accepts and stores controlled bytes
- [ Prove server-side template evaluation and identify its engine](web-exploitation.md#web-ssti) — Controlled input appears in a server-rendered template, preview, email or report Required: The application evaluates attacker-controlled template syntax and the selected engine exposes a useful object or function
- [ Use an XML parser's external-entity behavior for bounded file read](web-exploitation.md#web-xxe) — A working XML request reaches a server-side parser that accepts a controlled document or field Required: External entity or XInclude processing is enabled and the parser identity can read the selected file
- [ Test structured NoSQL operator injection with identity controls](web-exploitation.md#web-nosql) — A login or search accepts JSON/nested form properties and evidence suggests an operator-based document query Required: The framework preserves an attacker-controlled operator object and the query uses it without rejecting its type
- [ Match PHP deserialization gadgets to installed dependencies](web-exploitation.md#web-php-deserialization) — Source or request evidence shows controlled serialized PHP data reaches unsafe unserialize Required: Required gadget classes and compatible dependency versions are loaded; transport preserves exact serialized bytes
- [ Validate unsafe YAML object construction](web-exploitation.md#web-yaml) — Source or errors identify server-side Python YAML loading of controlled content Required: The application uses an unsafe PyYAML loader that permits the selected Python object constructor
- [ Test Shellshock only through a confirmed CGI-to-Bash chain](web-exploitation.md#web-shellshock) — A real CGI endpoint invokes Bash and component/patch evidence supports the vulnerable family Required: HTTP-derived environment data reaches an affected Bash process and the selected command is available
- [ Discover directories and files with controlled response filtering](web-mapping.md#web-content) — An application has unlinked paths, backups or administration endpoints Required: Correct base URL/session and a measured nonexistent-path response; bounded relevant wordlist
## web-artifacts

### Inspect source, backups, configuration and repository artifacts

**Enter:** JavaScript endpoints, backup names, exposed configuration or Git metadata

**Discovery**

```text
curl -sk http://TARGET:PORT/robots.txt
curl -sk http://TARGET:PORT/.git/HEAD
```

**Interpret:** The path and Git reference are investigation leads; neither proves a working secret or complete repository.

**Still check:** Compare missing-path controls, retrieve actual permitted artifacts and verify recovered history/account context.

**Verify:** Confirm actual file/history content and distinguish a historical secret from a usable current credential.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/web-mapping/#web-artifacts)

### Full procedure and variants

```bash
curl -sk http://TARGET:PORT/robots.txt
curl -sk http://TARGET:PORT/sitemap.xml
curl -sk http://TARGET:PORT/.git/HEAD
curl -sk http://TARGET:PORT/openapi.json
curl -sk http://TARGET:PORT/swagger.json
```

Also inspect HTML comments, hidden inputs, form actions, linked JavaScript, route strings, source-map references, cookies and response headers.

> **Decisive output:** a path, parameter, API schema, object identifier, component or secret-bearing artifact that creates a specific next request. Source disclosure is not command execution.

```bash
curl -ski http://TARGET:PORT/.git/HEAD
curl -ski http://TARGET:PORT/.git/config
```

> A readable `HEAD`/`config` supports exposed repository metadata. A `403`, redirect or generic template is not proof. Preserve the correct host header/base path.

If authorized, recover into a new local directory with a purpose-built tool and inspect locally:

```bash
git-dumper http://TARGET:PORT/.git/ repo-output
git -C repo-output status
git -C repo-output log --oneline --all --decorate
git -C repo-output log -p --all
```

`git-dumper` is an optional third-party helper; install on demand in an isolated environment only when the exposure has been confirmed. Manual object recovery is possible but slower.

```bash
rg -ni 'password|passwd|token|secret|api[_-]?key|private[_-]?key' repo-output
git -C repo-output log --all -S'password' --oneline
git -C repo-output log --all -G'pass(word)?|secret|token' --oneline
```

Inspect candidate commits without dumping all history:

```bash
git -C repo-output show COMMIT -- PATH
git -C repo-output diff COMMIT^ COMMIT -- PATH
```

Validate freshness, identity and compatible use. Removed historical values are often rotated or environment-specific.

### Follow the evidence

- [ Classify the artifact and its identity context](credentials.md#credential-classify) — A secret-like value, key file, stored hash, challenge response or ticket Required: Artifact provenance and format; possible local/domain/application identity and compatible protocol
- [ Match a public exploit to the actual component and configuration](public-exploits.md#exploit-select) — A product/version clue, advisory or component-specific public PoC Required: Exact vulnerable build/configuration, required access and endpoint behavior; reviewable source and a verifiable expected effect
- [ Map parameters, API methods, objects and writable properties](web-mapping.md#web-parameters) — An API/schema, numeric object IDs, hidden fields or different HTTP methods Required: A valid request and explicit role/object ownership; exact input format and content type
## web-content

### Discover directories and files with controlled response filtering

**Enter:** An application has unlinked paths, backups or administration endpoints

**Discovery**

```text
curl -sk -D - http://TARGET:PORT/KNOWN_MISSING_PATH
```

**Interpret:** The candidate's actual function differs from the soft-404 control despite equal status codes.

**Still check:** Request a known-missing path under the same host/session and compare status, body and length. Open each distinct Gobuster/ffuf result; a uniform login page or soft-404 is a filter problem, not a directory finding.

**Verify:** Open candidates and record their actual behavior; status/length alone is only a selection clue.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/web-mapping/#web-content)

### Full procedure and variants

Request a random nonexistent path first and record its status, length and body marker.

```bash
gobuster dir -u http://TARGET:PORT/ -w /usr/share/wordlists/dirb/common.txt -t 10 -o gobuster-root.txt
```

> **Decisive output:** manually verified routes including useful `200`, redirect, `401`, `403` and `405` responses.

<details>
<summary><strong>Variant — technology-aware extensions</strong></summary>

```bash
gobuster dir -u http://TARGET:PORT/ -w WORDLIST -x php,txt,bak,old,zip -t 10 -o gobuster-ext.txt
```

Choose extensions from observed stack evidence; do not spray every extension.

</details>

<details>
<summary><strong>Variant — authenticated discovery</strong></summary>

```bash
gobuster dir -u http://TARGET:PORT/ -w WORDLIST -c 'SESSION=VALUE' -H 'Authorization: Bearer TOKEN' -t 10 -o gobuster-auth.txt
```

Use only the cookie or header that applies. An expired session can turn every result into the same login redirect.

</details>

<details>
<summary><strong>Variant — filter a confirmed wildcard body length</strong></summary>

```bash
gobuster dir -u http://TARGET:PORT/ -w WORDLIST --exclude-length NOISE_LENGTH -t 10 -o gobuster-filtered.txt
```

Filtering without first confirming the noise response can hide a real path.

</details>

### Follow the evidence

- [ Map functions, roles and normal requests manually](web-mapping.md#web-behavior) — Forms, downloads, exports, account functions or role-specific interfaces Required: A normal request baseline and the relevant account/role; authorized accounts for role comparisons
- [ Inspect source, backups, configuration and repository artifacts](web-mapping.md#web-artifacts) — JavaScript endpoints, backup names, exposed configuration or Git metadata Required: Readable application artifact or a complete recoverable repository; preserve the public-source scope
- [ Establish upload acceptance, storage and retrieval](web-exploitation.md#web-upload) — An upload/import/attachment function Required: A valid upload request and permitted account; the server accepts and stores controlled bytes
## web-vhosts

### Discover virtual hosts and hostname-selected applications

**Enter:** DNS names, redirects, certificate names or a default virtual-host response

**Discovery**

```text
curl -sk --resolve HOSTNAME:PORT:TARGET https://HOSTNAME:PORT/
```

**Interpret:** A reproducible hostname-selected application is a new mapping target on the same address.

**Still check:** Send a random Host header as a negative control, compare the candidate's real response, then browse it with the correct hostname. A different status caused only by redirects or a default site is not a confirmed vhost.

**Verify:** Compare candidate and nonexistent-host responses, including content and redirects; resolve to the intended scoped address.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/web-mapping/#web-vhosts)

### Full procedure and variants

```bash
gobuster vhost -u http://DOMAIN:PORT/ --append-domain -w /usr/share/seclists/Discovery/DNS/subdomains-top1million-5000.txt -o vhosts.txt
```

Alternative with automatic calibration:

```bash
ffuf -w WORDLIST -u http://TARGET:PORT/ -H 'Host: FUZZ.DOMAIN' -ac -o ffuf-vhosts.json
```

> **Failure cue:** uniform status/length may be the default vhost. Compare each candidate with a random host header before adding it to the application map.

### Follow the evidence

- [ Establish scheme, host, redirects and request state](web-mapping.md#web-identity) — An HTTP endpoint, redirect or hostname-dependent response Required: Correct scheme/port and virtual host; saved cookies/headers for authenticated comparisons
- [ Map functions, roles and normal requests manually](web-mapping.md#web-behavior) — Forms, downloads, exports, account functions or role-specific interfaces Required: A normal request baseline and the relevant account/role; authorized accounts for role comparisons
- [ Expand names through DNS records and zone transfers](services.md#service-dns) — A DNS server, domain name or host aliases Required: Reachable DNS transport and relevant authoritative zone; AXFR requires an allowed TCP zone transfer
## web-parameters

### Map parameters, API methods, objects and writable properties

**Enter:** An API/schema, numeric object IDs, hidden fields or different HTTP methods

**Discovery**

```text
curl -sk -i -b cookies.txt http://TARGET:PORT/api/PATH
```

**Interpret:** The actual object, method and writable input are known; returned owner/role fields are only candidate security boundaries.

**Still check:** Determine field binding, ownership, persistence and server authorization with controlled accounts.

**Verify:** Prove which input is consumed and whether state changes persist in an independent read.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/web-mapping/#web-parameters)

### Full procedure and variants

GET parameter names:

```bash
ffuf -w /usr/share/seclists/Discovery/Web-Content/burp-parameter-names.txt -u 'http://TARGET:PORT/PATH?FUZZ=test' -ac -o params-get.json
```

POST form parameter names:

```bash
ffuf -w WORDLIST -u http://TARGET:PORT/PATH -X POST -H 'Content-Type: application/x-www-form-urlencoded' -d 'known=value&FUZZ=test' -ac -o params-post.json
```

Object values with an authenticated API:

```bash
ffuf -w NUMBERS -u 'http://TARGET:PORT/api/objects/FUZZ' -H 'Authorization: Bearer TOKEN' -mc all -fc 404 -o object-values.json
```

> **Decisive output:** a manually reproduced parameter or value that changes application behavior. Tool outliers are candidates, not confirmed access-control flaws.

<details>
<summary><strong>ffuf — preserve a captured authenticated request</strong></summary>

Save a working raw request from the proxy as request.txt, retain its Host/cookie/body, and put FUZZ at the single parameter name/value or path being tested. Replay it once manually first. The request file does not specify TLS: choose the transport explicitly.

```bash
# HTTPS request, including its original method and session headers
ffuf -request request.txt -request-proto https -w WORDLIST -mc all -ac -t 10 -o request-https.json

# Plain HTTP request: otherwise ffuf defaults to HTTPS
ffuf -request request.txt -request-proto http -w WORDLIST -mc all -ac -t 10 -o request-http.json
```

> **Read:** compare an outlier's status/length/body with a known missing value, then replay that exact request. A login redirect for every value → refresh the session before continuing. A one-time CSRF token → repair token handling; the saved-request flag does not refresh it automatically.

[ffuf request configuration](https://github.com/ffuf/ffuf/wiki/Home#request-configuration).

</details>

```bash
curl -ski http://TARGET:PORT/api/v1/PATH
curl -ski -X OPTIONS http://TARGET:PORT/api/v1/PATH
curl -ski -X POST -H 'Content-Type: application/json' -d '{"username":"TEST_USER","password":"TEST_PASSWORD"}' http://TARGET:PORT/api/v1/login
```

> **Interpretation:** `405` can establish that a route exists but rejects the method. Validation errors can reveal required fields. A token establishes only the authorization demonstrated by a later request.

Build a matrix across anonymous, user A, user B and administrator contexts where available:

```text
PATH | METHOD | IDENTITY/ROLE | OBJECT/PROPERTY | RESULT | NEXT
```

### Follow the evidence

- [ Modify a protected property through excessive writable fields](web-exploitation.md#web-mass-assignment) — API objects expose role, ownership or security-sensitive properties Required: The server binds an untrusted property to a persistent security-relevant field without checking permission
- [ Cross an object-ownership boundary](web-exploitation.md#web-idor) — A request selects an object by ID/path and two authorized ownership contexts are available Required: The server accepts a lower-privilege identity's request for an object it should not access
- [ Prove visible or blind operating-system command injection](web-exploitation.md#web-command) — An input appears in a command-like operation or causes shell-dependent behavior Required: Input reaches command execution with an exploitable parsing boundary; process identity/runtime can perform the selected proof
- [ Establish SQL query influence and DBMS context](web-exploitation.md#sql-influence) — Database errors or controlled true/false response differences Required: Input reaches a SQL query; a valid request and stable response baseline exist
- [ Execute browser code and validate a useful same-origin action](web-exploitation.md#web-xss) — Untrusted input reaches an executable HTML/JavaScript context Required: Payload reaches a browser execution sink; any useful privileged action additionally needs a victim context, same-origin access and a valid request state
- [ Use server-side requests to inspect reachable internal behavior](web-exploitation.md#web-ssrf) — URL import, preview, webhook or fetch behavior Required: The application server performs a controllable request; destination/protocol policy and its network position permit the selected resource
## S12

### Map an authentication, session or multistep web flow

**Enter:** the application exposes login, registration, recovery, role change, state-changing business action, authenticated API or another session-dependent flow.

**Discovery**

```text

```

**Interpret:** capture a working anonymous and/or authenticated request, then record method, scheme/host/path, headers, cookies/tokens, body fields, hidden values, redirects, role and each step required to complete the action. Include non-GET/POST methods, JSON/XML bodies and WebSocket/API messages when the application actually uses them.

**Still check:** replay the unchanged request first; then change one identity, object, property or session boundary at a time. Confirm freshness, CSRF/token coupling, object ownership and whether the result is server-side rather than a browser-only presentation change.

**Verify:** preserve one reproducible request/response pair and the exact role/session/object delta. Mapping a field or flow is not itself exploitation.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/reference/02-service-enumeration/10-http-web-mapping/)

### Full procedure and variants

- **Enter:** the application exposes login, registration, recovery, role change, state-changing business action, authenticated API or another session-dependent flow.
- **Discover:** capture a working anonymous and/or authenticated request, then record method, scheme/host/path, headers, cookies/tokens, body fields, hidden values, redirects, role and each step required to complete the action. Include non-GET/POST methods, JSON/XML bodies and WebSocket/API messages when the application actually uses them.
- **Validate:** replay the unchanged request first; then change one identity, object, property or session boundary at a time. Confirm freshness, CSRF/token coupling, object ownership and whether the result is server-side rather than a browser-only presentation change.
- **Execute:** [HTTP and web mapping](https://armaanleg3nd.github.io/oscp/reference/02-service-enumeration/10-http-web-mapping/), then route only the demonstrated effect to the existing parameter, authorization, IDOR, mass-assignment, XSS, parser or command/SQL method.
- **Verify:** preserve one reproducible request/response pair and the exact role/session/object delta. Mapping a field or flow is not itself exploitation.
- **Outcomes:** controlled unauthorized effect → D14 or the matching primitive; invariant authorization/ownership enforcement → ruled out for that transition; token expiry, cache, redirect or client-side behavior masks the result → inconclusive/D31.
- **Source:** [OWASP WSTG entry-point mapping](https://wstg.owasp.org/stable/4-Web_Application_Security_Testing/01-Information_Gathering/06-Identify_Application_Entry_Points/).

### Follow the evidence

