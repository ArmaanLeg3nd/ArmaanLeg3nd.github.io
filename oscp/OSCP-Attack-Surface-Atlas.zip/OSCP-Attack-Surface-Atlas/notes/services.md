# Extract opportunities from services

[Overview](../START.canvas) · [Browser map](../Map.html)

A service can disclose names, files, rights or execution. Test authentication, read, write and execution separately. A write becomes an execution path only when a useful consumer and trigger exist.

## service-ftp

### Use anonymous or authenticated FTP file access

**Enter:** An FTP banner or accessible listing

**Discovery**

```text
curl -v ftp://TARGET/
curl -v --user 'USER:PASSWORD' ftp://TARGET/
```

**Interpret:** A listing identifies candidate artifacts; a completed RETR with recognizable bytes establishes read access.

**Still check:** Validate the account context, file contents, data-channel reachability and any separate write/consumer conditions.

**Verify:** Retrieve recognizable bytes or independently verify an uploaded canary; distinguish listing, read and write rights.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/services/#service-ftp)

### Full procedure and variants

> **Recognize:** FTP usually appears on TCP/21, but trust an FTP banner or protocol response on any port. **Goal:** determine authentication, listable/readable content and effective write locations.

##### Baseline: anonymous access

```bash
ftp TARGET
```

At the prompts, try user `anonymous` and an email-like password. Then:

```text
status
pwd
ls -la
binary
get FILE
quit
```

If login succeeds but listing/transfer fails, use the client's `passive` command to toggle data-channel mode and retry once before changing credentials.

> **Decisive output:** code `230` accepts the login; directory listings and successful `RETR` establish read access. Inspect downloaded backups, configuration, keys and source locally. Store target artifacts outside this public repository.

<details>
<summary><strong>Variant — authenticated FTP</strong></summary>

```bash
ftp TARGET
```

Enter `USER` and the password when prompted. Enumerate from the authenticated root again; it may expose a different namespace than anonymous access.

</details>

<details>
<summary><strong>Variant — curl listing, download and bounded write test</strong></summary>

```bash
curl --list-only ftp://TARGET/
curl -o FILE ftp://TARGET/path/FILE
curl --user USER ftp://TARGET/
curl --user USER -o FILE ftp://TARGET/path/FILE
curl --user USER --upload-file ./probe.txt ftp://TARGET/path/probe.txt
```

Omit `--user` for anonymous access. Let curl prompt for an authenticated password instead of placing it in shell history. Upload only a harmless uniquely named probe when write validation is necessary and authorized; remove it through the FTP client after the test.

</details>

<details>
<summary><strong>Variant — focused Nmap helpers</strong></summary>

```bash
nmap -sV -p PORT --script ftp-anon,ftp-syst TARGET
```

`ftp-anon` checks anonymous login and may flag writable entries; `ftp-syst` asks for server/system information. Manually confirm useful access with a protocol client.

</details>

> **Failure cues:** `530` means that login was rejected, not that FTP has no other usable identity. A listing failure after `230` may be a data-channel/passive-mode or authorization problem. A successful upload proves write access only; it does not prove that a web server, scheduled task or privileged process consumes that file.

> **Next action:** inspect recovered files; record exact read/write boundaries; validate any new credential once against its likely service; send a writable-consumer hypothesis to the appropriate web, execution or privilege-escalation block.

### Follow the evidence

- [ Classify the artifact and its identity context](credentials.md#credential-classify) — A secret-like value, key file, stored hash, challenge response or ticket Required: Artifact provenance and format; possible local/domain/application identity and compatible protocol
- [ Inspect source, backups, configuration and repository artifacts](web-mapping.md#web-artifacts) — JavaScript endpoints, backup names, exposed configuration or Git metadata Required: Readable application artifact or a complete recoverable repository; preserve the public-source scope
- [ Validate known passwords and context-specific reuse](credentials.md#credential-use) — A password tied to a plausible user and service Required: Correct local/domain/application identity, reachable compatible service, accepted authentication and account state
## service-ssh

### Use SSH passwords, keys and forwarding-capable access

**Enter:** An SSH service and a known password, private key or agent context

**Discovery**

```text
ssh -v -p PORT USER@TARGET
ssh -v -i KEY -p PORT USER@TARGET
```

**Interpret:** Accepted key authentication plus a verified shell identity establishes that specific login, not root or unrestricted forwarding.

**Still check:** Check actual account/shell/subsystem and separately inspect forwarding policy if a tunnel is needed.

**Verify:** Run hostname and id in the resulting context; retain whether a shell, SFTP or only forwarding was actually granted.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/services/#service-ssh)

### Full procedure and variants

> **Recognize:** SSH commonly uses TCP/22. **Prerequisite for access:** an accepted authentication method plus a permitted account/session context.

##### Baseline: validate one known identity

```bash
ssh -v -p PORT USER@TARGET
```

> **Decisive output:** the debug trace separates connection, host-key negotiation, offered authentication methods and account acceptance. A shell prompt establishes session access as that identity.

<details>
<summary><strong>Variant — private key</strong></summary>

```bash
chmod 600 KEY
ssh -v -i KEY -p PORT USER@TARGET
```

The key must correspond to an authorized public key for that account. `Permission denied (publickey)` can mean wrong user, wrong key, server policy or account restrictions.

</details>

<details>
<summary><strong>Variant — discover methods for a known username</strong></summary>

```bash
nmap -p PORT --script ssh-auth-methods --script-args "ssh.user=USER" TARGET
```

This starts an authentication exchange and is logged; Nmap classifies it as intrusive. Use it only when the supported methods change the next decision.

</details>

<details>
<summary><strong>Variant — non-interactive key check</strong></summary>

```bash
ssh -o BatchMode=yes -o ConnectTimeout=5 -i KEY -p PORT USER@TARGET 'id'
```

Batch mode will not prompt for passwords or key passphrases. It is useful only when the key is already usable non-interactively.

</details>

> **Failure cues:** timeout suggests route/filtering/service issues; refusal means no accepting listener in that context; host-key failure occurs before user authentication; `Permission denied` proves that the attempted method/context failed, not that every credential is invalid. A valid account may still have no shell or be restricted by server policy.

> **Next action:** after a shell, verify `whoami`, groups, hostname and addresses, then re-enumerate locally. Password spraying and key-passphrase cracking belong to the credential-attack block, not this procedure.

### Follow the evidence

- [ Establish Linux state and choose an escalation candidate](linux-privesc.md#linux-state) — A new Linux foothold or an identity/privilege change Required: A working command channel and accurate effective identity, group, mount and process context
- [ Inspect and recover SSH private-key access](credentials.md#ssh-key) — A private key from a file read, share, repository or home directory Required: Correct key format, passphrase if encrypted, matching server account/key authorization and accepted algorithm/policy
- [ Forward a selected service through an SSH client-side listener](pivoting.md#ssh-local) — SSH reaches a server that can access the needed internal service Required: Accepted SSH identity and forwarding policy; local listener availability and SSH-server-to-destination route
## service-smtp

### Enumerate SMTP identities and accessible mailbox protocols

**Enter:** SMTP capabilities or mail-related account clues

**Discovery**

```text
nc -nv TARGET 25

EHLO example.invalid
VRFY USER
VRFY INVALID_CONTROL
QUIT
```

**Interpret:** A reproducible reply difference can expose a possible mailbox identity.

**Still check:** Check catch-all policy and account context; recipient acceptance does not prove mailbox credentials or OS access.

**Verify:** Record response/control differences and separate inferred account existence from successful mailbox authentication.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/services/#service-smtp)

### Full procedure and variants

> **Recognize:** SMTP commonly uses TCP/25, submission uses 587, and implicit TLS commonly uses 465. **Goal:** collect banner/capabilities, mail-domain clues and only defensible user evidence.

##### Baseline: banner and capabilities

```bash
nc -nv TARGET PORT
```

Then enter:

```text
EHLO example.invalid
HELP
VRFY USER
EXPN postmaster
QUIT
```

> **Decisive output:** `250-` capability lines reveal extensions such as STARTTLS or AUTH. `250` after `VRFY` may support a valid mailbox; `550` commonly rejects or denies it; `252` explicitly means the server will not verify and is not proof that the user exists.

<details>
<summary><strong>Variant — STARTTLS or implicit TLS</strong></summary>

```bash
openssl s_client -connect TARGET:587 -starttls smtp -crlf -quiet
openssl s_client -connect TARGET:465 -crlf -quiet
```

Run `EHLO example.invalid` after TLS negotiation. Certificate names and capabilities can yield host/domain clues; authentication still requires a supported identity and mechanism.

</details>

<details>
<summary><strong>Variant — focused automated user checks</strong></summary>

```bash
smtp-user-enum -M VRFY -U users.txt -t TARGET -p PORT
smtp-user-enum -M RCPT -U users.txt -t TARGET -p PORT
```

`RCPT` testing requires an SMTP transaction and servers may deliberately normalize responses. Treat automation as candidate generation and manually compare decisive responses.

</details>

<details>
<summary><strong>Variant — Windows source position</strong></summary>

```powershell
Test-NetConnection -ComputerName TARGET -Port PORT
```

This verifies TCP reachability only. Use an available Netcat/Ncat or OpenSSL client for protocol dialogue.

</details>

> **Failure cues:** multiline replies begin with `NNN-` and finish with `NNN `; read the final line. `503` often means the command sequence is wrong. Uniform `252` or `550` responses make enumeration inconclusive. A visible AUTH method does not mean anonymous relay or valid credentials.

> **Next action:** add confirmed/candidate names and domains to the private evidence ledger; test new names only in the later credential block. Do not send real mail or run relay checks unless the objective requires it.

##### POP3 and IMAP handoff

Mail-access services expose mailbox capabilities and, with legitimate credentials, stored messages that may contain workflow or reset links.

```bash
openssl s_client -connect TARGET:995 -crlf -quiet   # POP3S
openssl s_client -connect TARGET:993 -crlf -quiet   # IMAPS
```

POP3 dialogue:

```text
CAPA
USER USER
PASS PASSWORD
STAT
LIST
QUIT
```

IMAP dialogue:

```text
a1 CAPABILITY
a2 LOGIN USER PASSWORD
a3 LIST "" "*"
a4 LOGOUT
```

> Test one legitimately acquired credential. Capability output is not authentication; avoid brute-force NSE scripts until lockout/authorization is explicitly understood. Source supplement: reviewed getSH Nmap mail blocks.

### Follow the evidence

- [ Validate known passwords and context-specific reuse](credentials.md#credential-use) — A password tied to a plausible user and service Required: Correct local/domain/application identity, reachable compatible service, accepted authentication and account state
- [ Expand names through DNS records and zone transfers](services.md#service-dns) — A DNS server, domain name or host aliases Required: Reachable DNS transport and relevant authoritative zone; AXFR requires an allowed TCP zone transfer
- [ Enumerate SMB/RPC shares, files and identities](services.md#service-smb) — SMB/RPC endpoints, domain clues or new credentials Required: Reachable SMB/RPC; anonymous, guest, local or domain context must be explicit; share and filesystem ACLs both matter
## service-dns

### Expand names through DNS records and zone transfers

**Enter:** A DNS server, domain name or host aliases

**Discovery**

```text
dig @TARGET DOMAIN SOA
dig @TARGET DOMAIN NS
dig @TARGET DOMAIN AXFR
```

**Interpret:** An authoritative zone and returned records can expose hostnames, aliases and applications needing separate enumeration.

**Still check:** Check each new name's scope/address and verify host/virtual-host behavior.

**Verify:** Identify responding server, record type, answer and zone authority; transfer refusal disproves only that transfer/context.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/services/#service-dns)

### Full procedure and variants

> **Recognize:** DNS uses UDP/53 for most queries and TCP/53 for operations including conventional zone transfers and oversized responses. **Prerequisite:** a known or inferred domain for meaningful record and name enumeration.

##### Baseline: query the target DNS server directly

```bash
dig @TARGET DOMAIN SOA
dig @TARGET DOMAIN NS
dig @TARGET DOMAIN A
dig @TARGET DOMAIN MX
dig @TARGET DOMAIN TXT
```

> **Decisive output:** `ANSWER` records disclose names, addresses, mail exchangers or text. The `aa` flag supports an authoritative answer. Record `status` separately from the answer count.

<details>
<summary><strong>Variant — reverse lookup and zone transfer</strong></summary>

```bash
dig @TARGET -x IP
dig @TARGET DOMAIN AXFR
```

A successful AXFR returns the zone records and closing SOA. `Transfer failed`, `REFUSED` or `NOTAUTH` only disproves an unauthenticated transfer from this source; continue ordinary queries.

</details>

<details>
<summary><strong>Variant — name guessing after the domain is known</strong></summary>

```bash
dnsrecon -d DOMAIN -n TARGET -t std
dnsrecon -d DOMAIN -n TARGET -D WORDLIST -t brt
dnsenum --dnsserver TARGET DOMAIN
```

Check wildcard behavior before trusting large result sets. Every resolved in-scope name becomes a new discovery/service-enumeration input.

</details>

<details>
<summary><strong>Variant — reverse sweep of an explicitly assigned range</strong></summary>

```bash
dnsrecon -r SUBNET -n TARGET
```

Use this only when the entire `SUBNET` is assigned. PTR names are clues; resolve/scan only in-scope results.

</details>

<details>
<summary><strong>Variant — host and Windows nslookup</strong></summary>

```bash
host -t mx DOMAIN TARGET
host -t txt DOMAIN TARGET
```

```powershell
nslookup HOST.DOMAIN TARGET
nslookup -type=TXT HOST.DOMAIN TARGET
nslookup -type=MX DOMAIN TARGET
```

</details>

> **Failure cues:** `NXDOMAIN` means that queried name does not exist in that view; `NOERROR` with no answer can mean the name exists but lacks that record type. Timeout can be filtering, loss or a silent/unreachable server. A recursive answer does not establish that the server is authoritative.

> **Next action:** add new hostnames/IPs to the scoped queue, correlate naming roles with observed services, and repeat discovery/service identification for those in-scope endpoints.

### Follow the evidence

- [ Validate the source path and discover hosts](discovery.md#path-hosts) — No response, a new subnet, or uncertainty about the interface and route Required: Correct VPN/interface and explicit scope; discovery probes must be compatible with the path
- [ Discover virtual hosts and hostname-selected applications](web-mapping.md#web-vhosts) — DNS names, redirects, certificate names or a default virtual-host response Required: A destination listener, relevant domain candidates and controlled Host/SNI routing
- [ Establish domain identity, DC, DNS, time and route](ad-mapping.md#domain-state) — Domain credentials or a domain-joined foothold Required: Correct realm/domain and account qualification; reachable DC/services, usable DNS and acceptable clock skew
## service-nfs

### Inspect RPC/NFS exports and effective file identity

**Enter:** RPC/NFS listeners or export information

**Discovery**

```text
rpcinfo -p TARGET
showmount -e TARGET
```

**Interpret:** An export lists a filesystem candidate and client policy; it does not establish file access or trusted UID 0.

**Still check:** Use the owning procedure to verify NFS version, allowed client, numeric identity mapping, read/write and squash/mount policy.

**Verify:** Verify the export, mapped identity, actual bytes and any created file's server-side ownership.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/services/#service-nfs)

### Full procedure and variants

> **Recognize:** rpcbind commonly appears on TCP/UDP 111 and NFS on TCP/UDP 2049, with additional dynamically assigned RPC ports. **Goal:** find exports, allowed client ranges and effective UID/GID-based permissions.

##### Baseline: list RPC services and exports

```bash
rpcinfo -p TARGET
showmount -e TARGET
```

> **Decisive output:** `rpcinfo` maps RPC programs to versions/transports/ports. `showmount -e` returns exports and apparent allowed clients, but NFSv4-only servers may not expose the mount service and `showmount` completeness varies by implementation.

<details>
<summary><strong>Variant — Nmap without mounting</strong></summary>

```bash
nmap -sV -p 111,2049 --script nfs-showmount,nfs-ls,nfs-statfs TARGET
```

The scripts can list exports, file attributes and access flags. Confirm access manually when a finding matters.

</details>

<details>
<summary><strong>Variant — mount read-only first</strong></summary>

```bash
sudo mkdir -p /mnt/nfs-audit
sudo mount -t nfs -o ro,vers=3,nolock TARGET:/EXPORT /mnt/nfs-audit
find /mnt/nfs-audit -maxdepth 3 -ls
sudo umount /mnt/nfs-audit
```

If version 3 fails and version 4 is advertised, retry with `-o ro,vers=4`. NFSv4 may present a pseudo-filesystem whose export path differs from `showmount` output.

</details>

<details>
<summary><strong>Variant — inspect numeric ownership</strong></summary>

```bash
ls -lan /mnt/nfs-audit
find /mnt/nfs-audit -maxdepth 3 -type f -readable -ls
```

NFS commonly authorizes Unix identities by numeric UID/GID. A matching local username is irrelevant if its number differs. `root_squash` usually maps remote UID 0 to an unprivileged identity; `no_root_squash` is dangerous but still requires a useful writable object and privileged consumption path.

</details>

<details>
<summary><strong>Variant — bounded write verification</strong></summary>

```bash
sudo mount -t nfs -o rw,vers=3,nolock TARGET:/EXPORT /mnt/nfs-audit
touch /mnt/nfs-audit/probe-file
ls -ln /mnt/nfs-audit/probe-file
rm /mnt/nfs-audit/probe-file
sudo umount /mnt/nfs-audit
```

Use a unique harmless name only when write validation is needed and authorized. Record the resulting numeric owner/group. Success proves write in that directory, not execution or privileged ownership.

</details>

> **Failure cues:** `showmount` failure does not rule out NFSv4. `access denied by server` can mean export client restrictions or wrong path/version. `permission denied` after mounting is file authorization, not network failure. Do not change local UIDs or write to an export during concept study.

> **Next action:** inspect readable backups, home data, keys and configuration; record numeric ownership and actual write boundaries; send a writable/privileged-consumer hypothesis to the escalation block.

##### Rsync daemon — list modules before copying

> **Recognize:** an rsync daemon normally listens on TCP/873, although the application can use another port. The daemon namespace uses `HOST::MODULE` or `rsync://HOST/MODULE`; a single colon is SSH/remote-shell syntax and is a different access path.

```bash
nmap -sV -p 873 --script rsync-list-modules TARGET
rsync rsync://TARGET/
rsync --list-only rsync://TARGET/MODULE/
```

> **Decisive output:** a named module and a file listing establish only that the current anonymous or supplied account can enumerate that namespace. Read access is proven by retrieving selected bytes, not by the module name.

<details>
<summary><strong>Variant — retrieve a selected file or a reviewed module</strong></summary>

```bash
# One selected artifact
rsync -av rsync://TARGET/MODULE/path/FILE ./FILE

# A reviewed module into a dedicated local evidence directory
mkdir -p ./rsync-MODULE
rsync -av --safe-links rsync://TARGET/MODULE/ ./rsync-MODULE/
```

`--safe-links` ignores symbolic links that point outside the copied tree. Review module size and content first; do not mirror a large tree by default. If authentication is required, let rsync prompt or use a protected `--password-file` rather than putting a password on the command line.

</details>

> **Failure cues:** no listed modules can mean the daemon hides its module list; `@ERROR: auth failed` is an authentication boundary; `@ERROR: Unknown module` is a namespace error; a listed module can still deny individual reads or writes.
>
> **Next action:** inspect selected readable backups, keys, source and configuration locally. Treat a writable module as file placement only until a specific consumer, destination identity and trigger are proven. Do not use `--delete` against a remote module during enumeration.

##### TFTP — known-name retrieval only

> **Recognize:** TFTP normally uses UDP/69 for the initial request and has no directory-listing or login model. It is useful only when configuration, source, boot metadata or another service gives a plausible filename.

```text
tftp TARGET
tftp> binary
tftp> get FILE
tftp> quit
```

> **Decisive output:** a completed transfer plus recognizable local bytes establishes read access to that exact name. A timeout is ambiguous because the UDP request, server policy, transfer port or filename can fail without a useful error.

<details>
<summary><strong>Variant — bounded write check only when the objective requires it</strong></summary>

```bash
printf '%s\n' 'TFTP_WRITE_CANARY' > tftp-probe.txt
```

```text
tftp TARGET
tftp> binary
tftp> put tftp-probe.txt
tftp> quit
```

Use a unique harmless filename and only when write capability changes the next decision. TFTP normally offers no remote delete operation; do not create a probe unless you already have an authorized cleanup route.

</details>

> **Next action:** inspect a retrieved artifact and follow only evidence-backed filenames. A successful upload is not execution; prove the server-side path and consumer separately.

### Follow the evidence

- [ Classify the artifact and its identity context](credentials.md#credential-classify) — A secret-like value, key file, stored hash, challenge response or ticket Required: Artifact provenance and format; possible local/domain/application identity and compatible protocol
- [ Exploit a permission-backed mount, NFS mapping or local service](linux-privesc.md#linux-mounts) — A writable/exported filesystem or a loopback-only service with useful privileges Required: Relevant export/mount options or service authentication; effective identity, writable path and any privileged execution consumer
- [ Transfer over HTTP using Linux or Windows clients](sessions-transfers.md#transfer-http) — A tool/artifact must reach a target that can make an HTTP request Required: Correct server bind and served directory; target-to-server route, available downloader and writable destination
## service-rsync

### Inspect rsync modules and retrieve selected artifacts

**Enter:** An rsync daemon banner, TCP/873 listener or disclosed rsync module

**Discovery**

```text
nmap -sV -p 873 --script rsync-list-modules TARGET
rsync rsync://TARGET/
rsync --list-only rsync://TARGET/MODULE/
```

**Interpret:** A visible module and file listing identify an rsync namespace; they do not establish write or execution.

**Still check:** Retrieve one selected file and verify its bytes; record anonymous or supplied-account context.

**Verify:** Verify the module, authentication context, path and retrieved bytes; do not infer write or execution from a visible name.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/services/#service-rsync)

### Full procedure and variants

> **Recognize:** an rsync daemon normally listens on TCP/873, although the application can use another port. The daemon namespace uses `HOST::MODULE` or `rsync://HOST/MODULE`; a single colon is SSH/remote-shell syntax and is a different access path.

```bash
nmap -sV -p 873 --script rsync-list-modules TARGET
rsync rsync://TARGET/
rsync --list-only rsync://TARGET/MODULE/
```

> **Decisive output:** a named module and a file listing establish only that the current anonymous or supplied account can enumerate that namespace. Read access is proven by retrieving selected bytes, not by the module name.

<details>
<summary><strong>Variant — retrieve a selected file or a reviewed module</strong></summary>

```bash
# One selected artifact
rsync -av rsync://TARGET/MODULE/path/FILE ./FILE

# A reviewed module into a dedicated local evidence directory
mkdir -p ./rsync-MODULE
rsync -av --safe-links rsync://TARGET/MODULE/ ./rsync-MODULE/
```

`--safe-links` ignores symbolic links that point outside the copied tree. Review module size and content first; do not mirror a large tree by default. If authentication is required, let rsync prompt or use a protected `--password-file` rather than putting a password on the command line.

</details>

> **Failure cues:** no listed modules can mean the daemon hides its module list; `@ERROR: auth failed` is an authentication boundary; `@ERROR: Unknown module` is a namespace error; a listed module can still deny individual reads or writes.
>
> **Next action:** inspect selected readable backups, keys, source and configuration locally. Treat a writable module as file placement only until a specific consumer, destination identity and trigger are proven. Do not use `--delete` against a remote module during enumeration.

### Follow the evidence

- [ Classify the artifact and its identity context](credentials.md#credential-classify) — A secret-like value, key file, stored hash, challenge response or ticket Required: Artifact provenance and format; possible local/domain/application identity and compatible protocol
- [ Transfer over HTTP using Linux or Windows clients](sessions-transfers.md#transfer-http) — A tool/artifact must reach a target that can make an HTTP request Required: Correct server bind and served directory; target-to-server route, available downloader and writable destination
- [ Use SSH passwords, keys and forwarding-capable access](services.md#service-ssh) — An SSH service and a known password, private key or agent context Required: Compatible authentication method, correct user, accepted key policy and the requested shell/subsystem permission
## service-tftp

### Retrieve an evidence-backed file over TFTP

**Enter:** A UDP/69 service plus a plausible filename from configuration, source or boot metadata

**Discovery**

```text
tftp TARGET
tftp> binary
tftp> get FILE
tftp> quit
```

**Interpret:** The exact known filename is retrievable; TFTP still exposes no general directory namespace.

**Still check:** Verify recognizable bytes and provenance; distinguish read from any separately required write test.

**Verify:** Verify the local file's recognizable bytes and provenance; a client success message without the expected file is insufficient.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/services/#service-tftp)

### Full procedure and variants

> **Recognize:** TFTP normally uses UDP/69 for the initial request and has no directory-listing or login model. It is useful only when configuration, source, boot metadata or another service gives a plausible filename.

```text
tftp TARGET
tftp> binary
tftp> get FILE
tftp> quit
```

> **Decisive output:** a completed transfer plus recognizable local bytes establishes read access to that exact name. A timeout is ambiguous because the UDP request, server policy, transfer port or filename can fail without a useful error.

<details>
<summary><strong>Variant — bounded write check only when the objective requires it</strong></summary>

```bash
printf '%s\n' 'TFTP_WRITE_CANARY' > tftp-probe.txt
```

```text
tftp TARGET
tftp> binary
tftp> put tftp-probe.txt
tftp> quit
```

Use a unique harmless filename and only when write capability changes the next decision. TFTP normally offers no remote delete operation; do not create a probe unless you already have an authorized cleanup route.

</details>

> **Next action:** inspect a retrieved artifact and follow only evidence-backed filenames. A successful upload is not execution; prove the server-side path and consumer separately.

### Follow the evidence

- [ Classify the artifact and its identity context](credentials.md#credential-classify) — A secret-like value, key file, stored hash, challenge response or ticket Required: Artifact provenance and format; possible local/domain/application identity and compatible protocol
- [ Transfer over HTTP using Linux or Windows clients](sessions-transfers.md#transfer-http) — A tool/artifact must reach a target that can make an HTTP request Required: Correct server bind and served directory; target-to-server route, available downloader and writable destination
- [ Match a public exploit to the actual component and configuration](public-exploits.md#exploit-select) — A product/version clue, advisory or component-specific public PoC Required: Exact vulnerable build/configuration, required access and endpoint behavior; reviewable source and a verifiable expected effect
## service-smb

### Enumerate SMB/RPC shares, files and identities

**Enter:** SMB/RPC endpoints, domain clues or new credentials

**Discovery**

```text
smbclient -L //TARGET -N
smbclient -L //TARGET -U 'DOMAIN/USER'
```

**Interpret:** A share name supplies a filesystem investigation target; listing it does not prove read, write or service creation.

**Still check:** Connect to the named share under the identity that listed it, then ls/get the exact object. Listing a share does not prove read or write. For a write candidate, verify the path operation and identify a separate execution consumer before treating it as access.

**Verify:** Prove the specific share/object action; a successful login or administrative indicator does not establish every remote-execution route.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/services/#service-smb)

### Full procedure and variants

> **Recognize:** direct-hosted SMB commonly uses TCP/445; NetBIOS session service commonly uses TCP/139; MS-RPC endpoint mapping commonly uses TCP/135. They are related Windows surfaces but not interchangeable. **Goal:** distinguish null, guest and authenticated contexts; enumerate shares, files, users, groups, domain/workgroup clues and actual permissions.

##### Baseline: list shares without credentials

```bash
smbclient -N -L //TARGET
```

> **Decisive output:** a share list proves that this access context can enumerate names. It does not prove access to share contents. `NT_STATUS_ACCESS_DENIED` means this context was denied; repeat after obtaining a legitimate credential.

<details>
<summary><strong>Variant — authenticated share listing and connection</strong></summary>

```bash
smbclient -L //TARGET -U 'DOMAIN/USER'
smbclient //TARGET/SHARE -U 'DOMAIN/USER'
smbclient -L //TARGET -U 'TARGET/USER'
smbclient -L //TARGET -U 'guest%'
```

The first two forms use a domain identity, the third makes a local target account explicit, and the fourth tests a guest account with an empty password. Let the client prompt for non-empty passwords. Inside the share:

```text
pwd
ls
allinfo FILE
get FILE
mkdir probe-dir
rmdir probe-dir
exit
```

Use a harmless uniquely named directory only when write permission must be verified. A successful create/remove establishes share-level write access, not code execution.

</details>

<details>
<summary><strong>Variant — recursive retrieval</strong></summary>

```bash
smbclient //TARGET/SHARE -U 'DOMAIN/USER' -c 'recurse ON;prompt OFF;mget *'
```

Run from a dedicated local evidence directory and review expected volume first. Search downloaded configuration, scripts, backups, keys and unattended-install files locally; never publish recovered data.

</details>

<details>
<summary><strong>Variant — RPC null or authenticated session</strong></summary>

```bash
rpcclient -U '' -N TARGET
rpcclient -U 'DOMAIN/USER' TARGET
```

Useful interactive queries:

```text
srvinfo
enumdomains
enumdomusers
enumdomgroups
queryuser RID
netshareenumall
quit
```

Null-session denial is common on modern systems. Authenticated output must be labelled with the identity that produced it.

</details>

<details>
<summary><strong>Variant — fast permission summary and consolidated candidates</strong></summary>

```bash
nxc smb TARGET -u USER -p PASSWORD --shares
enum4linux-ng -A TARGET
```

NetExec (`nxc`) is the current command name on recent Kali releases; older material may use `crackmapexec`. These tools consolidate candidates. Confirm useful shares and files with `smbclient` or native access.

</details>

<details>
<summary><strong>Variant — protocol, signing and time clues</strong></summary>

```bash
nmap -p 139,445 --script smb-protocols,smb2-security-mode,smb2-time TARGET
```

Signing and dialect results affect later relay/exploit decisions but are not vulnerabilities by themselves. The older `smb-os-discovery` script depends on SMBv1 behavior and may not identify modern hosts reliably.

</details>

<details>
<summary><strong>Variant — Windows built-ins</strong></summary>

```powershell
net view \\TARGET /all
Get-ChildItem \\TARGET\SHARE
Get-Content \\TARGET\SHARE\FILE
```

These use the current Windows logon context unless alternate credentials or mappings are established. An existing connection to the same server under another identity can cause credential-conflict errors.

</details>

<details>
<summary><strong>SMBMap — map rights, then read one useful file</strong></summary>

Use from Kali when SMB is reachable. Choose the same domain/local identity that worked with smbclient. Suppress write probes when inventorying reads; this means a writable label is not being tested here.

```bash
# Known domain account: enumerate share access without creating a probe file
smbmap -H TARGET -d DOMAIN -u USER -p 'PASSWORD' --no-write-check

# Inspect the selected share to a bounded depth
smbmap -H TARGET -d DOMAIN -u USER -p 'PASSWORD' -r 'SHARE' --depth 2 --no-write-check

# Download the specific file found above
smbmap -H TARGET -d DOMAIN -u USER -p 'PASSWORD' --download 'SHARE\PATH\FILE' --no-write-check
```

> **Read:** a listed file must still be readable under this identity. A downloaded config/backup → classify its credential material, then test only the relevant account/service. A denied share → try another listed share or a newly obtained identity; do not infer a host-wide denial.

[SMBMap upstream](https://github.com/ShawnDEvans/smbmap). For broader SMB/RPC collection, use the existing enum4linux-ng baseline; authenticate explicitly when credentials exist:

```bash
# No credentials: anonymous RPC/SMB candidates
enum4linux-ng -A TARGET

# Known identity: domain objects visible to this account
enum4linux-ng -A -w DOMAIN -u USER -p 'PASSWORD' TARGET
```

> **Next:** validate returned users/groups/shares with rpcclient or smbclient. A collector can return partial data despite a successful login.

</details>

> **Failure cues:** distinguish connection failure, authentication failure, share enumeration denial and file authorization denial. A share named `IPC$` is not a general file share. Guest acceptance may look like success while returning a restricted namespace. A share marked writable still needs a consumer/trigger before it becomes an execution path.

> **Next action:** inspect readable content, record per-share rights, validate names/domain clues, and re-run authenticated enumeration whenever identity changes. Move file-consumer hypotheses to web/execution/escalation and signing/relay hypotheses to the later credential/AD blocks.

##### NetBIOS names before SMB enumeration

Use when UDP/137 or SMB suggests Windows names but DNS/domain identity is unclear.

```bash
# Ask the assigned host for its NetBIOS names
nbtscan TARGET
nmblookup -A TARGET
```

Read: a machine name and group/domain label are leads. A workgroup label does not prove AD membership. Resolve the returned name and use the SMB/LDAP checks with the accepted identity. No reply can mean filtering or disabled NetBIOS while TCP/445 still works.

Sources: [upstream 1](https://www.kali.org/tools/nbtscan/).

##### SMB/RPC RID lookups when a normal user listing is denied

Use when the accepted identity can translate SIDs but cannot list the directory directly. Keep the queried host/domain and a bounded RID range explicit.

```bash
nxc smb TARGET -d DOMAIN -u USER -p 'PASSWORD' --rid-brute 4000
```

Read: classify returned SID types—users, groups and machine accounts are different objects. The upper bound is coverage, not proof that higher RIDs contain nothing. A resolved name is not a password, service authorization or successful logon. Prefer the existing native directory/RPC listing when it is available; do not infer no accounts from a single denied enumeration method.

Sources: [upstream 1](https://www.netexec.wiki/smb-protocol/enumeration/enumerate-users-by-bruteforcing-rid).

### Follow the evidence

- [ Classify the artifact and its identity context](credentials.md#credential-classify) — A secret-like value, key file, stored hash, challenge response or ticket Required: Artifact provenance and format; possible local/domain/application identity and compatible protocol
- [ Read domain shares, SYSVOL and NETLOGON for useful artifacts](ad-mapping.md#domain-shares) — A valid domain identity and accessible file services Required: Reachable SMB plus share/object read rights in the chosen identity context
- [ Execute through uploaded service creation using PsExec](lateral-movement.md#move-services) — A destination grants administrative-share write and service-control rights Required: SMB/SCM reachability, writable required share, effective service-creation/start rights and an accepted password/hash or supported Kerberos context
## service-snmp

### Extract configuration and process information through SNMP

**Enter:** UDP/161 evidence or an exposed management plane

**Discovery**

```text
snmpwalk -v2c -c COMMUNITY TARGET 1.3.6.1.2.1.1
```

**Interpret:** A real OID response confirms the accepted read context and supplies software/name clues.

**Still check:** Determine which useful views/branches are actually readable; process data and write rights are separate.

**Verify:** Preserve the OID, accepted security context and returned value; empty branches can reflect view restrictions.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/services/#service-snmp)

### Full procedure and variants

> **Recognize:** SNMP queries commonly use UDP/161. Versions 1 and 2c authenticate with a community string sent without modern transport protection; version 3 can provide user-based authentication and privacy. **Goal:** turn a valid read context into host, interface, route, process, software, user and listener clues.

##### Baseline: find a read community, then walk

```bash
onesixtyone -c COMMUNITY_FILE TARGET
snmpwalk -v2c -c COMMUNITY TARGET 1.3.6.1.2.1
```

Use `-v1` instead when version 1 is indicated. Start with the standard system tree before a huge full walk.

> **Decisive output:** returned OID/value pairs prove that the selected version/community can read those objects. Hostnames, interfaces, routes, users, processes and locally listening ports become new hypotheses to validate through the appropriate service or post-access path.

<details>
<summary><strong>Variant — efficient v2c bulk walk</strong></summary>

```bash
snmpbulkwalk -v2c -c COMMUNITY TARGET 1.3.6.1.2.1
```

Bulk requests reduce round trips but require SNMPv2c or later. If the agent rejects them, fall back to `snmpwalk` with the verified version.

</details>

<details>
<summary><strong>Variant — high-value Windows OIDs</strong></summary>

```bash
snmpwalk -v1 -c COMMUNITY TARGET 1.3.6.1.4.1.77.1.2.25
snmpwalk -v1 -c COMMUNITY TARGET 1.3.6.1.2.1.25.4.2.1.2
snmpwalk -v1 -c COMMUNITY TARGET 1.3.6.1.2.1.25.6.3.1.2
snmpwalk -v1 -c COMMUNITY TARGET 1.3.6.1.2.1.6.13.1.3
```

These target user names, running process names, installed software and TCP listener ports. Availability depends on the agent and exposed MIB view.

</details>

<details>
<summary><strong>Variant — SNMPv3 authenticated and private walk</strong></summary>

```bash
snmpwalk -v3 -l authPriv -u USER -a SHA -A AUTH_PASSWORD -x AES -X PRIV_PASSWORD TARGET 1.3.6.1.2.1
```

The security level, authentication algorithm, privacy algorithm and credentials must match the configured SNMPv3 user. `authNoPriv` authenticates without encryption; `noAuthNoPriv` supplies neither and should be used only when that exact configuration is observed.

</details>

<details>
<summary><strong>Variant — focused UDP verification</strong></summary>

```bash
sudo nmap -sU -sV -p 161 --script snmp-info TARGET
```

`snmp-info` extracts basic SNMPv3 engine information without proving a usable v1/v2c community.

</details>

> **Failure cues:** UDP silence can remain `open|filtered`; it does not prove that the community is wrong. `Timeout: No Response` can be version mismatch, wrong community, filtering, loss or an unavailable OID view. `No Such Object` means the queried OID is absent/not exposed, not that the whole service failed. Do not use a discovered write community to change configuration during enumeration.

> **Next action:** translate output into exact host/service/user hypotheses, scan newly disclosed in-scope addresses/listeners from the proper source position, and keep configuration-changing SNMP actions outside this stage.

### Follow the evidence

- [ Validate the source path and discover hosts](discovery.md#path-hosts) — No response, a new subnet, or uncertainty about the interface and route Required: Correct VPN/interface and explicit scope; discovery probes must be compatible with the path
- [ Classify the artifact and its identity context](credentials.md#credential-classify) — A secret-like value, key file, stored hash, challenge response or ticket Required: Artifact provenance and format; possible local/domain/application identity and compatible protocol
- [ Match a public exploit to the actual component and configuration](public-exploits.md#exploit-select) — A product/version clue, advisory or component-specific public PoC Required: Exact vulnerable build/configuration, required access and endpoint behavior; reviewable source and a verifiable expected effect
## service-mysql

### Use MySQL/MariaDB data and file primitives

**Enter:** A MySQL-compatible service and valid application/database credentials

**Discovery**

```text
SELECT USER(),CURRENT_USER(),VERSION();
SHOW GRANTS;
SHOW VARIABLES LIKE 'secure_file_priv';
```

**Interpret:** SELECT permits data investigation; absent FILE/admin rights and the restricted directory constrain file/OS hypotheses.

**Still check:** Check exact grants, useful tables, destination OS permissions and an execution consumer before escalating a file operation.

**Verify:** Check current database identity, grants and actual returned data or written file through an independent observation.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/services/#service-mysql)

### Full procedure and variants

```bash
mysql -h TARGET -P PORT -u USER -p
```

```sql
SELECT VERSION(), USER(), CURRENT_USER();
SHOW DATABASES;
SHOW GRANTS;
USE DATABASE;
SHOW TABLES;
DESCRIBE TABLE;
SELECT * FROM TABLE LIMIT 20;
SELECT @@secure_file_priv;
```

> **Interpret:** `USER()` shows the presented client identity; `CURRENT_USER()` shows the account used for privilege checking. `secure_file_priv` restricts server-side import/export: a directory constrains it, an empty value is unrestricted by that variable, and `NULL` disables these operations. The `FILE` privilege is still required.

<details>
<summary><strong>MySQL variant — validate server-side file read/write prerequisites</strong></summary>

```sql
SELECT LOAD_FILE('/path/on/database/server');
SELECT 'probe' INTO OUTFILE '/allowed/server/path/probe.txt';
```

Use only an authorized harmless path. `LOAD_FILE` returning `NULL` is ambiguous among missing file, permissions, size, FILE privilege and `secure_file_priv`. `INTO OUTFILE` will not overwrite an existing file. A written file becomes execution only if another privileged component consumes it.

</details>

### Follow the evidence

- [ Classify the artifact and its identity context](credentials.md#credential-classify) — A secret-like value, key file, stored hash, challenge response or ticket Required: Artifact provenance and format; possible local/domain/application identity and compatible protocol
- [ Convert database rights into a file or operating-system effect](web-exploitation.md#sql-os) — Confirmed SQL control plus database file, execution or impersonation privileges Required: DBMS-specific privilege and enabled facility; OS service identity, writable/readable destination and a compatible consumer
- [ Execute an uploaded file through a compatible handler](web-exploitation.md#web-upload-exec) — Uploads are retrievable and the application stack suggests an executable file handler Required: Controlled executable content survives validation; final storage/URL is handled by the compatible interpreter; process execution is permitted
## service-mssql

### Use SQL Server rights, impersonation and command facilities

**Enter:** SQL Server credentials or a Windows identity accepted by the database

**Discovery**

```text
SELECT SYSTEM_USER, ORIGINAL_LOGIN(), @@VERSION;
SELECT IS_SRVROLEMEMBER('sysadmin');
```

**Interpret:** A valid login with sysadmin=0 is data/rights evidence, not permission to enable xp_cmdshell.

**Still check:** Enumerate actual database/server grants and useful impersonation; independently verify any OS facility and its identity.

**Verify:** Verify SQL identity and any OS effect with hostname/whoami; record service/proxy execution identity.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/services/#service-mssql)

### Full procedure and variants

```bash
impacket-mssqlclient 'USER@TARGET'
impacket-mssqlclient 'DOMAIN/USER@TARGET' -windows-auth
```

Let the tool prompt for the password. At the SQL prompt:

```sql
SELECT @@VERSION;
SELECT SYSTEM_USER;
SELECT IS_SRVROLEMEMBER('sysadmin');
SELECT name FROM sys.databases;
USE DATABASE;
SELECT TABLE_SCHEMA, TABLE_NAME FROM INFORMATION_SCHEMA.TABLES;
SELECT TOP 20 * FROM SCHEMA.TABLE;
```

> **Interpret:** `IS_SRVROLEMEMBER('sysadmin')` returns `1`, `0` or `NULL`; `NULL` is not success. Impacket also exposes helpers such as `enum_impersonate` and `xp_cmdshell` depending on version and rights.

<details>
<summary><strong>MSSQL variant — command-execution boundary</strong></summary>

```sql
EXEC xp_cmdshell 'whoami';
```

`xp_cmdshell` is disabled by default on new installations. Enabling it generally requires high privilege and changes server configuration; do not enable it merely to enumerate. When available, a sysadmin's child process normally runs as the SQL Server service account; an authorized non-sysadmin may use a configured proxy. Verify returned identity before choosing the next action.

</details>

### Follow the evidence

- [ Convert database rights into a file or operating-system effect](web-exploitation.md#sql-os) — Confirmed SQL control plus database file, execution or impersonation privileges Required: DBMS-specific privilege and enabled facility; OS service identity, writable/readable destination and a compatible consumer
- [ Classify the artifact and its identity context](credentials.md#credential-classify) — A secret-like value, key file, stored hash, challenge response or ticket Required: Artifact provenance and format; possible local/domain/application identity and compatible protocol
- [ Verify command execution, host and represented identity](sessions-transfers.md#session-proof) — A PoC, injected command or remote client reports execution Required: A functioning execution primitive and an observable output or controlled side effect
## service-postgres

### Use PostgreSQL data and privileged program execution

**Enter:** PostgreSQL access or an application connection string

**Discovery**

```text
SELECT current_user,session_user,version();
SELECT rolname,rolsuper FROM pg_roles WHERE rolname=current_user;
```

**Interpret:** An ordinary database role does not automatically have COPY PROGRAM or server-file access.

**Still check:** Inspect effective role memberships and exact operation rights, then the database service's OS context.

**Verify:** Separate returned rows, file operations and command execution; prove the actual operating-system identity for the latter.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/services/#service-postgres)

### Full procedure and variants

```bash
psql -h TARGET -p PORT -U USER -d postgres
```

```text
\conninfo
\l
\du
\dn
\dt *.*
```

```sql
SELECT version(), current_user, session_user;
SELECT rolname, rolsuper, rolcreaterole, rolcreatedb
FROM pg_roles;
```

<details>
<summary><strong>PostgreSQL variant — server file/program privilege boundary</strong></summary>

```sql
SELECT pg_has_role(current_user, 'pg_read_server_files', 'member');
SELECT pg_has_role(current_user, 'pg_write_server_files', 'member');
SELECT pg_has_role(current_user, 'pg_execute_server_program', 'member');
```

Server-side `COPY ... FROM/TO 'file'` uses the PostgreSQL server's filesystem and service identity. `COPY ... PROGRAM` executes on the server and requires superuser or the corresponding predefined role. Client-side `\copy` reads/writes the client filesystem and is not the same primitive.

</details>

> **Failure cues:** connection refusal/timeout is network or listener context; login rejection is authentication/context; an empty database list may be visibility limits; object denial is authorization. Query only bounded rows first. Never assume that reading application credentials or obtaining database admin implies OS execution.

> **Next action:** identify application accounts, hashes/credentials, paths and linked systems; record the precise grant enabling any file or execution primitive; validate recovered credentials in the later credential block and re-enumerate after any identity change.

### Follow the evidence

- [ Classify the artifact and its identity context](credentials.md#credential-classify) — A secret-like value, key file, stored hash, challenge response or ticket Required: Artifact provenance and format; possible local/domain/application identity and compatible protocol
- [ Convert database rights into a file or operating-system effect](web-exploitation.md#sql-os) — Confirmed SQL control plus database file, execution or impersonation privileges Required: DBMS-specific privilege and enabled facility; OS service identity, writable/readable destination and a compatible consumer
- [ Verify command execution, host and represented identity](sessions-transfers.md#session-proof) — A PoC, injected command or remote client reports execution Required: A functioning execution primitive and an observable output or controlled side effect
## service-redis

### Inspect Redis access and persistence boundaries

**Enter:** A Redis listener or application cache credentials

**Discovery**

```text
redis-cli -h TARGET -p PORT PING
```

**Interpret:** The connection is usable but command ACLs can remove persistence/configuration methods.

**Still check:** Inspect allowed operations, data visibility and actual persistence/destination/consumer conditions.

**Verify:** Verify authentication context, allowed commands and actual key/file effects without assuming old Redis exploit defaults.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/services/#service-redis)

### Full procedure and variants

```bash
nmap -Pn -sV --script redis-info -p PORT TARGET
redis-cli -h TARGET -p PORT PING
redis-cli -h TARGET -p PORT INFO
redis-cli -h TARGET -p PORT ACL WHOAMI
redis-cli -h TARGET -p PORT ACL LIST
```

Authenticated when a password is legitimately known:

```bash
redis-cli -h TARGET -p PORT --askpass
```

> `PONG` proves an accessible Redis command surface, not write/file/execution permission. Check ACLs, mode, bind/protected-mode and persistence/module configuration before reasoning about an effect. Do not run `CONFIG SET`, write keys or load modules during enumeration.

### Follow the evidence

- [ Classify the artifact and its identity context](credentials.md#credential-classify) — A secret-like value, key file, stored hash, challenge response or ticket Required: Artifact provenance and format; possible local/domain/application identity and compatible protocol
- [ Cross role, function or session authorization boundaries](web-exploitation.md#web-authz) — Administrative actions/routes or request methods visible from a lower role Required: The lower-role identity can invoke a protected server-side action without its required authorization
- [ Match a public exploit to the actual component and configuration](public-exploits.md#exploit-select) — A product/version clue, advisory or component-specific public PoC Required: Exact vulnerable build/configuration, required access and endpoint behavior; reviewable source and a verifiable expected effect
## service-oracle

### Triage Oracle listener and database identity

**Enter:** An Oracle TNS listener or connection descriptor

**Discovery**

```text
nmap -Pn -sV -p 1521 TARGET
```

**Interpret:** Listener/product evidence and a service name establish a connection candidate, not database credentials or DBA rights.

**Still check:** Validate the exact descriptor/account and inspect its permitted database action.

**Verify:** Distinguish listener identification, database login and a permitted SQL action.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/services/#service-oracle)

### Full procedure and variants

```bash
nmap -Pn -sV --script oracle-tns-version -p 1521 TARGET
nmap -Pn --script oracle-sid-brute -p 1521 TARGET
```

> A discovered SID/service name is a namespace clue, not credentials. Continue with an installed Oracle client only when a legitimate identity is available; preserve listener/version/SID evidence and do not treat a conventional port as Oracle proof. Source supplement: reviewed getSH Nmap Oracle block.

### Follow the evidence

- [ Validate known passwords and context-specific reuse](credentials.md#credential-use) — A password tied to a plausible user and service Required: Correct local/domain/application identity, reachable compatible service, accepted authentication and account state
- [ Match a public exploit to the actual component and configuration](public-exploits.md#exploit-select) — A product/version clue, advisory or component-specific public PoC Required: Exact vulnerable build/configuration, required access and endpoint behavior; reviewable source and a verifiable expected effect
- [ Validate uncertain results and rebuild the service queue](discovery.md#result-validation) — Scanners disagree, a result is ambiguous, or a new identity changes accessible behavior Required: A selected endpoint and a test that can resolve the decision-changing uncertainty
## service-remote

### Validate RDP, WinRM, VNC and Telnet access contexts

**Enter:** An exposed remote-access application and compatible known credentials

**Discovery**

```text
Test-NetConnection TARGET -Port 3389
Test-NetConnection TARGET -Port 5985
```

**Interpret:** Transport offers an RDP candidate from this source; it does not establish remote-interactive rights.

**Still check:** Check actual protocol, local/domain context, accepted authentication and endpoint/logon authorization.

**Verify:** Verify destination hostname, represented identity and usable effect in the resulting session.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/services/#service-remote)

### Full procedure and variants

> **Recognize:** RDP commonly uses TCP/3389; WinRM commonly uses 5985/HTTP and 5986/HTTPS. **Goal:** determine whether one known credential is accepted in the correct local/domain context and whether it is authorized for a usable session.

##### RDP baseline: authentication-only check

```bash
xfreerdp3 /v:TARGET /u:USER /d:DOMAIN /auth-only /cert:ignore
```

Some distributions expose the binary as `xfreerdp`. Omit `/d:DOMAIN` for the intended local-account context; use `/u:TARGET\\USER` if needed to make that context explicit.

> **Decisive output:** successful authentication-only validation supports that the credential is accepted for RDP/NLA. It does not prove an interactive desktop will be granted under every policy/session condition.

<details>
<summary><strong>Variant — open an RDP desktop</strong></summary>

```bash
xfreerdp3 /v:TARGET /u:USER /d:DOMAIN /dynamic-resolution /cert:ignore
```

Let FreeRDP prompt for the password. `/cert:ignore` suppresses certificate validation and is suitable only in the controlled lab context; it removes server-identity protection.

</details>

<details>
<summary><strong>Variant — identify RDP security requirements</strong></summary>

```bash
nmap -p 3389 --script rdp-enum-encryption,rdp-ntlm-info TARGET
```

This can disclose supported security layers, NLA and NTLM host/domain clues. It does not validate a credential.

</details>

##### WinRM baseline: interactive session

```bash
evil-winrm -i TARGET -u USER
```

```bash
evil-winrm -i TARGET -u 'DOMAIN\\USER'
```

Omitting `-p` makes the established Ruby client prompt for the password.

> **Decisive output:** an interactive PowerShell prompt establishes WinRM authorization. Immediately verify identity and host context with `whoami`, `hostname` and `Get-NetIPAddress`.

<details>
<summary><strong>Variant — WinRM over HTTPS</strong></summary>

```bash
evil-winrm -i TARGET -u USER -S -P 5986
```

Check `evil-winrm -h` because the established Ruby client and newer `evil-winrm-py` use different long-option spelling. Do not assume a copied command matches the installed implementation.

</details>

<details>
<summary><strong>Variant — Windows PowerShell remoting</strong></summary>

```powershell
$cred = Get-Credential
Enter-PSSession -ComputerName TARGET -Credential $cred
```

PowerShell remoting uses the configured WinRM endpoint. Local trusted-host, Kerberos/name-resolution and endpoint authorization settings can fail independently of password validity.

</details>

> **Failure cues:** certificate warnings are different from authentication failure. RDP errors can reflect NLA, account context, expired/locked accounts or missing logon rights. WinRM `401` supports authentication/authorization failure; `WinRM cannot process the request` can be name resolution, trusted-host, listener or transport context. Valid SMB credentials do not guarantee RDP or WinRM rights.

> **Next action:** after a session, re-enumerate identity, groups, privileges, files, local services/listeners and routes. Password spraying, pass-the-hash and ticket use belong to later credential/AD blocks.

##### VNC

```bash
nmap -Pn -sV --script vnc-info -p PORT TARGET
vncviewer TARGET:PORT
```

> VNC may expose a desktop without Windows logon semantics; the VNC server's authentication and the resulting OS session identity are separate. Use `realvnc-auth-bypass` or password testing only for a confirmed compatible product and explicit authorized objective, then verify the desktop identity.

##### Telnet

```bash
nmap -Pn -sV -p PORT TARGET
nc -nv TARGET PORT
telnet TARGET PORT
```

> Telnet is plaintext and may expose a banner/login prompt. Validate only legitimately acquired credentials; do not make `telnet-brute` a baseline. After login, verify host and identity because appliance/application shells can differ from an OS shell. Source supplement: reviewed getSH Nmap VNC/Telnet blocks.

##### GNU Inetutils telnetd — conditional authentication-bypass check

Use only after identifying the affected GNU Inetutils telnetd/login chain and its patch status. CVE-2026-24061 concerns how a supplied USER value reaches login; it does not apply to every Telnet server. Distribution backports matter.

```bash
# Client supports sending the autologin USER environment value
USER='-f root' telnet -a TARGET PORT
```

Read: if a shell is obtained, verify hostname and id. A prompt or echoed username is not root access. A different daemon, fixed build, client negotiation mismatch or a rejected USER value → return to service identification. The affected upstream range and distribution fixes must be checked against the advisory rather than inferred from port 23.

Sources: [upstream 1](https://security-tracker.debian.org/tracker/CVE-2026-24061).

### Follow the evidence

- [ Obtain an authorized RDP interactive session](lateral-movement.md#move-rdp) — RDP is reachable and the identity may have remote-interactive logon rights Required: Allowed account/session policy and compatible client/NLA/TLS; hash-based Restricted Admin has additional supported-policy/admin requirements
- [ Use WinRM, WinRS or PowerShell remoting](lateral-movement.md#move-winrm) — A WinRM listener and a candidate endpoint-authorized account Required: Reachable HTTP(S) listener, accepted authentication and endpoint/session configuration permissions; hash/ticket support depends on client/context
- [ Establish Windows token, host and process context](windows-privesc.md#windows-state) — A new Windows session or claimed administrator/SYSTEM transition Required: A functioning command channel and the actual effective token/process context
## service-ldap

### Discover LDAP naming contexts and authenticated search

**Enter:** LDAP/Kerberos listeners or a probable AD domain

**Discovery**

```text
ldapsearch -x -LLL -H ldap://DC_IP -s base -b '' defaultNamingContext namingContexts
```

**Interpret:** RootDSE supplies the search base; it does not grant arbitrary anonymous subtree access.

**Still check:** Check bind identity, transport/signing requirements and read visibility on the selected objects.

**Verify:** Record DC, base DN, bind identity and actual returned attributes; RootDSE alone is not a complete directory dump.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/services/#service-ldap)

### Full procedure and variants

> **Recognition:** LDAP commonly appears on TCP/389 or TCP/636; Global Catalog on TCP/3268 or 3269; Kerberos on TCP/UDP 88. Applications may listen elsewhere, so follow protocol evidence rather than port labels.

##### Baseline: discover naming contexts

> **Prerequisite:** LDAP reachability. **Coverage:** RootDSE only; this can work even when directory searches require authentication. **Decisive output:** `defaultNamingContext` and `dnsHostName`.

```bash
ldapsearch -x -LLL -H ldap://TARGET:389 -s base -b '' \
  defaultNamingContext rootDomainNamingContext configurationNamingContext dnsHostName
```

Convert `DC=corp,DC=example` into `corp.example` for DNS/Kerberos work. Preserve the server's exact hostname because Kerberos is name-sensitive.

<details>
<summary><strong>LDAPS and certificate-name inspection</strong></summary>

```bash
openssl s_client -connect TARGET:636 -servername DC_HOST </dev/null
ldapsearch -x -LLL -H ldaps://DC_HOST:636 -s base -b '' defaultNamingContext dnsHostName
```

> A certificate can disclose domain/DC names. A TLS validation error is a client trust/name issue, not proof that LDAP is unavailable.

</details>

##### Anonymous directory search

> **Prerequisite:** known base DN and server permitting anonymous search. **Failure cue:** `Inappropriate authentication` or `Insufficient access` closes only the anonymous path.

```bash
ldapsearch -x -LLL -H ldap://DC_IP:389 -b 'DC=DOMAIN,DC=TLD' \
  '(&(objectCategory=person)(objectClass=user))' \
  sAMAccountName userPrincipalName memberOf description
```

```bash
ldapsearch -x -LLL -H ldap://DC_IP:389 -b 'DC=DOMAIN,DC=TLD' \
  '(objectClass=group)' cn member description
```

##### Authenticated search

> **Prerequisite:** a valid directory identity. **Decisive output:** objects/attributes unavailable anonymously. Avoid placing a real password in shell history when an interactive prompt is available.

```bash
ldapsearch -x -LLL -H ldap://DC_HOST:389 \
  -D 'USER@DOMAIN.TLD' -W -b 'DC=DOMAIN,DC=TLD' \
  '(&(objectCategory=person)(objectClass=user))' \
  sAMAccountName userPrincipalName memberOf description servicePrincipalName userAccountControl
```

<details>
<summary><strong>Search computers, groups and SPN-bearing accounts separately</strong></summary>

```bash
ldapsearch -x -LLL -H ldap://DC_HOST:389 -D 'USER@DOMAIN.TLD' -W \
  -b 'DC=DOMAIN,DC=TLD' '(objectClass=computer)' \
  dNSHostName operatingSystem operatingSystemVersion servicePrincipalName

ldapsearch -x -LLL -H ldap://DC_HOST:389 -D 'USER@DOMAIN.TLD' -W \
  -b 'DC=DOMAIN,DC=TLD' '(objectClass=group)' cn member

ldapsearch -x -LLL -H ldap://DC_HOST:389 -D 'USER@DOMAIN.TLD' -W \
  -b 'DC=DOMAIN,DC=TLD' '(&(objectCategory=person)(servicePrincipalName=*))' \
  sAMAccountName servicePrincipalName memberOf
```

</details>

##### Kerberos prerequisites before an attack

Kerberos failures are often name/time/route failures rather than credential failures. Establish:

```bash
getent hosts DC_HOST
nc -nvz DC_IP 88
date -u
nmap -Pn -sV -p 88,389,445,464,636,3268,3269 DC_IP -oN dc-services.txt
```

> **Interpretation:** resolve `DOMAIN` and `DC_HOST` consistently, keep clock skew within Kerberos tolerance, and ensure the KDC is reached through the selected route. `KDC_ERR_C_PRINCIPAL_UNKNOWN` points to identity/domain naming; `KRB_AP_ERR_SKEW` points to time; `KDC_ERR_PREAUTH_FAILED` normally points to authentication material.

##### Handoff

- New users, groups, computers, SPNs or domain names → [domain mapping](https://github.com/ArmaanLeg3nd/OSCP-Exploitation-Reference/blob/main/reference/06-ad-lateral-movement/01-domain-mapping.md).
- A user confirmed without preauthentication → [Kerberos and identity transitions](https://github.com/ArmaanLeg3nd/OSCP-Exploitation-Reference/blob/main/reference/06-ad-lateral-movement/03-kerberos-and-identity-transitions.md).
- Valid credentials → rerun authenticated LDAP plus SMB/share/remote-access enumeration.
- Certificate templates/AD CS clues → [AD CS and object-control abuse](https://github.com/ArmaanLeg3nd/OSCP-Exploitation-Reference/blob/main/reference/06-ad-lateral-movement/04-object-control-adcs-and-domain-compromise.md).

### Follow the evidence

- [ Establish domain identity, DC, DNS, time and route](ad-mapping.md#domain-state) — Domain credentials or a domain-joined foothold Required: Correct realm/domain and account qualification; reachable DC/services, usable DNS and acceptable clock skew
- [ Enumerate directory objects with native, LDAP and PowerView approaches](ad-mapping.md#domain-directory) — A directory bind or domain-joined identity can read relevant objects Required: Correct search base and authentication transport; object/attribute visibility and compatible local utilities
- [ Request a selected service ticket for offline service-account recovery](ad-identities.md#kerberos-roast) — A user-owned SPN and a useful service-account relationship Required: A valid domain authentication/TGT context, reachable KDC, target SPN and a feasible password/encryption candidate strategy
## service-sip-irc

### Investigate SIP/IRC identity and configuration clues

**Enter:** A confirmed SIP or IRC application

**Discovery**

```text
nmap -Pn -sV -p PORT TARGET
nc -nv TARGET PORT
```

**Interpret:** The real protocol and registration state determine the next client operation; the expected port label is insufficient.

**Still check:** Verify application/version, accepted interaction and exact exploit/access conditions.

**Verify:** Retain protocol responses and distinguish product clues from confirmed vulnerabilities.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/services/#service-sip-irc)

### Full procedure and variants

These source-site topics contain only first-pass reconnaissance. Treat them as application-identification branches, not default exploitation paths.

##### SIP

> Commonly UDP/TCP 5060 or TLS 5061; follow protocol evidence.

```bash
nmap -Pn -sU -sV --script sip-methods -p 5060 TARGET
nmap -Pn -sT -sV --script sip-methods -p 5060 TARGET
```

> **Decisive output:** a SIP response and supported methods. `open|filtered` without application response remains ambiguous. Do not run `sip-brute` until the exact registrar, known test identities, lockout policy and explicit authorization are established.

##### IRC

```bash
nmap -Pn -sV --script irc-info -p PORT TARGET
nc -nv TARGET PORT
```

Minimal registration for an authorized test client:

```text
NICK testnick
USER testuser 0 * :Test User
QUIT
```

> **Decisive output:** IRC numeric replies, server/network name, version/capabilities or authentication requirement. Do not use `irc-brute` as identification; authenticate only with legitimately acquired credentials.

### Follow the evidence

- [ Match a public exploit to the actual component and configuration](public-exploits.md#exploit-select) — A product/version clue, advisory or component-specific public PoC Required: Exact vulnerable build/configuration, required access and endpoint behavior; reviewable source and a verifiable expected effect
- [ Validate known passwords and context-specific reuse](credentials.md#credential-use) — A password tied to a plausible user and service Required: Correct local/domain/application identity, reachable compatible service, accepted authentication and account state
- [ Identify applications and validate selected NSE checks](discovery.md#identify-app) — A listener has a port-based label or uncertain version Required: A reachable selected port; scripts must match the application and permitted assessment behavior
## S13

### Inspect a Java RMI registry before selecting an exploit

**Enter:** service detection or an application response identifies Java RMI on a selected port.

**Discovery**

```text
nmap -sV -p PORT --script rmi-dumpregistry TARGET

nmap -p PORT --script rmi-vuln-classloader TARGET
```

**Interpret:** enumerate bound names, classes, remote endpoints and codebase annotations without assuming the registry is exploitable:

  bash
  nmap -sV -p PORT --script rmi-dumpregistry TARGET

**Still check:** confirm the selected endpoint is the actual registry/service, its class-loading/serialization behavior, Java/version prerequisites and whether any proposed test is intrusive. The Nmap class-loader probe is categorized intrusive and must not be the baseline:

  bash
  nmap -p PORT --script rmi-vuln-classloader TARGET
ACTION PROCEDURE PENDING: discovery/validation only.

**Verify:** registry names or a vulnerable class-loader result are component evidence, not a session. A complete action must separately verify the executed identity and resulting capability.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/investigate/#S13)

### Full procedure and variants

- **Enter:** service detection or an application response identifies Java RMI on a selected port.
- **Discover:** enumerate bound names, classes, remote endpoints and codebase annotations without assuming the registry is exploitable:

  ```bash
  nmap -sV -p PORT --script rmi-dumpregistry TARGET
  ```

- **Validate:** confirm the selected endpoint is the actual registry/service, its class-loading/serialization behavior, Java/version prerequisites and whether any proposed test is intrusive. The Nmap class-loader probe is categorized intrusive and must not be the baseline:

  ```bash
  nmap -p PORT --script rmi-vuln-classloader TARGET
  ```

- **Execute:** no generic RMI/serialization execution procedure is registered. Route a matched component/version/condition to D16 only after the required behavior is established; see RW05.
- **Verify:** registry names or a vulnerable class-loader result are component evidence, not a session. A complete action must separately verify the executed identity and resulting capability.
- **Outcomes:** matching component and vulnerable behavior → candidate for reviewed D16 procedure; no registry or prerequisite decisively absent → ruled out here; filtered/incomplete registry or ambiguous class loading → inconclusive.
- **Sources:** [Nmap `rmi-dumpregistry`](https://nmap.org/nsedoc/scripts/rmi-dumpregistry.html) and [`rmi-vuln-classloader`](https://nmap.org/nsedoc/scripts/rmi-vuln-classloader.html).

### Follow the evidence

## S14

### Classify a Tomcat Manager interface and accepted role

**Enter:** the application is confirmed as Apache Tomcat and a /manager/* interface responds.

**Discovery**

```text
curl -sk -D - "https://TARGET:PORT/manager/html" -o /dev/null
  curl -sk -D - "https://TARGET:PORT/manager/text/list" -o /dev/null
```

**Interpret:** inspect the selected interface and authentication boundary without spraying credentials:

  bash
  curl -sk -D - "https://TARGET:PORT/manager/html" -o /dev/null
  curl -sk -D - "https://TARGET:PORT/manager/text/list" -o /dev/null

**Still check:** identify the accepted account and manager role: manager-gui, manager-script, manager-jmx or manager-status. GUI access and text-script access are intentionally separate; a 401, 403 and application 404 have different meanings.
ACTION PROCEDURE PENDING: discovery/validation only.

**Verify:** a manager listing proves the interface/role only. A deployable application, reachable context path and server-side execution identity require separate proof.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/investigate/#S14)

### Full procedure and variants

- **Enter:** the application is confirmed as Apache Tomcat and a `/manager/*` interface responds.
- **Discover:** inspect the selected interface and authentication boundary without spraying credentials:

  ```bash
  curl -sk -D - "https://TARGET:PORT/manager/html" -o /dev/null
  curl -sk -D - "https://TARGET:PORT/manager/text/list" -o /dev/null
  ```

- **Validate:** identify the accepted account and manager role: `manager-gui`, `manager-script`, `manager-jmx` or `manager-status`. GUI access and text-script access are intentionally separate; a `401`, `403` and application `404` have different meanings.
- **Execute:** current notes do not yet own a version-scoped deployment, verification and cleanup procedure. Preserve the authenticated management capability and see RW06. JBoss/Jenkins and other managers remain separate product branches under RW07.
- **Verify:** a manager listing proves the interface/role only. A deployable application, reachable context path and server-side execution identity require separate proof.
- **Outcomes:** accepted deployment-capable role → ready for a reviewed product procedure; role/interface denies the required operation → ruled out for that role; proxy rewriting, wrong scheme/path or ambiguous realm → inconclusive.
- **Source:** [Apache Tomcat Manager App HOW-TO](https://tomcat.apache.org/tomcat-11.0-doc/manager-howto.html).

### Follow the evidence

## S15

### Follow an MSSQL linked server as a new SQL identity boundary

**Enter:** a working MSSQL login reveals one linked server or login mapping.

**Discovery**

```text

```

**Interpret:** enumerate sys.servers and sp_helplinkedsrvlogin, preserving local login, remote server, provider/data source and mapping.

**Still check:** test one read-only remote identity query through the supported RPC or data-access mechanism. Do not enable RPC, create mappings or change configuration for enumeration.

**Verify:** record returned SYSTEM_USER, ORIGINAL_LOGIN() and the remote role result. A remote SQL query is not OS command execution.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/reference/02-service-enumeration/08-databases/#mssql-linked-server-and-login-context-mapping)

### Full procedure and variants

- **Enter:** a working MSSQL login reveals one linked server or login mapping.
- **Discover:** enumerate `sys.servers` and `sp_helplinkedsrvlogin`, preserving local login, remote server, provider/data source and mapping.
- **Validate:** test one read-only remote identity query through the supported RPC or data-access mechanism. Do not enable RPC, create mappings or change configuration for enumeration.
- **Execute:** [MSSQL linked-server and login-context mapping](https://armaanleg3nd.github.io/oscp/reference/02-service-enumeration/08-databases/#mssql-linked-server-and-login-context-mapping).
- **Verify:** record returned `SYSTEM_USER`, `ORIGINAL_LOGIN()` and the remote role result. A remote SQL query is not OS command execution.
- **Outcomes:** mapped remote query succeeds → re-enter D07 for that server/identity; link exists but RPC/data access is decisively unavailable → ruled out for that mechanism; mapping/authentication/provider failure is unresolved → inconclusive/D31.

### Follow the evidence

