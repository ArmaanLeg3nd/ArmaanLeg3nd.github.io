# Map Active Directory attack paths

[Overview](../START.canvas) · [Browser map](../Map.html)

Build identity, object-right, host-access and session maps. A graph relationship is a candidate until its effective permission, destination and current state are checked.

## domain-state

### Establish domain identity, DC, DNS, time and route

**Enter:** Domain credentials or a domain-joined foothold

**Discovery**

```text
whoami /all
whoami /upn
nltest /dsgetdc:DOMAIN
w32tm /query /status
```

**Interpret:** The named realm/DC and actual identity establish where directory/authentication checks must run.

**Still check:** Check DC/service reachability, resolver/SPN naming and clock compatibility, not merely the password.

**Verify:** Record represented identity, realm, selected DC, resolver, clock and real source route.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/ad-mapping/#domain-state)

### Full procedure and variants

##### Domain-joined Windows source

```cmd
whoami /all
echo %USERDNSDOMAIN%
echo %USERDOMAIN%
echo %LOGONSERVER%
nltest /dsgetdc:DOMAIN
nltest /dclist:DOMAIN
w32tm /query /status
```

```powershell
[System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()
Resolve-DnsName -Type SRV _ldap._tcp.dc._msdcs.DOMAIN
Resolve-DnsName -Type SRV _kerberos._tcp.DOMAIN
```

> **Decisive output:** domain FQDN, DC FQDN/IP, current user SID/groups, DNS SRV answers and a plausible time source. `USERDOMAIN` can be a NetBIOS label; prefer the DNS domain for LDAP/Kerberos.

##### Kali/off-domain source

```bash
dig +short SRV _ldap._tcp.dc._msdcs.DOMAIN @DC_IP
dig +short SRV _kerberos._tcp.DOMAIN @DC_IP
nxc smb DC_IP -d DOMAIN -u USER -p 'PASSWORD'
ldapsearch -x -LLL -H ldap://DC_HOST:389 -s base -b '' \
  defaultNamingContext configurationNamingContext rootDomainNamingContext dnsHostName
```

> RootDSE is a directory-server metadata object. Reading it can reveal naming contexts even when anonymous subtree searches are denied. Convert `corp.example` to `DC=corp,DC=example`; do not guess the base DN when RootDSE can supply it.

<details>
<summary><strong>Remote Windows session and double-hop caveat</strong></summary>

```cmd
whoami /all
klist
dir \\DC_HOST\SYSVOL
```

A supplied credential may create the remote session without being delegated onward to the DC. If local identity commands work but access to a second host fails, distinguish a WinRM/PowerShell remoting credential-delegation problem from invalid credentials. An interactive RDP session, explicit credentials, `/netonly` network credentials or an off-domain LDAP client may create a different context; always record which identity is used locally and over the network.

</details>

```text
IDENTITY MAP: USER/COMPUTER -> DIRECT + NESTED GROUPS -> DIRECTORY RIGHTS
HOST MAP:     COMPUTER -> OS/ROLE -> LOCAL/REMOTE-ACCESS RIGHTS -> SESSIONS
ROUTE MAP:    SOURCE -> DNS/KDC/DC/HOST -> REQUIRED PORT/SERVICE
LEAD MAP:     EVIDENCE -> HYPOTHESIS -> MINIMUM VALIDATION -> NEXT BLOCK
```

Authentication, authorization, reachability and session presence are independent. A valid LDAP bind does not prove share access; SMB administration on one host does not prove directory privilege; a session edge does not prove retrievable credentials.

```text
AS-REQ/AS-REP: user proves knowledge of long-term key -> receives TGT
TGS-REQ/TGS-REP: TGT requests SERVICE/HOST -> receives service ticket
AP-REQ: client presents service ticket -> service authenticates client
AUTHORIZATION: target service still evaluates the represented identity/claims
```

Before changing credentials or tools:

```bash
getent hosts DC_HOST
nc -nvz DC_IP 88
date -u
```

```cmd
w32tm /query /status
klist
```

Record domain FQDN/realm, DC FQDN/IP, source DNS, current time, KDC route and exact target SPN. IP connectivity does not replace hostname/SPN correctness.

### Follow the evidence

- [ Enumerate directory objects with native, LDAP and PowerView approaches](ad-mapping.md#domain-directory) — A directory bind or domain-joined identity can read relevant objects Required: Correct search base and authentication transport; object/attribute visibility and compatible local utilities
- [ Preserve DNS, Kerberos names and time across a pivot](pivoting.md#pivot-dns) — An IP connection works while hostname/Kerberos access fails Required: Reachable correct resolver/KDC path, matching target SPN/hostname, realm configuration and acceptable time
- [ Match route, destination service and effective authorization](lateral-movement.md#move-preflight) — A credential appears valid but the destination's usable access is unknown Required: Real source-to-service route, correct identity context and protocol-specific execution/logon rights
## domain-directory

### Enumerate directory objects with native, LDAP and PowerView approaches

**Enter:** A directory bind or domain-joined identity can read relevant objects

**Discovery**

```text
net user USER /domain
net group "GROUP" /domain
```

**Interpret:** Account/group membership supplies a relationship to investigate; nested membership and effective destination rights remain separate.

**Still check:** Verify object SID/type, nesting and the exact right granted to that principal.

**Verify:** Retain object identifiers, group relationships and actual visibility; distinguish directory facts from inferred execution access.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/ad-mapping/#domain-directory)

### Full procedure and variants

<section data-study-approach="native-windows" aria-label="Native Windows baseline">

```cmd
net user /domain
net user USER /domain
net group /domain
net group "Domain Admins" /domain
net group "GROUP" /domain
net accounts /domain
nltest /domain_trusts /all_trusts
net view /domain
net view \\DC_HOST
```

These commands are broadly available but provide partial views. Expand interesting users and groups individually, trace nested groups rather than assuming `memberOf` is complete, and retain SIDs when names can collide across domains.

<details>
<summary><strong>RSAT ActiveDirectory module, only when installed</strong></summary>

```powershell
Get-Command -Module ActiveDirectory
Get-ADDomain
Get-ADForest
Get-ADDomainController -Filter *
Get-ADUser -Filter * -Properties Enabled,Description,MemberOf,ServicePrincipalName,UserPrincipalName,PasswordLastSet,LastLogonDate,AdminCount
Get-ADGroup -Filter * -Properties GroupScope,GroupCategory,Members,Description
Get-ADGroupMember -Identity 'GROUP' -Recursive
Get-ADComputer -Filter * -Properties DNSHostName,OperatingSystem,OperatingSystemVersion,ServicePrincipalName,TrustedForDelegation,LastLogonDate
Get-ADTrust -Filter *
```

`Get-AD*` cmdlets require the RSAT ActiveDirectory module. Its absence on a client is normal; use ADSI, LDAP, PowerView or an off-domain client.

</details>

</section>

<section data-study-approach="adsi" aria-label="Built-in ADSI/DirectorySearcher fallback">

For repeated queries, [define LDAPSearch once inline](https://github.com/ArmaanLeg3nd/OSCP-Exploitation-Reference/blob/main/cheatsheets/active-directory.md#define-ldapsearch-once-in-this-powershell-session), then use its purpose-labelled calls. The transparent one-off procedure below remains useful when no helper is loaded.

```powershell
$root = [ADSI]'LDAP://RootDSE'
$base = [ADSI]("LDAP://" + $root.defaultNamingContext)
$searcher = New-Object System.DirectoryServices.DirectorySearcher($base)
$searcher.PageSize = 1000
$searcher.PropertiesToLoad.AddRange(@('samaccountname','userprincipalname','objectsid','memberof','serviceprincipalname','description','useraccountcontrol','pwdlastset','lastlogontimestamp'))
$searcher.Filter = '(&(objectCategory=person)(objectClass=user))'
$searcher.FindAll() | ForEach-Object { $_.Properties }
```

Change only the filter and requested attributes for another object class:

```powershell
# Groups
$searcher.Filter = '(objectCategory=group)'
$searcher.PropertiesToLoad.Clear()
$searcher.PropertiesToLoad.AddRange(@('samaccountname','objectsid','member','grouptype','description'))
$searcher.FindAll() | ForEach-Object { $_.Properties }

# Computers
$searcher.Filter = '(objectCategory=computer)'
$searcher.PropertiesToLoad.Clear()
$searcher.PropertiesToLoad.AddRange(@('dnshostname','operatingsystem','operatingsystemversion','serviceprincipalname','useraccountcontrol','lastlogontimestamp'))
$searcher.FindAll() | ForEach-Object { $_.Properties }
```

> `PageSize = 1000` asks for paged results; without paging, the server's result-size limit can silently produce an incomplete inventory. LDAP filters are data selection, not proof of access or exploitability.

</section>

<section data-study-approach="ldap" aria-label="Authenticated LDAP from Kali">

##### Discover the naming context

```bash
ldapsearch -x -LLL -H ldap://DC_HOST:389 -s base -b '' \
  defaultNamingContext configurationNamingContext rootDomainNamingContext dnsHostName
```

##### Users, groups and computers

```bash
ldapsearch -x -LLL -H ldap://DC_HOST:389 -D 'USER@DOMAIN' -W \
  -E pr=1000/noprompt -b 'DC=DOMAIN,DC=TLD' \
  '(&(objectCategory=person)(objectClass=user))' \
  sAMAccountName userPrincipalName objectSid userAccountControl memberOf description servicePrincipalName pwdLastSet lastLogonTimestamp adminCount
```

```bash
ldapsearch -x -LLL -H ldap://DC_HOST:389 -D 'USER@DOMAIN' -W \
  -E pr=1000/noprompt -b 'DC=DOMAIN,DC=TLD' \
  '(objectCategory=group)' sAMAccountName objectSid member groupType description
```

```bash
ldapsearch -x -LLL -H ldap://DC_HOST:389 -D 'USER@DOMAIN' -W \
  -E pr=1000/noprompt -b 'DC=DOMAIN,DC=TLD' \
  '(objectCategory=computer)' dNSHostName operatingSystem operatingSystemVersion servicePrincipalName userAccountControl lastLogonTimestamp
```

<details>
<summary><strong>SPNs, trusts and GPO/OU context</strong></summary>

```bash
# SPN-bearing accounts: mapping only; do not request tickets in this block.
ldapsearch -x -LLL -H ldap://DC_HOST:389 -D 'USER@DOMAIN' -W \
  -E pr=1000/noprompt -b 'DC=DOMAIN,DC=TLD' \
  '(&(objectCategory=person)(objectClass=user)(servicePrincipalName=*))' \
  sAMAccountName servicePrincipalName memberOf userAccountControl pwdLastSet
```

```bash
# Trusted-domain objects
ldapsearch -x -LLL -H ldap://DC_HOST:389 -D 'USER@DOMAIN' -W \
  -b 'DC=DOMAIN,DC=TLD' '(objectClass=trustedDomain)' \
  cn securityIdentifier trustDirection trustType trustAttributes
```

```bash
# OUs and GPO containers; correlate links before inferring host effect.
ldapsearch -x -LLL -H ldap://DC_HOST:389 -D 'USER@DOMAIN' -W \
  -E pr=1000/noprompt -b 'DC=DOMAIN,DC=TLD' \
  '(|(objectClass=organizationalUnit)(objectClass=groupPolicyContainer))' \
  distinguishedName displayName name gPLink gPOptions
```

</details>

##### LDAP failure router

| Result | Interpretation | Next action |
| --- | --- | --- |
| `Invalid credentials (49)` | Bind identity/secret/context failed; subcodes may refine the cause | Recheck UPN vs `DOMAIN\USER`, account state and exact secret; do not infer authorization |
| `Strong(er) authentication required` / confidentiality required | Server policy rejects that bind/transport | Use the permitted LDAPS/StartTLS or Kerberos/SASL path; do not disable protections |
| `Size limit exceeded` or suspiciously round count | Search is incomplete | Add paged results and narrow the base/filter |
| Referral/partial results | Search crossed a naming-context boundary | Query the referred domain/partition or compatible Global Catalog deliberately |
| Bind succeeds, search empty | Wrong base/filter, ACL filtering or genuinely no matches | Verify RootDSE base, test a known object and request fewer attributes |
| Works by IP, Kerberos fails | Route exists but name/SPN/DNS/time path is wrong | Use DC FQDN, AD DNS, correct realm and synchronized time |

</section>

<section data-study-approach="powerview" aria-label="PowerView: convenient manual breadth">

```powershell
Import-Module .\PowerView.ps1
Get-Command -Module PowerView
Get-Domain
Get-DomainController
Get-DomainTrust
Get-DomainUser | Select-Object samaccountname,userprincipalname,description,memberof,serviceprincipalname
Get-DomainGroup
Get-DomainGroupMember -Identity 'GROUP' -Recurse
Get-DomainComputer | Select-Object dnshostname,operatingsystem,operatingsystemversion
Get-DomainUser -SPN | Select-Object samaccountname,serviceprincipalname,memberof
```

The original PowerSploit repository is archived. Course examples and forks may use legacy aliases such as `Get-NetUser`, `Get-NetGroup`, `Get-NetComputer` or `Get-NetDomainTrust`. Inspect `Get-Command`/`Get-Help` for the exact copy present rather than mixing generations.

</section>

```text
NEW PASSWORD/HASH/KEY/TICKET
-> VERIFY TYPE, CLIENT, REALM, VALIDITY
-> AUTHENTICATE THROUGH ONE COMPATIBLE SERVICE
-> CONFIRM IDENTITY
-> REPEAT GROUP/ACL/SHARE/HOST/SESSION/ROUTE MAPPING
```

Do not overwrite the old state. Record which source produced the material and which protocol accepted it.

### Follow the evidence

- [ Validate effective directory-object control](ad-mapping.md#domain-acl) — An ACL/graph edge names GenericAll, GenericWrite, WriteDacl, WriteOwner or an extended/property right Required: Effective trustee membership, target object/type, inheritance/deny behavior and the exact permitted operation
- [ Validate host access and volatile session candidates](ad-mapping.md#domain-hosts) — Group-to-host access edges or a privileged user's possible session Required: Reachable destination service and its actual authorization; session evidence must be current and collection rights sufficient
- [ Request a selected service ticket for offline service-account recovery](ad-identities.md#kerberos-roast) — A user-owned SPN and a useful service-account relationship Required: A valid domain authentication/TGT context, reachable KDC, target SPN and a feasible password/encryption candidate strategy
- [ Collect focused BloodHound data and validate an attack path](ad-mapping.md#domain-graph) — Directory relationships are too broad for manual comparison or a candidate chain needs ranking Required: Compatible collector/deployment, explicit scope, directory rights and separate permission/connectivity for host/session collection
- [ Identify service accounts and SPNs worth investigating](ad-mapping.md#domain-spns) — User-owned SPNs or service-account clues Required: Directory visibility and correct service/account association; roasting requires the additional authentication and encryption conditions
- [ Request AS-REP material for an account without preauthentication](ad-identities.md#kerberos-asrep) — A known user or directory flag indicates Kerberos preauthentication is disabled Required: Account with preauthentication disabled, KDC reachability and a supported returned encryption type; no-password and authenticated-discovery contexts differ
- [ Conditional: trace GPO control to privileged policy consumption](ad-identities.md#ad-gpo) — A useful linked GPO has a potentially controllable directory or SYSVOL component Required: Effective rights on the necessary GPO components, applicable target scope/filtering, writable policy artifact and a privileged refresh trigger
- [ Conditional: use a validated delegation or RBCD relationship](ad-identities.md#ad-delegation) — Delegation configuration or computer-object write suggests a Kerberos impersonation path Required: Exact delegation type; required service/machine identity and key; allowed target/SPN; account flags and KDC policy permit the flow
- [ Conditional: validate an AD CS enrollment-to-authentication path](ad-identities.md#ad-certificates) — A CA/template configuration exposes a plausible certificate identity transition Required: Effective enrollment/template/CA rights and the exact vulnerable settings; issuance requirements, identity mapping and authentication route must all permit the path
## domain-shares

### Read domain shares, SYSVOL and NETLOGON for useful artifacts

**Enter:** A valid domain identity and accessible file services

**Discovery**

```text
net view \\DC_HOST
dir \\DOMAIN\SYSVOL
dir \\DOMAIN\NETLOGON
```

**Interpret:** A real domain-readable script gives concrete identity/path leads for credential and host investigation.

**Still check:** Verify readable artifact content, whether any secret is current and what account/service it belongs to.

**Verify:** Prove read access and actual artifact content; keep recovered real secrets private.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/ad-mapping/#domain-shares)

### Full procedure and variants

##### Inventory, then test the object

```cmd
net view \\DC_HOST
dir \\DC_HOST\SYSVOL
dir \\DC_HOST\NETLOGON
```

```bash
nxc smb DC_IP -d DOMAIN -u USER -p 'PASSWORD' --shares
smbclient -L //DC_IP -U 'DOMAIN/USER'
smbclient //DC_IP/SYSVOL -U 'DOMAIN/USER' -c 'recurse ON; ls'
smbclient //DC_IP/SHARE -U 'DOMAIN/USER'
```

Inside `smbclient`, use `ls`, `cd`, `get FILE` and a harmless approved `put` only when write validation is needed. Share listing, share connection, file read and file write are separate permissions.

Inspect authorized readable policy/logon/deployment paths for scripts, configurations, backups, connection strings and legacy Group Policy Preferences XML containing `cpassword`. Selectively retrieve relevant files; do not bulk-copy a share merely because it is readable. A discovered secret returns to the credential-classification procedure.

### Follow the evidence

- [ Classify the artifact and its identity context](credentials.md#credential-classify) — A secret-like value, key file, stored hash, challenge response or ticket Required: Artifact provenance and format; possible local/domain/application identity and compatible protocol
- [ Validate known passwords and context-specific reuse](credentials.md#credential-use) — A password tied to a plausible user and service Required: Correct local/domain/application identity, reachable compatible service, accepted authentication and account state
- [ Enumerate SMB/RPC shares, files and identities](services.md#service-smb) — SMB/RPC endpoints, domain clues or new credentials Required: Reachable SMB/RPC; anonymous, guest, local or domain context must be explicit; share and filesystem ACLs both matter
## domain-spns

### Identify service accounts and SPNs worth investigating

**Enter:** User-owned SPNs or service-account clues

**Discovery**

```text
Get-DomainUser -SPN | Select-Object samaccountname,serviceprincipalname,memberof
```

**Interpret:** A user-owned service name identifies a potential ticket/password-recovery target whose rights may be useful.

**Still check:** Check actual account type, KDC authentication, encryption type and feasibility; SPN existence alone is not weakness.

**Verify:** Record SPN, account/object type and relevant privilege relationships before prioritizing recovery.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/ad-mapping/#domain-spns)

### Full procedure and variants

```cmd
setspn -Q */*
setspn -L ACCOUNT
```

```powershell
Get-DomainUser -SPN | Select-Object samaccountname,serviceprincipalname,memberof,useraccountcontrol,pwdlastset
```

Record `account → service class/host/port → groups → password age/encryption/delegation clues → reachable service`. An SPN means the account represents a Kerberos service identity; it does not mean the password is weak, the service is reachable or the account is privileged. Ticket acquisition/cracking is Block 11.

### Follow the evidence

- [ Request a selected service ticket for offline service-account recovery](ad-identities.md#kerberos-roast) — A user-owned SPN and a useful service-account relationship Required: A valid domain authentication/TGT context, reachable KDC, target SPN and a feasible password/encryption candidate strategy
- [ Recover passwords with feasible dictionary, rule and mask attacks](credentials.md#offline-recovery) — A supported stored verifier or converted protected artifact Required: Correct format/mode, complete salt/context, justified candidates and an available offline tool/backend
- [ Validate effective directory-object control](ad-mapping.md#domain-acl) — An ACL/graph edge names GenericAll, GenericWrite, WriteDacl, WriteOwner or an extended/property right Required: Effective trustee membership, target object/type, inheritance/deny behavior and the exact permitted operation
## domain-acl

### Validate effective directory-object control

**Enter:** An ACL/graph edge names GenericAll, GenericWrite, WriteDacl, WriteOwner or an extended/property right

**Discovery**

```text
Get-DomainObjectAcl -Identity TARGET_OBJECT -ResolveGUIDs
```

**Interpret:** A DACL-control ACE for a possibly controlled trustee opens an intermediate-right candidate.

**Still check:** Resolve the ACE's trustee and group nesting, target object class, GUID and inheritance/deny scope. For password reset, group writes or DACL changes open that exact operation's procedure and check its additional conditions before modifying anything.

**Verify:** Verify principal, object SID/type and effective permitted modification; preserve original ACL/state before changes.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/ad-mapping/#domain-acl)

### Full procedure and variants

```powershell
Get-DomainObjectAcl -Identity TARGET_OBJECT -ResolveGUIDs |
  Where-Object { $_.ActiveDirectoryRights -match 'GenericAll|GenericWrite|WriteDacl|WriteOwner|ExtendedRight|WriteProperty|Self' } |
  Select-Object ObjectDN,SecurityIdentifier,ActiveDirectoryRights,ObjectAceType,AceType,IsInherited,InheritanceType
```

PowerView normally exposes the trustee as `SecurityIdentifier`. Resolve that SID and trace controlled direct/nested membership. `-ResolveGUIDs` resolves operation GUIDs; it does not make every trustee a friendly account name. A blank projected column can mean the selected property is absent, not that an ACE has no trustee.

<details>
<summary><strong>Compatible copy that actually emits IdentityReference</strong></summary>

Use this projection only when inspecting the returned object confirms that the loaded implementation provides `IdentityReference`.

```powershell
Get-DomainObjectAcl -Identity TARGET_OBJECT -ResolveGUIDs |
  Where-Object { $_.ActiveDirectoryRights -match 'GenericAll|GenericWrite|WriteDacl|WriteOwner|ExtendedRight|WriteProperty|Self' } |
  Select-Object ObjectDN,IdentityReference,ActiveDirectoryRights,ObjectAceType,AceType,IsInherited,InheritanceType
```

If the value is an unresolved SID, resolve it before applying the rule to a controlled principal.

</details>

| Candidate right | Possible transition to validate later | Missing proof now |
| --- | --- | --- |
| `GenericAll` | Broad object modification | Controlled trustee, target object class, applicable deny/inheritance and useful change |
| `GenericWrite` / `WriteProperty` | Change one or more writable attributes | Exact attribute/object GUID and a transition that consumes it |
| `WriteOwner` | Become owner | Ability to change the DACL afterward and use the resulting right |
| `WriteDacl` | Add an ACE | Effective write-DACL right, planned narrow ACE and restoration |
| `AllExtendedRights` / `ForceChangePassword` | Extended operation such as reset where applicable | Object class, exact extended right and downstream usefulness |
| `Self` / validated write | Add self/member or another validated attribute where schema permits | Correct validated-write GUID and target type |
| GPO/OU control | Affect linked computers/users | Writable GPO component, effective link/scope, refresh/trigger and target placement |

An ACE is one rule. Effective access depends on trustee/group nesting, allow/deny semantics, inheritance, object-specific GUIDs and security descriptor scope. Do not perform the modification in this mapping block.

> **Model:** controlled principal → effective ACE → target object/type → permitted modification → authentication/authorization effect → cleanup.

Enumerate a target's ACL with resolved GUIDs:

```powershell
Import-Module .\PowerView.ps1
Get-DomainObjectAcl -Identity TARGET_OBJECT -ResolveGUIDs |
  Where-Object { $_.ActiveDirectoryRights -match 'GenericAll|GenericWrite|WriteDacl|WriteOwner|ExtendedRight' }
```

Resolve trustees:

```powershell
ConvertFrom-SID 'S-1-5-21-...'
Get-DomainObject -Identity 'S-1-5-21-...' | Select-Object samaccountname,objectclass
```

Common effects require different rights:

| Right/object | Possible controlled effect | Validation needed |
| --- | --- | --- |
| `GenericAll`/password-reset extended right on user | Reset the user's password | Effective trustee, account state, protected-object behavior |
| `GenericAll` or effective member-attribute write on group | Add a controlled principal to the group | Target group, nesting and a refreshed logon token |
| `GenericWrite`/SPN-property write on user | Add a temporary SPN, request a TGS and remove it | Exact property right, duplicate-SPN checks and cleanup |
| `WriteDacl` | Grant a narrower right | Ability to write DACL and restore original ACL |
| `WriteOwner` | Change owner, then possibly DACL | Owner semantics and cleanup |
| Computer-object write | RBCD-related attribute change | Machine account/control, SPN/Kerberos and target service |

### Follow the evidence

- [ Reset a target account password through a validated directory right](ad-identities.md#ad-password-reset) — A controlled trustee has the effective password-reset right on a useful account Required: Exact object/right and account state; the disruptive password change is justified within the assigned lab objective
- [ Add a controlled identity to a group through effective membership rights](ad-identities.md#ad-group-control) — A group member-attribute write or equivalent effective right Required: Exact target group, controlled principal, useful resulting right and a fresh token/logon context
- [ Convert ownership or DACL control into a narrower useful right](ad-identities.md#ad-owner-dacl) — Effective WriteOwner or WriteDacl on a useful directory object Required: Correct object/ACE semantics, permission to perform the required intermediate change and a preserved original ACL/owner
- [ Use validated directory replication rights for bounded credential proof](ad-identities.md#ad-dcsync) — A principal has the relevant effective replication rights at the domain naming context Required: Required replication extended rights, DC RPC connectivity and correct domain identity; access to a member server is insufficient
## domain-hosts

### Validate host access and volatile session candidates

**Enter:** Group-to-host access edges or a privileged user's possible session

**Discovery**

```text
nxc smb TARGET -d DOMAIN -u USER -p 'PASSWORD' --shares
```

**Interpret:** A permitted SMB action identifies a host capability; it does not establish RDP/WinRM/SCM rights. Investigate sessions only with a supported, permitted remote query.

**Still check:** Verify actual group effectiveness, service/logon rights, session freshness and collection visibility.

**Verify:** Record the destination-specific successful action and freshness/limits of session evidence.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/ad-mapping/#domain-hosts)

### Full procedure and variants

```powershell
Find-LocalAdminAccess
```

```bash
nxc smb TARGET -d DOMAIN -u USER -p 'PASSWORD'
nxc smb TARGET -d DOMAIN -u USER -p 'PASSWORD' --shares
```

`Find-LocalAdminAccess` is a broad candidate generator and can be noisy or blocked by firewall/RPC controls. Validate a selected host with the service you may actually use. NetExec's `(Pwn3d!)` indicates administrative SMB context according to that tool; it does not establish RDP, WinRM, WMI/DCOM or directory rights. RDP, WinRM, SMB/service control and WMI/DCOM each have different ports, services, policies and authorization.

```powershell
Get-NetSession -ComputerName COMPUTER -Verbose
Get-NetLoggedon -ComputerName COMPUTER
```

```cmd
PsLoggedOn.exe \\COMPUTER
```

`Get-NetSession` relies on workstation/session enumeration APIs that modern Windows may restrict. PsLoggedOn combines Registry profile evidence with `NetSessionEnum`; remote Registry access and sufficient rights are relevant, and querying can itself create a network-session entry. Therefore:

- empty/denied is **inconclusive**, not proof of no users;
- a session is a time-sensitive observation, not a durable ACL;
- a session matters only if the current identity can reach/control that host and a later credential/ticket technique applies;
- session presence does not prove credentials are resident, accessible or reusable.

### Follow the evidence

- [ Obtain an authorized RDP interactive session](lateral-movement.md#move-rdp) — RDP is reachable and the identity may have remote-interactive logon rights Required: Allowed account/session policy and compatible client/NLA/TLS; hash-based Restricted Admin has additional supported-policy/admin requirements
- [ Use WinRM, WinRS or PowerShell remoting](lateral-movement.md#move-winrm) — A WinRM listener and a candidate endpoint-authorized account Required: Reachable HTTP(S) listener, accepted authentication and endpoint/session configuration permissions; hash/ticket support depends on client/context
- [ Obtain accessible live logon-session credential material](ad-identities.md#ad-lsass) — A controlled Windows host may hold useful logged-on identities Required: Required process/host privileges, useful sessions and compatible architecture; PPL/Credential Guard/protection may prevent access or remove material
## domain-graph

### Collect focused BloodHound data and validate an attack path

**Enter:** Directory relationships are too broad for manual comparison or a candidate chain needs ranking

**Discovery**

```text
In BloodHound: locate the controlled principal; inspect the exact edge, source object, destination and collection age.
Resolve its underlying group/ACL/service evidence with the corresponding manual method.
```

**Interpret:** The directory edge supplies a candidate intermediate right; missing host/session evidence cannot be invented from the graph.

**Still check:** Collect with a version-compatible SharpHound/BloodHound collector, then validate the selected edge. Resolve group nesting and effective ACEs for object control; test destination rights and session freshness for host/session edges.

**Verify:** Validate every useful edge against current directory/host evidence and identify the transition each one enables.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/ad-mapping/#domain-graph)

### Full procedure and variants

##### Current SharpHound CE

Low-noise directory baseline that avoids contacting every workstation:

```powershell
.\SharpHound.exe --CollectionMethods DCOnly --OutputDirectory .\bh --ZipFileName domain-dconly.zip
```

Add host facts only when they can answer the next question:

```powershell
.\SharpHound.exe --CollectionMethods LocalGroup --ComputerFile .\candidate-hosts.txt --OutputDirectory .\bh --ZipFileName candidate-localgroups.zip
.\SharpHound.exe --CollectionMethods Session --ComputerFile .\candidate-hosts.txt --Loop --LoopDuration 00:10:00 --OutputDirectory .\bh --ZipFileName candidate-sessions.zip
```

SharpHound with no collection flag uses its broader default, including directory data plus local-group/session attempts. `All` performs every supported method; it is not the first response to an unanswered narrow question. Import the output ZIP into a compatible BloodHound CE deployment and verify node/edge counts and ingestion errors.

<details>
<summary><strong>Collector variants and compatibility</strong></summary>

```powershell
# Inspect the actual collector before using copied syntax.
.\SharpHound.exe --help
```

```bash
# Community Linux collector; flags and output compatibility vary by release.
bloodhound-python --help
bloodhound-python -u USER -p 'PASSWORD' -d DOMAIN -ns DC_IP -dc DC_HOST -c All --zip
```

```powershell
# Legacy/course PowerShell collector; use only with a compatible legacy deployment.
Import-Module .\SharpHound.ps1
Invoke-BloodHound -CollectionMethod All -OutputDirectory .\bh -ZipFileName legacy.zip
```

Use the collector version intended for the BloodHound deployment. `bloodhound-python`, legacy SharpHound PowerShell and current SharpHound CE are alternatives with different schemas/features, not interchangeable command spellings.

</details>

##### Analyze in this order

1. Mark only identities/hosts actually controlled. A low-privilege session on a host does not make the host itself fully owned.
2. Inspect the controlled principal's direct and nested group memberships and outbound object-control edges.
3. Inspect reachable computers where it has local admin, RDP, WinRM/DCOM or other applicable rights.
4. Inspect high-value goals and shortest paths only as hypothesis generation.
5. Classify each selected edge:
   - directory/static-ish: group, ACL, GPO, OU, trust;
   - host-derived: local group or user right;
   - volatile: session;
   - route-dependent: the required host/service must be reachable now.
6. Reproduce the minimum important relationship manually before handing it to Block 11 or 12.

```text
ID | CONTROLLED PRINCIPAL | RELATIONSHIP | TARGET | SOURCE EVIDENCE
   | EFFECTIVE? | ROUTE/SERVICE | VOLATILITY | EXPECTED TRANSITION
   | MINIMUM VALIDATION | STATUS | NEXT BLOCK
```

Rank candidates by:

1. confidence that the relationship is effective;
2. deterministic value of the resulting identity/access;
3. route and service availability;
4. stability versus volatile session timing;
5. reversibility and impact;
6. number of unsupported assumptions.

Prefer a validated readable share/credential clue or direct object right over a multi-edge path built from stale sessions and unreachable hosts.

### Follow the evidence

- [ Validate effective directory-object control](ad-mapping.md#domain-acl) — An ACL/graph edge names GenericAll, GenericWrite, WriteDacl, WriteOwner or an extended/property right Required: Effective trustee membership, target object/type, inheritance/deny behavior and the exact permitted operation
- [ Validate host access and volatile session candidates](ad-mapping.md#domain-hosts) — Group-to-host access edges or a privileged user's possible session Required: Reachable destination service and its actual authorization; session evidence must be current and collection rights sufficient
- [ Maintain state and select the next evidence-producing test](integration.md#attack-state) — Several hosts, identities, routes or competing hypotheses need coordination Required: Explicit scope/objective and a record of observations, unknowns and available capabilities
## S11

### Interpret an AD trust as a boundary, not a privilege transition

**Enter:** directory or native trust enumeration identifies another domain/forest relationship.

**Discovery**

```text

```

**Interpret:** record source and destination domain, direction, trust type/transitivity, same-forest versus cross-forest context, selective authentication and SID filtering.

**Still check:** destination DNS/KDC/service reachability, accepted identity, target SPN, allowed-to-authenticate/resource rights and the exact capability sought. A trust object or child-domain administration is not automatically forest compromise.
ACTION PROCEDURE PENDING: discovery/validation only.

**Verify:** establish one destination service action under the named identity. Trust-key/SID-history forgery and coercion chains are not registered complete procedures; see RW04.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/reference/06-ad-lateral-movement/06-conditional-infrastructure-and-trusts/#trusts-inspect-the-boundary-before-treating-another-domain-as-reachable-privilege)

### Full procedure and variants

- **Enter:** directory or native trust enumeration identifies another domain/forest relationship.
- **Discover:** record source and destination domain, direction, trust type/transitivity, same-forest versus cross-forest context, selective authentication and SID filtering.
- **Validate:** destination DNS/KDC/service reachability, accepted identity, target SPN, allowed-to-authenticate/resource rights and the exact capability sought. A trust object or child-domain administration is not automatically forest compromise.
- **Execute:** [Trust-boundary inspection](https://armaanleg3nd.github.io/oscp/reference/06-ad-lateral-movement/06-conditional-infrastructure-and-trusts/#trusts-inspect-the-boundary-before-treating-another-domain-as-reachable-privilege), then [movement preflight](https://armaanleg3nd.github.io/oscp/reference/06-ad-lateral-movement/05-lateral-movement/#2-preflight-from-the-actual-source).
- **Verify:** establish one destination service action under the named identity. Trust-key/SID-history forgery and coercion chains are not registered complete procedures; see RW04.
- **Outcomes:** destination service accepts the identity and action → D29; filtering/selective-auth/resource authorization decisively denies it → ruled out here; direction/filtering/identity or route unresolved → inconclusive.

### Follow the evidence

## S18

### Inspect AD-integrated DNS record control

**Enter:** AD-integrated DNS is present and a selected zone or record object may be writable by the current principal.

**Discovery**

```text
$Root = (Get-ADRootDSE).defaultNamingContext
  $DnsBase = "CN=MicrosoftDNS,DC=DomainDnsZones,$Root"
  Get-ADObject -SearchBase $DnsBase -LDAPFilter '(objectClass=dnsNode)' -Properties dnsRecord -ResultSetSize 50
```

**Interpret:** enumerate the zone container and record objects from a domain Windows context:

  powershell
  $Root = (Get-ADRootDSE).defaultNamingContext
  $DnsBase = "CN=MicrosoftDNS,DC=DomainDnsZones,$Root"
  Get-ADObject -SearchBase $DnsBase -LDAPFilter '(objectClass=dnsNode)' -Properties dnsRecord -ResultSetSize 50

**Still check:** identify one exact dnsNode distinguished name, effective create/write-child or record-property right, zone replication scope, resolver path, intended record/value, TTL and cleanup/restore plan. Zone visibility is not write permission.
ACTION PROCEDURE PENDING: discovery/validation only.

**Verify:** a future write must resolve through the intended client path and cleanup must restore only the changed record. LDAP success alone is insufficient.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/investigate/#S18)

### Full procedure and variants

- **Enter:** AD-integrated DNS is present and a selected zone or record object may be writable by the current principal.
- **Discover:** enumerate the zone container and record objects from a domain Windows context:

  ```powershell
  $Root = (Get-ADRootDSE).defaultNamingContext
  $DnsBase = "CN=MicrosoftDNS,DC=DomainDnsZones,$Root"
  Get-ADObject -SearchBase $DnsBase -LDAPFilter '(objectClass=dnsNode)' -Properties dnsRecord -ResultSetSize 50
  ```

- **Validate:** identify one exact `dnsNode` distinguished name, effective create/write-child or record-property right, zone replication scope, resolver path, intended record/value, TTL and cleanup/restore plan. Zone visibility is not write permission.
- **Execute:** no record-add/modify/delete procedure is registered; keep mutation unavailable under RW10.
- **Verify:** a future write must resolve through the intended client path and cleanup must restore only the changed record. LDAP success alone is insufficient.
- **Outcomes:** exact writable object/zone and resolver path established → ready for RW10; effective right denied or non-AD-integrated zone → ruled out here; object visible but ACL/replication/client resolver unresolved → inconclusive.

### Follow the evidence

